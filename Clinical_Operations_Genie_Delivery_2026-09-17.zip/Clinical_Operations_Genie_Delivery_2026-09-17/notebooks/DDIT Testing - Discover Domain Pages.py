# Databricks notebook source
# DBTITLE 1,Domain Overview
# MAGIC %md
# MAGIC # DDIT Testing — Databricks Discover Domain Pages
# MAGIC
# MAGIC **Domain:** `ddit_testing`  
# MAGIC **Subdomain:** Clinical Operations  
# MAGIC **Created:** September 8, 2026  
# MAGIC **Status:** Ready for Discover Pages publication (Pages Beta)  
# MAGIC **Target:** https://docs.databricks.com/aws/en/discover/discover-page  
# MAGIC **API Ref:** https://docs.databricks.com/api/workspace/
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Purpose
# MAGIC
# MAGIC This notebook defines **4 governed Discover Pages** for the `ddit_testing` domain. Each page follows the Databricks Discover Pages schema:
# MAGIC
# MAGIC | Field | Description |
# MAGIC | --- | --- |
# MAGIC | **Page Title** | Short business-concept name (appears in Discover search and domain browse) |
# MAGIC | **Definition** | Rich-text explanation of the concept, visible to all domain consumers |
# MAGIC | **Structured Fields** | Key-value metadata pairs (e.g., Source System, Data Level, Refresh Cadence) |
# MAGIC | **Related Assets** | Linked Unity Catalog tables, metric views, dashboards, and Genie Agents |
# MAGIC | **Source Files** | Knowledge documents that the page content is derived from |
# MAGIC
# MAGIC Each section below maps directly to a Discover Page creation form in the Discover UI and is ready for manual publication.
# MAGIC
# MAGIC ### Pages Index
# MAGIC
# MAGIC | # | Page Title | Source File | Business Scope |
# MAGIC | --- | --- | --- | --- |
# MAGIC | 1 | Clinical Trial Abbreviations & Terminology | `01_abbreviations_glossary.txt` | Acronym resolution, role definitions, system names |
# MAGIC | 2 | Milestone Definitions & Readiness Criteria | `02_milestone_definitions.txt` | Milestone meaning, sequencing, and gating logic |
# MAGIC | 3 | Process Flow & Dependency Model | `04_process_flow_dependencies.txt` | End-to-end dependency chain, risk classification, critical path |
# MAGIC | 4 | Enrollment Analytics Playbook | `08_enrollment_analytics.txt` | Plan vs actual analysis, FPO/NCV/IRT source interpretation |

# COMMAND ----------

# DBTITLE 1,Page 1 — Clinical Trial Abbreviations & Terminology
# MAGIC %md
# MAGIC ## Page 1 — Clinical Trial Abbreviations & Terminology
# MAGIC
# MAGIC ### Discover Page Metadata
# MAGIC
# MAGIC | Field | Value |
# MAGIC | --- | --- |
# MAGIC | **Page Title** | Clinical Trial Abbreviations & Terminology |
# MAGIC | **Domain** | ddit_testing |
# MAGIC | **Subdomain** | Clinical Operations |
# MAGIC | **Source File** | `/Users/mutafmi1@novartis.net/knowledge_documents/01_abbreviations_glossary.txt` |
# MAGIC | **Tag** | `ABBREVIATIONS_GLOSSARY` |
# MAGIC
# MAGIC ### Definition
# MAGIC
# MAGIC Canonical reference for all clinical trial abbreviations, acronyms, role names, and system identifiers used across the Clinical Operations domain. This page resolves ambiguous shorthand in natural-language queries and ensures consistent interpretation across Genie Agents, dashboards, and reports.
# MAGIC
# MAGIC ### Structured Fields
# MAGIC
# MAGIC | Abbreviation | Full Term | Context / Disambiguation |
# MAGIC | --- | --- | --- |
# MAGIC | CTT | Clinical Trial Team | Cross-functional team responsible for planning, conduct, and reporting of clinical trials |
# MAGIC | FPS | Final Protocol Synopsis | High-level protocol summary; precedes Final Protocol |
# MAGIC | FP | Final Protocol | Comprehensive trial plan document. **Not** "First Patient" |
# MAGIC | FCA | Final Country Allocation | Country allocation entered into CTMS (NCV) |
# MAGIC | CTMS / NCV | Clinical Trial Management System / Novartis Clinical Vault | Enterprise operational data system |
# MAGIC | HA | Health Authority | National regulatory agency (FDA, EMA, PMDA, etc.) |
# MAGIC | EC / IRB | Ethics Committee / Institutional Review Board | Local ethics approval body |
# MAGIC | RFI | Request for Information | Formal query from HA on a submission |
# MAGIC | FSIV | First Site Initiation Visit | First SIV in a country/study; marks start of trial activities |
# MAGIC | SIV | Site Initiation Visit | Formal visit after all approvals in place |
# MAGIC | SSV | Site Selection Visit | Capability assessment visit to potential sites |
# MAGIC | FRIS | First Ready to Initiate Site | Checkpoint confirming site readiness before SIV |
# MAGIC | FPFV | First Patient First Visit | First patient signs informed consent |
# MAGIC | FPFT | First Patient First Treatment | First patient receives treatment |
# MAGIC | LPFV | Last Patient First Visit | Last patient signs informed consent |
# MAGIC | LPFT | Last Patient First Treatment | Last patient receives treatment |
# MAGIC | LPLV | Last Patient Last Visit | Final visit of the final participant |
# MAGIC | MVA | Modelling and Viability Assessment | Operational viability determination for the study |
# MAGIC | iDBL | Interim Clinical Database Lock | Interim data lock for planned analyses |
# MAGIC | DBL | Clinical Database Lock | Final data lock for primary analysis |
# MAGIC | SAP | Statistical Analysis Plan | Finalized statistical methodology |
# MAGIC | TFL | Tables, Figures & Listings | Statistical output shells and final deliverables |
# MAGIC | CSR | Clinical Study Report | Published and e-signed study report |
# MAGIC | eTMF / DMS | Electronic Trial Master File / Document Management System | NCV-based document repository |
# MAGIC | EDL | Essential Document List | Required documents list per milestone level |
# MAGIC | EoT | End of Trial | Trial completion and archival initiation |
# MAGIC | CPR | Clinical Packaging Request | IMP packaging approval |
# MAGIC | IMP | Investigational Medicinal Product | Study drug |
# MAGIC | FPO | FootPrint Optimizer | Novartis enrollment planning and forecasting application |
# MAGIC | IRT | Interactive Response Technology | Randomization and real-time enrollment tracking system |
# MAGIC | UAT | User Acceptance Testing | System validation before go-live |
# MAGIC | COPH | Clinical Operations Program Head | Senior program oversight role |
# MAGIC | COPM | Clinical Operations Program Manager | Program management role |
# MAGIC | SL | Study Lead | Primary operational lead for the study |
# MAGIC | SSUL | Study Start-Up Lead | Leads site activation and country startup |
# MAGIC | CTT Kick-off | CTT Kick-off Meeting | Formal meeting to introduce CTT members and start operational activities |
# MAGIC | eCRF | Electronic Case Report Form | Approved form for clinical data capture |
# MAGIC | RAVE | RAVE | Novartis standard eCRF system |
# MAGIC | DB Live | Database Live | Clinical database activation milestone |
# MAGIC | Final CSR TFL | Final CSR Tables, Figures & Listings | Full statistical analysis deliverables for the CSR |
# MAGIC | CSR Body | Clinical Study Report Body | Central narrative section of the CSR |
# MAGIC | CSR Shell | CSR Shell | Outline/template for the CSR with placeholders for TFL |
# MAGIC | EoT checklist | End of Trial Checklist | Created in NCV eTMF; sign-off represents final steps along with archival request |
# MAGIC | IMP Tech Release | Investigational Medicinal Product Technical Release | Technical release of study drug |
# MAGIC | QARP/QP Release | Quality Assurance Responsible Person / Qualified Person Regulatory Release | Regulatory quality release |
# MAGIC | RF | Request for Information | Query issued by HA on a Novartis submission (synonym of RFI) |
# MAGIC | GCO | Global Clinical Operations | Novartis team managing clinical study execution after Final Concept Sheet |
# MAGIC | GCT | Global Clinical Team | Parent team of CTTs; sets trial objectives |
# MAGIC | GCP | Good Clinical Practice | Regulatory and ethical standards for clinical trial conduct |
# MAGIC | ENRL | Enrollment | Tracked metric: total enrolled vs target; indicates recruitment progress |
# MAGIC | LPLT | Last Patient Last Treatment | Last patient completes last treatment day |
# MAGIC | SSUM | Site Start-Up Manager | Manages site-level startup activities |
# MAGIC | CPM | Country Project Manager | Country-level project management role |
# MAGIC
# MAGIC ### Related Assets
# MAGIC
# MAGIC | Asset Type | Asset Name | Role |
# MAGIC | --- | --- | --- |
# MAGIC | Knowledge File | `01_abbreviations_glossary.txt` | Source of truth for abbreviation definitions |
# MAGIC | Genie Agent | Clinical Study Planning & Milestones (`01f190a629c71bada767d3c14d08ddda`) | Consumes abbreviations in text instructions |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_study_recruitment_performance` | Uses metric_id codes that map to abbreviations |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.metric_configuration` | metric_id → human label mapping |

# COMMAND ----------

# DBTITLE 1,Page 2 — Milestone Definitions & Readiness Criteria
# MAGIC %md
# MAGIC ## Page 2 — Milestone Definitions & Readiness Criteria
# MAGIC
# MAGIC ### Discover Page Metadata
# MAGIC
# MAGIC | Field | Value |
# MAGIC | --- | --- |
# MAGIC | **Page Title** | Milestone Definitions & Readiness Criteria |
# MAGIC | **Domain** | ddit_testing |
# MAGIC | **Subdomain** | Clinical Operations |
# MAGIC | **Source File** | `/Users/mutafmi1@novartis.net/knowledge_documents/02_milestone_definitions.txt` |
# MAGIC | **Tag** | `MILESTONE_DEFINITIONS` |
# MAGIC
# MAGIC ### Definition
# MAGIC
# MAGIC Defines every clinical trial milestone tracked in the Clinical Operations domain, including its meaning, completion criteria, dependencies on predecessor milestones, and downstream impact when delayed. This page is critical for Genie to correctly interpret milestone-related queries and for risk analysis logic.
# MAGIC
# MAGIC ### Structured Fields — Milestone Semantics
# MAGIC
# MAGIC | Milestone | Definition | Key Dependencies | Delay Impact |
# MAGIC | --- | --- | --- | --- |
# MAGIC | Final Concept Sheet | Study concept endorsed; triggers operational planning | Governance board endorsement | Blocks CTT Kick-off and all downstream planning |
# MAGIC | CTT Kick-off | Cross-functional team alignment meeting | Final Concept Sheet available | Cannot develop protocol synopsis without team alignment |
# MAGIC | Final Protocol Synopsis | High-level protocol summary | CTT Kick-off; concept sheet | Delays full protocol writing |
# MAGIC | Final Protocol | Comprehensive trial plan | Synopsis approval | Cascading delays to key documents, HA/EC submissions, FSIV, FPFV |
# MAGIC | Max Country List | Broad theoretical country set | Initial feasibility/MVA | Delays trial feasibility and final allocation |
# MAGIC | Country Selected | Confirmed participating countries | Feasibility completion + allocation | Delays SSU activities, site selection, submissions |
# MAGIC | Key Study Documents Complete | All study-level submission documents ready | CTT Kick-off; protocol; EDL configuration | Gates HA/EC submissions and study greenlight |
# MAGIC | Key Country Documents Complete | Country-specific submission documents ready | Country selected; key study docs | Gates HA submission for that country |
# MAGIC | Clinical Database Go Live | Activation of EDC/database for data capture | Key study documents; UAT approval | Delays study greenlight and enrollment start |
# MAGIC | HA Submission | Regulatory dossier sent to Health Authority | Key country documents complete | Delays HA decision and country greenlight |
# MAGIC | HA Decision | Formal regulatory outcome (approval/RFI/rejection) | HA Submission | Gates country greenlight and site activation |
# MAGIC | Trial Greenlight | Study can begin enrollment | Study docs ready + DB live + 1 approved country + 1 ready site | Gates first enrollment |
# MAGIC | Country Greenlight | Country can begin site activation | HA approval + country operational readiness | Gates site greenlight within that country |
# MAGIC | Site Selection Visit (SSV) | Capability assessment at potential sites | Country selected; COPH/COPM endorsed site list | Delays site selection and confirmation |
# MAGIC | Site Selected | Site accepted after SSV | SSV outcome | Delays contract and activation |
# MAGIC | Contract Package Sent | Contract documents sent to confirmed site | Site confirmed | Required for site greenlight |
# MAGIC | Contract Fully Executed | Site contract signed | Contract package review | Gates site greenlight (with EC/IRB approval) |
# MAGIC | EC/IRB Submission | Ethics submission for site | Key site documents complete | Delays EC/IRB approval |
# MAGIC | EC/IRB Approval | Ethics approval for site | EC/IRB Submission | Prerequisite for site greenlight |
# MAGIC | Site Greenlight | Site cleared for initiation | Country greenlight + contract + EC/IRB approval + drug on site | Gates SIV |
# MAGIC | SIV (Site Initiation Visit) | Formal site training and activation | Site greenlight | Gates Ready to Screen and FPFV |
# MAGIC | Ready to Screen | Site can begin screening | SIV completed (expected within 2 weeks) | Delays first patient activity |
# MAGIC | Grant Plan | Country-specific per-patient variable cost calculation based on Visit Evaluation Schedule and local FMV benchmarks | Site confirmed; protocol VES | Budget misalignment delays contracts and site greenlight |
# MAGIC | Site Essential Document List (Site EDL) | Site-specific configuration of required documents; drives IRB/EC submission and site greenlight | Site confirmed | Incomplete EDL delays EC/IRB sub and site greenlight |
# MAGIC | Site Regulatory Greenlight | All regulatory approvals for the site confirmed | Country greenlight + study/country GL in place | Without study+country GL, site GL cannot be achieved |
# MAGIC | FPFV | First patient signs consent | Ready to Screen | Study-level achieved when first patient dosed at any site; tracked at site/country/study; HA notification required in some countries |
# MAGIC | ENRL (Enrollment) | Total enrolled vs target; percentage indicates recruitment progress; recruitment rate/month forecasts LPFV | FPFV | Slow enrollment extends LPFV and overall study timeline |
# MAGIC | LPFV | Last patient signs consent | FPFV + ongoing enrollment reaching target | Usually 100% enrollment; over-enrollment possible; HA notification required |
# MAGIC | LPLT | Last patient completes last treatment day | Ongoing treatment completion | Site-level; rolls up to country/study; linked to final analysis |
# MAGIC | LPLV | Last patient completes last visit | All patients complete/dropped | Triggers DBL and site closure; HA notification required |
# MAGIC | Site Closing | Site status changed to Closing in NCV after global LPLV | LPLV achieved for site | Close out visit can proceed after DB closure |
# MAGIC | Site Close Out Visit | Final visit to secure records, data, compliance materials | Site closing; DBL | Ideally within 12 weeks after DBL; no new site activities after |
# MAGIC | DBL | Clinical Database Lock | LPLV; data cleaning complete; all queries resolved | Gates statistical analysis and CSR; interim DBLs possible |
# MAGIC | CSR Body | Central narrative of the Clinical Study Report | DBL; analysis complete | Multiple interim CSRs possible; final requires final DBL |
# MAGIC | TFL (Tables, Figures, Listings) | Supportive trial data tables, figures, statistical listings | Alongside CSR Body development | Included in CSR |
# MAGIC | CSR Shell | Finalized outline/template for CSR with placeholders | DBL; initial draft activities | Required before final CSR |
# MAGIC | CSR Published | Completion and publication of the CSR | Final DBL + CSR Body + TFL + CSR Shell + sites closed | Interim CSR after interim DBL; final CSR after LPLV |
# MAGIC | EOT (End of Trial) | Trial completion and archival initiation | CSR Published; all sites closed | Final milestone in the trial lifecycle |
# MAGIC
# MAGIC ### Risk Classification Framework
# MAGIC
# MAGIC | Status | Criteria |
# MAGIC | --- | --- |
# MAGIC | 🟢 ON TRACK | Progressing per plan with sufficient float; no predecessor delays; no impact on FSIV/FPFV |
# MAGIC | 🟡 AT RISK | Within planned date but progress suggests difficulty; early warning indicators; potential successor impact |
# MAGIC | 🔴 OFF TRACK | Planned date not yet passed but current status makes it impossible to meet; confirmed future FSIV/FPFV slip |
# MAGIC | ❗ ISSUE | Planned finish date already missed and task remains incomplete; must be escalated |
# MAGIC
# MAGIC ### Related Assets
# MAGIC
# MAGIC | Asset Type | Asset Name | Role |
# MAGIC | --- | --- | --- |
# MAGIC | Knowledge File | `02_milestone_definitions.txt` | Source of truth for milestone semantics |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_event` | Study milestone events |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.event` | Event metadata/definitions |
# MAGIC | Landing Table | `nextgen_eu_development_clinical_operations.landing_odh.cur_milestone_planned` | Planned milestone dates |
# MAGIC | Landing Table | `nextgen_eu_development_clinical_operations.landing_odh.cur_milestone_actual` | Actual milestone dates |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_study_milestones` | Genie-ready milestone reporting |

# COMMAND ----------

# DBTITLE 1,Page 3 — Process Flow & Dependency Model
# MAGIC %md
# MAGIC ## Page 3 — Process Flow & Dependency Model
# MAGIC
# MAGIC ### Discover Page Metadata
# MAGIC
# MAGIC | Field | Value |
# MAGIC | --- | --- |
# MAGIC | **Page Title** | Process Flow & Dependency Model |
# MAGIC | **Domain** | ddit_testing |
# MAGIC | **Subdomain** | Clinical Operations |
# MAGIC | **Source File** | `/Users/mutafmi1@novartis.net/knowledge_documents/04_process_flow_dependencies.txt` |
# MAGIC | **Tag** | `PROCESS_FLOW_DEPENDENCIES` |
# MAGIC
# MAGIC ### Definition
# MAGIC
# MAGIC Documents the end-to-end clinical trial process flow from study planning through enrollment, defining phase-by-phase dependencies, operational guardrails, and critical-path reasoning. This page enables Genie and analysts to surface dependency-driven risks, detect planning gaps, and evaluate whether milestone timelines are consistent with downstream targets (FSIV/FPFV).
# MAGIC
# MAGIC ### Structured Fields — Process Phases & Dependencies
# MAGIC
# MAGIC #### Phase 1: Study Planning (Final Concept → Final Protocol)
# MAGIC
# MAGIC | Step | Dependency | Guardrail |
# MAGIC | --- | --- | --- |
# MAGIC | Final Concept Sheet | Governance endorsement | Should be available ≥24 weeks before planned Final Protocol date |
# MAGIC | CTT Kick-off | Concept sheet available | Should occur within 2 weeks of final concept sheet |
# MAGIC | Protocol Synopsis | CTT Kick-off alignment | Must be approved before full protocol finalization |
# MAGIC | Final Protocol | Synopsis approval | Typically 4–6 months from CTT Kick-off; delay cascades to all downstream |
# MAGIC
# MAGIC #### Phase 2: Feasibility & Allocation
# MAGIC
# MAGIC | Step | Dependency | Guardrail |
# MAGIC | --- | --- | --- |
# MAGIC | Feasibility KOM | Concept sheet + trial feasibility strategy | Aligns all contributors on scope and timelines |
# MAGIC | Max Country List | Initial feasibility/MVA | Theoretical country set pending validation |
# MAGIC | Trial Feasibility | Max Country List set | Includes country/site outreach, surveys, sticky-point identification |
# MAGIC | Feasibility Package Assembly | Trial feasibility output | Should complete \~8 weeks before Final Protocol |
# MAGIC | Final Allocation | Feasibility package | Confirmed countries, patient targets, site lists; triggers SSUL handover |
# MAGIC
# MAGIC #### Phase 3: Study Start-Up
# MAGIC
# MAGIC | Step | Dependency | Guardrail |
# MAGIC | --- | --- | --- |
# MAGIC | Key Study Documents | CTT Kick-off; protocol; EDL in NCV | Delays cascade to HA/EC submissions, greenlight, SIVs |
# MAGIC | Key Country Documents | Country selected; study docs | Country-specific; required for HA submission |
# MAGIC | Vendor Setup | Kick-off; vendor contracts | Vendor go-live must align with FSIV/FPFV; track via VenGo or tracker |
# MAGIC | Clinical DB Go Live | Key study docs; UAT | Gates study greenlight; delay blocks enrollment start |
# MAGIC | HA/EC Submissions | Key country docs + DB live | Gates country greenlight |
# MAGIC | Trial Greenlight | Study docs + DB live + 1 approved country + 1 ready site | Gates first enrollment |
# MAGIC
# MAGIC #### Phase 4: Site Activation
# MAGIC
# MAGIC | Step | Dependency | Guardrail |
# MAGIC | --- | --- | --- |
# MAGIC | SSV → Site Selected → Confirmed | Country selected; COPH/COPM endorsement | Track % SSV done vs planned |
# MAGIC | Contract Sent → Executed | Site confirmed | Critical for site greenlight |
# MAGIC | EC/IRB Sub → Approval | Key site docs complete | Track % approved vs planned |
# MAGIC | Site Greenlight | Country GL + contract + EC/IRB + drug on site | Only after country greenlight |
# MAGIC | SIV | Site greenlight | Marks SSU → SL handover for that site |
# MAGIC | Ready to Screen | SIV completed | Expected within 2 weeks of SIV |
# MAGIC
# MAGIC #### Phase 5: Enrollment
# MAGIC
# MAGIC | Step | Dependency | Guardrail |
# MAGIC | --- | --- | --- |
# MAGIC | FPFV | Ready to Screen; trial greenlight | Study-level achieved when first patient dosed at any site |
# MAGIC | Enrollment Progress | Active sites; recruitment rate | Track actual vs target at site/country/study level monthly |
# MAGIC | LPFV | Ongoing enrollment reaching target | Forecast from current rate; HA notification required |
# MAGIC | LPLV | All patients complete/dropped | Triggers DBL and site closure activities |
# MAGIC
# MAGIC ### HA Submission Categories
# MAGIC
# MAGIC | Category | Description | Trigger |
# MAGIC | --- | --- | --- |
# MAGIC | Initial Submission | First regulatory submission for a new clinical trial in a country; includes final protocol, IB, IMPD/CMC, recruitment materials, country forms | Starts after Final Protocol completion |
# MAGIC | Protocol Amendment Submission | Change to protocol after initial approval; triggered by endpoint/design changes, safety modifications, participant burden changes, or administrative changes | Protocol change required post-approval |
# MAGIC
# MAGIC ### Submission Pathways
# MAGIC
# MAGIC | Pathway | Scope | Key Detail |
# MAGIC | --- | --- | --- |
# MAGIC | EU-CTR Initial (Part I + Part II) | EU/EEA coordinated system | Part I = scientific package; Part II = country/site-level package; Part I submission only after final protocol |
# MAGIC | US Initial IND / IND Amendment | United States | FDA regulatory pathway |
# MAGIC | RoW Initial Submissions | Rest of World | Country-specific HA pathways |
# MAGIC
# MAGIC ### EU-CTR Specific Flow
# MAGIC
# MAGIC Part I Submission → Part I Approval → Part II Submission → Country Green Light → FSIV → FPFV
# MAGIC
# MAGIC Each step requires NCV status verification to determine On Track / At Risk / Off Track.
# MAGIC
# MAGIC ### Essential Document Lists (EDLs)
# MAGIC
# MAGIC EDLs exist for 3 milestone levels and are pre-populated in NCV:
# MAGIC
# MAGIC | Level | Key Documents |
# MAGIC | --- | --- |
# MAGIC | Study (Key Study Documents) | Protocol, protocol signature page, IB, ICF global template, CRFs/sample forms, Safety Plan, vendor manuals (IRT, eCOA, labs), recruitment docs, DSUR linkage, AxMP/IMP supply docs |
# MAGIC | Country (Key Country Documents) | Country ICF adaptation, country DSUR/RA forms, local RA application forms, EC forms, country-specific recruitment materials, PI CV requirements, local vendor qualification |
# MAGIC | Site (Key Site Documents) | Site CVs, GCP certificates, delegation log, local facility license, Site SoA, site signature page, site-specific recruitment doc approvals |
# MAGIC
# MAGIC ### FSIV/FPFV Impact Mapping
# MAGIC
# MAGIC | Status | FSIV/FPFV Impact |
# MAGIC | --- | --- |
# MAGIC | 🟢 On Track | No impact |
# MAGIC | 🟡 At Risk | Possible slip |
# MAGIC | 🔴 Off Track | Confirmed slip |
# MAGIC | ❗ Issue | Actual slip (date breached) |
# MAGIC
# MAGIC ### Budget Planning Dependencies
# MAGIC
# MAGIC SL/SSUL must ensure budget planning aligns with key milestones. Delays in budget activities should be flagged as risk with an action plan. Grant Plans define per-patient variable costs based on the Visit Evaluation Schedule and local FMV benchmarks (via GrantPlan database). Grant Plan inputs include all per-patient variable costs, protocol-driven assessments, and assumptions (screen failure rates, dropout rates).
# MAGIC
# MAGIC ### Related Assets
# MAGIC
# MAGIC | Asset Type | Asset Name | Role |
# MAGIC | --- | --- | --- |
# MAGIC | Knowledge File | `04_process_flow_dependencies.txt` | Source of truth for dependency logic and guardrails |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study` | Study master context |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_country` | Country-level footprint |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_site` | Site-level context |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_event` | Event/milestone tracking |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_country_event` | Country-level events |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_site_event` | Site-level events |
# MAGIC | Landing Table | `nextgen_eu_development_clinical_operations.landing_fpo.fpo_approved_plan_curves` | Approved plan curves from FPO |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_study_milestones` | Milestone reporting |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_scenario_planning` | Scenario planning |

# COMMAND ----------

# DBTITLE 1,Page 4 — Enrollment Analytics Playbook
# MAGIC %md
# MAGIC ## Page 4 — Enrollment Analytics Playbook
# MAGIC
# MAGIC ### Discover Page Metadata
# MAGIC
# MAGIC | Field | Value |
# MAGIC | --- | --- |
# MAGIC | **Page Title** | Enrollment Analytics Playbook |
# MAGIC | **Domain** | ddit_testing |
# MAGIC | **Subdomain** | Clinical Operations |
# MAGIC | **Source File** | `/Users/mutafmi1@novartis.net/knowledge_documents/08_enrollment_analytics.txt` |
# MAGIC | **Tag** | `ENROLLMENT_ANALYTICS` |
# MAGIC
# MAGIC ### Definition
# MAGIC
# MAGIC Operational guide for analyzing enrollment performance across clinical trials. Defines how to interpret data from the three primary source systems (FPO, NCV CTMS, IRT), explains plan-vs-actual comparison methodology, and provides the framework for diagnosing enrollment underperformance. This page ensures consistent analytical methodology across all enrollment-related Genie queries and dashboards.
# MAGIC
# MAGIC ### Structured Fields — Source Systems
# MAGIC
# MAGIC | System | Full Name | Primary Role | Key Data |
# MAGIC | --- | --- | --- | --- |
# MAGIC | FPO | FootPrint Optimizer | Planning & forecasting | Approved scenarios, planned enrollment curves, milestone projections, country allocations |
# MAGIC | NCV CTMS | Novartis Clinical Vault | Actuals tracking & system of record | Subject enrollment status, milestone actuals, site/country/study rollups |
# MAGIC | IRT | Interactive Response Technology | Real-time enrollment events | Randomization, screening, treatment arm assignment |
# MAGIC
# MAGIC ### Structured Fields — Key Enrollment Metrics
# MAGIC
# MAGIC | Metric | Level | metric_id Pattern | Interpretation |
# MAGIC | --- | --- | --- | --- |
# MAGIC | Total Enrolled Actual | Study | `s_tot_enrolled_act` | Cumulative patients randomized/enrolled |
# MAGIC | Total Enrolled Planned | Study | `s_tot_enrolled_pln` | Protocol target enrollment |
# MAGIC | Total Screened Actual | Study | `s_tot_screened_act` | Patients who signed consent |
# MAGIC | Screen Failure Rate | Study | `s_screen_failure_rate_act` | % screened who failed screening |
# MAGIC | Enrollment Rate | Study | `s_enrollment_rate_act` | Patients enrolled per unit time |
# MAGIC | Dropout Rate | Study | `s_drop_out_rate_act` | % enrolled who discontinued |
# MAGIC | Country Enrolled Actual | Country | `sc_tot_enrolled_act` | Country-level enrollment |
# MAGIC | Country Screened Actual | Country | `sc_tot_screened_act` | Country-level screening |
# MAGIC | Site Enrolled Actual | Site | `ss_tot_enrolled_act` | Site-level enrollment |
# MAGIC | Site Screened Actual | Site | `ss_tot_screened_act` | Site-level screening |
# MAGIC
# MAGIC ### Structured Fields — Analysis Framework
# MAGIC
# MAGIC #### Plan vs Actual Comparison
# MAGIC
# MAGIC | Dimension | What to Compare | Red Flag |
# MAGIC | --- | --- | --- |
# MAGIC | Enrollment Curve | Cumulative actual vs planned over time | Widening gap (actual below plan) each month |
# MAGIC | Milestone Timing | Planned vs actual dates for 25%/50%/75% enrollment | Slippage >2 weeks at any checkpoint |
# MAGIC | Site Activation | % sites initiated vs plan | Actual <80% of planned at any checkpoint |
# MAGIC | Country Contribution | Per-country enrolled vs target | Any country <50% of target while others exceed |
# MAGIC | Recruitment Rate | Patients/site/month actual vs assumed | Actual rate <70% of planned rate |
# MAGIC
# MAGIC #### Data Triangulation Rules
# MAGIC
# MAGIC | Rule | Description |
# MAGIC | --- | --- |
# MAGIC | IRT = ground truth for patient count | IRT captures randomization in real time; NCV may lag |
# MAGIC | NCV = system of record | Operational data, milestones, and official reporting |
# MAGIC | FPO = plan vs actual visualization | Overlay actuals against planned curves |
# MAGIC | IRT > NCV discrepancy | Indicates CTMS data entry lag; use IRT figure and alert CRAs |
# MAGIC | NCV missing planned values | Flag as data completeness gap; targets must exist for comparison |
# MAGIC | Monthly reconciliation | IRT vs NCV enrollment counts should match; investigate gaps |
# MAGIC
# MAGIC #### Key Factors Influencing Enrollment Speed
# MAGIC
# MAGIC | Factor | Impact | What to Monitor | Mitigation |
# MAGIC | --- | --- | --- | --- |
# MAGIC | Site Initiation Timing | Delayed SIVs reduce recruiting capacity; top reason enrollment lags | FSIV→LSIV duration vs plan; % sites initiated at each checkpoint | Track start-up cycle times; push lagging sites; add new sites to compensate |
# MAGIC | Regulatory & Ethics Approvals | HA/EC delays at country/site level bottleneck activation | HA approval to FSIV step duration by country | Flag long timelines early; re-prioritize faster countries; work with Reg Affairs |
# MAGIC | Enrollment Plan Realism | Overly optimistic recruitment rates create persistent shortfalls | Actual recruitment rate vs planned per site/month | Use historical data; revise targets or increase site count |
# MAGIC | Screening Rate | Low screening rate narrows the patient funnel regardless of screen failure % | Patients screened per site per month vs expected | Increase outreach; engage investigators; open new sites in high-pool regions |
# MAGIC | Screen Failure Rate | High SF% means more patients must be screened to reach target | SF% trend by site/country; actual vs planned SF% | Train sites on pre-screening; consider protocol amendment; filter ineligible earlier |
# MAGIC | Patient Pool / Indication | Rare diseases = naturally slower; competitive landscape exhausts shared pools | Enrollment rate trend; competitive trial intelligence | Expect longer timeline for limited pools; adjust regional spread; bolster retention |
# MAGIC | Site Performance & Engagement | Zero-enrollers and underperformers drag overall pace | Per-site enrollment; zero-enrollers after 3 months active | Support underperformers; close non-performing sites; share top-recruiter best practices |
# MAGIC | Geographical Differences | Regional variation in culture, infrastructure, and regulatory pace | Region-by-region enrollment vs target breakdown | Allocate more sites in high-performing regions; adjust country mix |
# MAGIC
# MAGIC ### Structured Fields — IRT Reconciliation & Data Integrity
# MAGIC
# MAGIC | Rule | Detail |
# MAGIC | --- | --- |
# MAGIC | IRT = ground truth for patient count | IRT captures every randomization in real time; NCV may lag by days |
# MAGIC | Monthly IRT vs NCV reconciliation | Total enrolled must match; investigate every discrepancy |
# MAGIC | Site-level cross-check | Every site with IRT enrollments must have corresponding NCV subject records |
# MAGIC | Screening vs Randomization gap | Large gap indicates high screen failure; IRT can generate explicit Screen Failure Report |
# MAGIC | IRT > NCV discrepancy action | Use IRT figure for analysis; simultaneously alert CRAs to update NCV; note data cut-off in reporting |
# MAGIC | IRT integration with analytics | If IRT feed is connected to SENSE or a dashboard, use it as the enrollment source correlated with NCV parameters |
# MAGIC | NCV Recalculate Enrollment Actuals | Use this NCV function after a batch of new subject entries to force immediate refresh of rolled-up metrics |
# MAGIC | NCV Milestone Alignment | Verify milestone dates in NCV make sense (e.g., confirm LPFV is real, not triggered by erroneous subject status) |
# MAGIC
# MAGIC ### Structured Fields — 360° Data Source Summary
# MAGIC
# MAGIC | System | Gives You | Use For |
# MAGIC | --- | --- | --- |
# MAGIC | FPO | Plan vs Actual visualizations and forecasts | Enrollment curve comparison; milestone projection; scenario planning |
# MAGIC | NCV CTMS | Detailed actuals with context (site, dates) + milestone tracking | Official reporting; milestone verification; planned vs actual at all levels |
# MAGIC | IRT | Most up-to-date enrollment events | Real-time count verification; secondary check on actuals; screen failure analysis |
# MAGIC
# MAGIC Keep these systems synchronized: if something looks off in one, cross-check with the others.
# MAGIC
# MAGIC ### Related Assets
# MAGIC
# MAGIC | Asset Type | Asset Name | Role |
# MAGIC | --- | --- | --- |
# MAGIC | Knowledge File | `08_enrollment_analytics.txt` | Source of truth for enrollment analysis methodology |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_metric` | Study-level performance metrics (EAV model) |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_country_metric` | Country-level metrics |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.study_site_metric` | Site-level metrics |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.curated_study_management.metric_configuration` | Metric ID → human label mapping |
# MAGIC | Landing Table | `nextgen_eu_development_clinical_operations.landing_fpo.fpo_approved_plan_curves` | FPO approved plan curves |
# MAGIC | Materialized View | `nextgen_eu_development_clinical_operations.curated_study_management.study_site_metric_over_time_calc` | Site-level metric trends |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_study_recruitment_performance` | Study-level enrollment KPIs |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_study_country_performance` | Country-level metrics |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_study_site_performance` | Site-level metrics |
# MAGIC | Genie Agent | Clinical Study Planning & Milestones (`01f190a629c71bada767d3c14d08ddda`) | Consumes enrollment metric definitions |

# COMMAND ----------

# DBTITLE 1,Page 5 — Milestone Chain & Dependency Model
# MAGIC %md
# MAGIC ## Page 5 — Milestone Chain & Dependency Model
# MAGIC
# MAGIC ### Discover Page Metadata
# MAGIC
# MAGIC | Field | Value |
# MAGIC | --- | --- |
# MAGIC | **Page Title** | Milestone Chain & Dependency Model |
# MAGIC | **Domain** | ddit_testing |
# MAGIC | **Subdomain** | Clinical Operations |
# MAGIC | **Source File** | `/Users/mutafmi1@novartis.net/knowledge_documents/05_milestone_chain_dependencies.txt` |
# MAGIC | **Tag** | `MILESTONE_CHAIN_DEPENDENCIES` |
# MAGIC
# MAGIC ### Definition
# MAGIC
# MAGIC Defines the complete milestone dependency chain (DAG) for clinical trial execution, covering 122 milestones across Study, Country, and Site levels. Each milestone specifies its predecessor(s), successor(s), relationship type (Finish-to-Start, Start-to-Start, Finish-to-Finish), expected duration in working days, activity type, and responsible owner role. This page enables the Genie Agent to reason about critical path analysis, dependency-driven risk assessment, and expected timelines between any two milestones.
# MAGIC
# MAGIC ### Structured Fields — Milestone Levels
# MAGIC
# MAGIC | Level | Count | Scope | Examples |
# MAGIC | --- | --- | --- | --- |
# MAGIC | Study | 25 | Study-wide milestones from CTT Kick-off through EOT | CTT Kick Off, Final Protocol, Study Greenlight, FSIV, FPFV, FPFT, LPFV, LPLT, LPLV, DBL, CSR Published, EOT |
# MAGIC | Country | 18 | Country-level milestones: selection, regulatory, enrollment progress | First Country Selected, Country Greenlight, HA Submission/Approval, EC/IRB Sub/App, ENRL_1 through ENRL_100 |
# MAGIC | Site | 79 | Site-level milestones: selection, confirmation, contracts, documents, activation, SIV | SSV chain (25-100%), Site Selected chain, Site Confirmed chain, CONTRACT_SENT chain, CONTRACT_EXEC chain, KEY_SITE_DOC chain, SITE_EC_SUB/APP chain, SITE_GREENLIGHT chain, SIV chain |
# MAGIC
# MAGIC ### Structured Fields — Critical Path: Study Start to First Patient
# MAGIC
# MAGIC | Sequence | Milestone Code | Duration (working days) | Relationship |
# MAGIC | --- | --- | --- | --- |
# MAGIC | 1 | CTT Kick Off | 1 | Start milestone |
# MAGIC | 2 | Final Protocol | 60 | FS from CTT Kick Off |
# MAGIC | 3 | Key Study Documents Complete | 30 | FS from Final Protocol |
# MAGIC | 4 | Clinical Database Go Live | 30 | FS from Final Protocol (parallel) |
# MAGIC | 5 | Study Greenlight | 1 | FS from Key Study Docs + DB Go Live |
# MAGIC | 6 | First Key Country Doc | 15 | FS from Final Protocol |
# MAGIC | 7 | First Country Greenlight | 1 | FS from First Key Country Doc |
# MAGIC | 8 | First HA Submission | 1 | FS from First Country Greenlight |
# MAGIC | 9 | First HA Approval | 90 | FS from First HA Submission |
# MAGIC | 10 | First Site Greenlight | 1 | FS from site activation chain |
# MAGIC | 11 | FSIV | 10 | FS from First Site Greenlight |
# MAGIC | 12 | Ready to Screen | 1 | FS from FSIV |
# MAGIC | 13 | FPFV | 5 | FS from Ready to Screen |
# MAGIC | 14 | FPFT | 1 | FS from FPFV |
# MAGIC
# MAGIC ### Structured Fields — Critical Path: Last Patient to Trial End
# MAGIC
# MAGIC | Sequence | Milestone Code | Duration (working days) | Relationship |
# MAGIC | --- | --- | --- | --- |
# MAGIC | 1 | ENRL_100 | — | Enrollment complete |
# MAGIC | 2 | LPFV | 1 | FS from ENRL_100 |
# MAGIC | 3 | LPFT | 1 | FS from LPFV |
# MAGIC | 4 | LPLT | 5 | FS from LPFT |
# MAGIC | 5 | LPLV | 180 | FS from LPLT |
# MAGIC | 6 | DBL | 25 | FS from LPLV |
# MAGIC | 7 | TFL / TFL_BI | 15 | FS from DBL |
# MAGIC | 8 | CSR Body | 90 | FS from LPLV (parallel: CSR Shell = FF minus 90d) |
# MAGIC | 9 | CSR Published | 5 | FS from CSR Body |
# MAGIC | 10 | Site Closed | 90 | FS from LPLV (parallel) |
# MAGIC | 11 | Site Close Out Visit | 90 | FS from Site Closed |
# MAGIC | 12 | EOT | 365 | FS from LPLV |
# MAGIC
# MAGIC ### Structured Fields — Percentage Completion Chains
# MAGIC
# MAGIC Several milestone families track incremental progress at 1%, 25%, 50%, 75%, 90%, 100%:
# MAGIC
# MAGIC | Chain | Level | Relationship Pattern | Typical Duration per Step |
# MAGIC | --- | --- | --- | --- |
# MAGIC | SSV (Site Selection Visits) | Site | Start-to-Start between steps; FF at 100% | 10 working days |
# MAGIC | Site Selected | Site | Start-to-Start; FS at 100% | 10 working days |
# MAGIC | Site Confirmed | Site | Start-to-Start; FF at 100% | 10 working days |
# MAGIC | CONTRACT_SENT | Site | Start-to-Start; FF at 100% | 5 working days |
# MAGIC | CONTRACT_EXEC | Site | Start-to-Start; FF at 100% | 25 working days |
# MAGIC | KEY_SITE_DOC | Site | Start-to-Start; SS at 100% | 25 working days |
# MAGIC | SITE_EC_SUB | Site | Start-to-Start; FS at 100% | 10 working days |
# MAGIC | SITE_EC_APP | Site | Start-to-Start; FS at 100% | 25 working days |
# MAGIC | SITE_GREENLIGHT | Site | Start-to-Start; FS at 100% | 5 working days |
# MAGIC | SIV | Site | Start-to-Start; SS at 100% | 20 working days |
# MAGIC | ENRL (Enrollment) | Country | Start-to-Start; FS at 100% | 10–130 working days |
# MAGIC
# MAGIC ### Structured Fields — Relationship Types
# MAGIC
# MAGIC | Type | Abbreviation | Meaning |
# MAGIC | --- | --- | --- |
# MAGIC | Finish to Start | FS | Predecessor must finish before successor can start (most common) |
# MAGIC | Start to Start | SS | Successor can start when predecessor starts (used for parallel % chains) |
# MAGIC | Finish to Finish | FF | Successor finishes when predecessor finishes (used for 100% gates) |
# MAGIC
# MAGIC ### Related Assets
# MAGIC
# MAGIC | Asset Type | Asset Name | Role |
# MAGIC | --- | --- | --- |
# MAGIC | Knowledge File | `05_milestone_chain_dependencies.txt` | Source of truth for the full 122-milestone dependency DAG |
# MAGIC | Reference Table | `nextgen_eu_development_sandbox.clinops_research.ref_milestone_chain` | Queryable UC table with all milestone chain data (122 rows, 12 columns) |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_milestone_raw_data` | Planned vs actual milestone dates from ODH; joinable with ref_milestone_chain on milestone code |
# MAGIC | Metric View | `nextgen_eu_development_sandbox.clinops_research.mv_study_milestones` | Study-level milestone tracking from curated_study_management |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.landing_odh.cur_milestone_planned` | Raw planned milestone dates |
# MAGIC | Source Table | `nextgen_eu_development_clinical_operations.landing_odh.cur_milestone_actual` | Raw actual milestone dates |

# COMMAND ----------

# DBTITLE 1,Publication Guidance
# MAGIC %md
# MAGIC ## Publication Guidance
# MAGIC
# MAGIC ### Status
# MAGIC
# MAGIC * **Pages Beta:** Active on this workspace
# MAGIC * **Programmatic API:** Not available from compute (all REST probes return 404; feature uses browser-session-only frontend APIs)
# MAGIC * **Creation method:** Manual via Discover UI
# MAGIC
# MAGIC ### Prerequisites
# MAGIC
# MAGIC 1. **Identify or create the `ddit_testing` domain** — Domain must exist in Discover before Pages can be attached
# MAGIC 2. **Curator permissions** — Publisher needs domain curator role to author Pages
# MAGIC
# MAGIC ### Step-by-Step Manual Creation
# MAGIC
# MAGIC For each of the 5 pages above:
# MAGIC
# MAGIC 1. Navigate to **Discover** → `ddit_testing` domain
# MAGIC 2. Click **"New Page"**
# MAGIC 3. **Page Title** → Copy from the "Page Title" row in that page's Discover Page Metadata table
# MAGIC 4. **Definition** → Copy the entire text under the "Definition" heading
# MAGIC 5. **Structured Fields** → Recreate each table row as a structured field entry; if the UI expects one value per field, combine the remaining columns into a concise sentence
# MAGIC 6. **Related Assets** → Link each asset from the "Related Assets" table using Unity Catalog or workspace search
# MAGIC 7. **Tag** → Apply the tag value from the metadata table if your Page form supports tags
# MAGIC 8. **Publish** the page and verify it appears under the `ddit_testing` domain
# MAGIC
# MAGIC ### Pages to Create (in order)
# MAGIC
# MAGIC | # | Page Title | Tag |
# MAGIC | --- | --- | --- |
# MAGIC | 1 | Clinical Trial Abbreviations & Terminology | `ABBREVIATIONS_GLOSSARY` |
# MAGIC | 2 | Milestone Definitions & Readiness Criteria | `MILESTONE_DEFINITIONS` |
# MAGIC | 3 | Process Flow & Dependency Model | `PROCESS_FLOW_DEPENDENCIES` |
# MAGIC | 4 | Enrollment Analytics Playbook | `ENROLLMENT_ANALYTICS` |
# MAGIC | 5 | Milestone Chain & Dependency Model | `MILESTONE_CHAIN_DEPENDENCIES` |
# MAGIC
# MAGIC ### Cross-References
# MAGIC
# MAGIC | Asset | Purpose |
# MAGIC | --- | --- |
# MAGIC | `Clinical Operations Genie Space - Full Status Report` | Main solution documentation; contains F1 mapping and architecture |
# MAGIC | Genie Agent `01f190a629c71bada767d3c14d08ddda` | Production Genie space consuming these domain concepts |
# MAGIC | Knowledge files in `/Users/mutafmi1@novartis.net/knowledge_documents/` | Raw source content for each page |