# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Notebook Overview
# MAGIC %md
# MAGIC # Clinical Trial Report Generator
# MAGIC
# MAGIC Generate two standalone HTML reports for a selected `study_code` using curated Genie questions. Benchmarking, example management, and benchmark monitoring are maintained in the Genie Agent, while this notebook focuses on report data retrieval, rendering, and file output.

# COMMAND ----------

# DBTITLE 1,Report Prompt Description
# MAGIC %md
# MAGIC This section defines the 10 report prompts used to retrieve executive summary and milestone analysis content for the selected study. Update these prompts only when the report sections themselves need to change.

# COMMAND ----------

# DBTITLE 1,Rendering Description
# MAGIC %md
# MAGIC This section converts the fetched Genie results into printable HTML reports with charts and saves the generated files under `/Workspace/Users/mutafmi1@novartis.net/reports`.

# COMMAND ----------

# DBTITLE 1,Config + Genie Helper
import time, json
from datetime import datetime
from databricks.sdk import WorkspaceClient

# --- Config ---
SPACE_ID = "01f1ab62b66a10d58dc563873967e205"

dbutils.widgets.text("study_code", "CAIN457R12301", "Study Code")
TEST_STUDY = dbutils.widgets.getma("study_code")

w = WorkspaceClient()

def ask_genie(question, conversation_id=None, max_polls=25):
    """Ask Genie a question. Returns dict with text, columns, rows, sql, status."""
    if conversation_id:
        msg = w.genie.create_message(space_id=SPACE_ID,
            conversation_id=conversation_id, content=question)
    else:
        msg = w.genie.start_conversation(space_id=SPACE_ID, content=question)

    for _ in range(max_polls):
        result = w.genie.get_message(space_id=SPACE_ID,
            conversation_id=msg.conversation_id, message_id=msg.message_id)
        if result.status.value in ("COMPLETED", "FAILED"):
            break
        time.sleep(2)

    resp = {"text": None, "columns": [], "rows": [], "sql": None,
            "status": result.status.value,
            "conv_id": msg.conversation_id, "msg_id": msg.message_id}

    if result.attachments:
        for att in result.attachments:
            if att.text:
                resp["text"] = att.text.content
            if att.query:
                resp["sql"] = att.query.query
                # Genie returns chunk metadata, not inline data.
                # Execute the Genie-generated SQL directly for full rows.
                try:
                    pdf = spark.sql(att.query.query).toPandas()
                    resp["columns"] = list(pdf.columns)
                    resp["rows"] = pdf.values.tolist()
                except Exception as e:
                    # Fallback: try to get columns from manifest
                    try:
                        qr = w.genie.get_message_query_result(space_id=SPACE_ID,
                            conversation_id=msg.conversation_id, message_id=msg.message_id)
                        if qr.statement_response and qr.statement_response.manifest:
                            resp["columns"] = [c.name for c in qr.statement_response.manifest.schema.columns]
                    except Exception:
                        pass
    return resp

print(f"Genie helper ready. Test study: {TEST_STUDY}")

# COMMAND ----------

# DBTITLE 1,Report Query Definitions
# ============================================================
# Report query definitions — all prompts tagged by report
# ============================================================

CERTIFIED_QUERIES = [
    # ─── Executive Summary ───
    {"id": "CQ-1", "report": "Executive Summary", "section": "KPI Dashboard",
     "question": f"Show all recruitment KPIs and their values for study {TEST_STUDY}"},

    {"id": "CQ-2", "report": "Executive Summary", "section": "Country Enrollment",
     "question": f"For study {TEST_STUDY}, show each country with metric name and metric value for the enrollment metrics TE Actual, TE Planned, TS Actual, TS Planned, plus sites set up and sites planned. Only include countries where sites set up is greater than 0."},

    {"id": "CQ-3", "report": "Executive Summary", "section": "Milestone Snapshot",
     "question": f"Show overdue and pending milestones for study {TEST_STUDY} with event name, milestone status, event category, scheduled date, and baseline date. Only include milestones that have a scheduled date."},

    {"id": "CQ-4", "report": "Executive Summary", "section": "Risks & Actions",
     "question": f"What are the top 5 risks for study {TEST_STUDY} based on overdue milestones and countries with lowest enrollment vs plan? Include risk type, detail, and severity."},

    # ─── Milestone Analysis ───
    {"id": "CQ-5", "report": "Milestone Analysis", "section": "All Milestones",
     "question": f"List all milestones for study {TEST_STUDY} with milestone status, event name, event category, actual date, baseline date, scheduled date, and days variance from baseline, ordered by event category then status"},

    {"id": "CQ-6", "report": "Milestone Analysis", "section": "Variance & Overdue",
     "question": f"Show milestones for study {TEST_STUDY} that are either Overdue or have positive days variance from baseline. Include event name, milestone status, event category, actual date, baseline date, scheduled date, and days variance from baseline. Sort by milestone status then by days variance descending."},

    {"id": "CQ-7", "report": "Milestone Analysis", "section": "Country & Site",
     "question": f"For study {TEST_STUDY}, show each country with the metric business name and metric value for metrics TE Actual, TE Planned, TS Actual, and TS Planned. Also show sites set up and sites planned. Only include countries where sites set up is greater than 0."},

    {"id": "CQ-8", "report": "Milestone Analysis", "section": "Scenarios",
     "question": f"Show scenario planning data for study {TEST_STUDY} with scenario name, scenario status, screening rate, and randomization rate"},

    {"id": "CQ-9", "report": "Milestone Analysis", "section": "Risk Insights",
     "question": f"For study {TEST_STUDY}, show a combined risk summary table with: 1) all overdue milestones with event name and days since scheduled date, 2) countries where enrolled actual is less than enrolled planned. Label each row as 'Overdue Milestone' or 'Enrollment Gap'. Sort by risk severity descending."},

    # ─── Cross-Report (shared context) ───
    {"id": "CQ-10", "report": "Executive Summary", "section": "Study Overview",
     "question": f"Provide a summary overview of study {TEST_STUDY}: study name, study phase, total enrolled actual vs planned, total screened actual vs planned, and the count of overdue milestones."},
]

print(f"Defined {len(CERTIFIED_QUERIES)} report queries:")
for cq in CERTIFIED_QUERIES:
    print(f"  {cq['id']:5} [{cq['report']:20}] {cq['section']}")

# COMMAND ----------

# DBTITLE 1,Fetch Report Sections from Genie
# ============================================================
# Fetch all report sections from Genie
# ============================================================
import pandas as pd

results = {}
fetch_rows = []

for cq in CERTIFIED_QUERIES:
    print(f"\n{'='*60}")
    print(f"{cq['id']} [{cq['report']}] {cq['section']}")
    print(f"Prompt: {cq['question'][:90]}...")
    t0 = time.time()

    conv_id = None
    if cq.get("follow_up_of") and cq["follow_up_of"] in results:
        conv_id = results[cq["follow_up_of"]]["conv_id"]
        print(f"  Reusing conversation from {cq['follow_up_of']}")

    resp = ask_genie(cq["question"], conversation_id=conv_id)
    elapsed = round(time.time() - t0, 1)
    results[cq["id"]] = resp

    has_data = len(resp["rows"]) > 0
    has_text = resp["text"] is not None and len(resp["text"]) > 0
    has_sql = resp["sql"] is not None

    status_icon = "✅" if resp["status"] == "COMPLETED" else "❌"
    data_icon = f"✅ {len(resp['rows'])} rows" if has_data else "⚠️ no data"
    text_icon = f"✅ {len(resp['text'])} chars" if has_text else "⚠️ no text"

    print(f"  Status: {status_icon} {resp['status']} ({elapsed}s)")
    print(f"  Data:   {data_icon}  |  Columns: {resp['columns'][:5]}")
    print(f"  Text:   {text_icon}")
    if has_sql:
        print(f"  SQL:    {resp['sql'][:120]}...")
    if has_text:
        print(f"  Narrative preview: {resp['text'][:200]}...")

    fetch_rows.append({
        "Query ID": cq["id"], "Report": cq["report"], "Section": cq["section"],
        "Status": resp["status"], "Rows": len(resp["rows"]),
        "Has SQL": has_sql, "Has Text": has_text,
        "Columns": ", ".join(resp["columns"][:5]),
        "Time (s)": elapsed
    })

print(f"\n{'='*60}")
print("SECTION FETCH SUMMARY")
fetch_df = pd.DataFrame(fetch_rows)
display(fetch_df)

blockers = []
warnings = []
for _, row in fetch_df.iterrows():
    if row["Status"] != "COMPLETED":
        blockers.append(f"{row['Query ID']}: Genie returned {row['Status']}")
    elif row["Rows"] == 0 and not row["Has Text"]:
        blockers.append(f"{row['Query ID']}: No table rows or narrative returned")
    elif row["Rows"] == 0:
        warnings.append(f"{row['Query ID']}: Narrative-only response")

if blockers:
    print(f"\n❌ BLOCKERS ({len(blockers)}):")
    for item in blockers:
        print(f"  - {item}")
if warnings:
    print(f"\n⚠️ WARNINGS ({len(warnings)}):")
    for item in warnings:
        print(f"  - {item}")
if not blockers and not warnings:
    print("\n✅ All report sections fetched successfully")
elif not blockers:
    print(f"\n✅ No blockers. {len(warnings)} warning(s) noted.")
else:
    print(f"\n❌ {len(blockers)} blocker(s) — fix before rendering reports.")

# COMMAND ----------

# DBTITLE 1,Risk Classification Engine
# ============================================================
# Risk Classification Engine — enriches Genie results with
# multi-type, severity-coded risk analysis from direct SQL
# ============================================================
import pandas as pd

SEVERITY_THRESHOLDS = {
    "Critical": {"min_days": 365, "min_gap_pct": 50, "min_sfr": 60, "color": "#8B0000"},
    "High":     {"min_days": 90,  "min_gap_pct": 20, "min_sfr": 40, "color": "#C0504D"},
    "Medium":   {"min_days": 30,  "min_gap_pct": 10, "min_sfr": 30, "color": "#E6A817"},
    "Low":      {"min_days": 0,   "min_gap_pct": 0,  "min_sfr": 0,  "color": "#70AD47"},
}

def classify_severity(days=None, gap_pct=None, sfr=None):
    for sev, t in SEVERITY_THRESHOLDS.items():
        if days is not None and days >= t["min_days"]:
            return sev
        if gap_pct is not None and gap_pct >= t["min_gap_pct"]:
            return sev
        if sfr is not None and sfr >= t["min_sfr"]:
            return sev
    return "Low"

def build_comprehensive_risks(study_code):
    """Build multi-type risk table from direct SQL queries."""
    all_risks = []

    # ── 1. Overdue Milestones ──
    overdue = spark.sql(f"""
        SELECT event_name, event_category, scheduled_date,
               DATEDIFF(CURRENT_DATE(), scheduled_date) AS days_overdue
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_milestones
        WHERE study_code_alias = '{study_code}'
          AND milestone_progress_status = 'Overdue'
          AND scheduled_date IS NOT NULL
        ORDER BY days_overdue DESC
    """).toPandas()
    for _, r in overdue.iterrows():
        sev = classify_severity(days=r['days_overdue'])
        all_risks.append({
            "Risk Type": "Overdue Milestone",
            "Detail": f"{r['event_name']}" + (f" ({r['event_category']})" if pd.notna(r['event_category']) else ""),
            "Metric": f"{int(r['days_overdue'])} days overdue",
            "Severity": sev,
            "Recommended Action": "Escalate to CTT" if sev in ("Critical", "High") else "Monitor closely"
        })

    # ── 2. Enrollment Gaps ──
    enroll = spark.sql(f"""
        SELECT country_name,
          MAX(CASE WHEN metric_id = 'sc_tot_enrolled_act' THEN metric_value END) AS enrolled_actual,
          MAX(CASE WHEN metric_id = 'sc_tot_enrolled_pln' THEN metric_value END) AS enrolled_planned
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_country_performance
        WHERE study_code_alias = '{study_code}'
          AND metric_id IN ('sc_tot_enrolled_act', 'sc_tot_enrolled_pln')
        GROUP BY country_name
        HAVING enrolled_planned > 0 AND enrolled_actual < enrolled_planned
    """).toPandas()
    for _, r in enroll.iterrows():
        gap = r['enrolled_planned'] - r['enrolled_actual']
        gap_pct = (gap / r['enrolled_planned']) * 100 if r['enrolled_planned'] > 0 else 0
        sev = classify_severity(gap_pct=gap_pct)
        all_risks.append({
            "Risk Type": "Enrollment Gap",
            "Detail": f"{r['country_name']}: {int(r['enrolled_actual'])}/{int(r['enrolled_planned'])} enrolled",
            "Metric": f"{gap_pct:.0f}% below plan ({int(gap)} patients)",
            "Severity": sev,
            "Recommended Action": "Add sites or reallocate" if sev in ("Critical", "High") else "Track enrollment curve"
        })

    # ── 3. Screen Failure Alerts ──
    sfr = spark.sql(f"""
        SELECT country_name,
          MAX(CASE WHEN metric_id = 'sc_screen_failure_rate_act' THEN metric_value END) AS sfr_actual,
          MAX(CASE WHEN metric_id = 'sc_screen_failure_rate_pln' THEN metric_value END) AS sfr_planned
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_country_performance
        WHERE study_code_alias = '{study_code}'
          AND metric_id IN ('sc_screen_failure_rate_act', 'sc_screen_failure_rate_pln')
        GROUP BY country_name
        HAVING sfr_actual > 30
    """).toPandas()
    for _, r in sfr.iterrows():
        sev = classify_severity(sfr=r['sfr_actual'])
        all_risks.append({
            "Risk Type": "Screen Failure Alert",
            "Detail": f"{r['country_name']}: SFR {r['sfr_actual']:.0f}%" + (f" (plan: {r['sfr_planned']:.0f}%)" if pd.notna(r['sfr_planned']) and r['sfr_planned'] > 0 else ""),
            "Metric": f"SFR {r['sfr_actual']:.0f}%",
            "Severity": sev,
            "Recommended Action": "Review eligibility criteria & site training" if sev in ("Critical", "High") else "Monitor SFR trend"
        })

    # ── 4. Site Activation Delay ──
    sites = spark.sql(f"""
        SELECT country_name, sites_set_up, sites_planned
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_country_performance
        WHERE study_code_alias = '{study_code}'
          AND sites_planned > 0
          AND sites_set_up < sites_planned
        GROUP BY country_name, sites_set_up, sites_planned
    """).toPandas()
    for _, r in sites.iterrows():
        gap_pct = ((r['sites_planned'] - r['sites_set_up']) / r['sites_planned']) * 100
        sev = classify_severity(gap_pct=gap_pct)
        all_risks.append({
            "Risk Type": "Site Activation Delay",
            "Detail": f"{r['country_name']}: {int(r['sites_set_up'])}/{int(r['sites_planned'])} sites active",
            "Metric": f"{gap_pct:.0f}% behind plan",
            "Severity": sev,
            "Recommended Action": "Accelerate HA/EC submissions" if sev in ("Critical", "High") else "Track SIV timeline"
        })

    risk_df = pd.DataFrame(all_risks)
    if not risk_df.empty:
        sev_order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
        risk_df["_sev_rank"] = risk_df["Severity"].map(sev_order)
        risk_df = risk_df.sort_values("_sev_rank").drop(columns=["_sev_rank"]).reset_index(drop=True)
    return risk_df

# Build comprehensive risk table
risk_df = build_comprehensive_risks(TEST_STUDY)

# Inject into results dict for report rendering
if 'results' not in dir():
    results = {}
results["CQ-RISK"] = {
    "columns": list(risk_df.columns) if not risk_df.empty else [],
    "rows": risk_df.values.tolist() if not risk_df.empty else [],
    "text": None,
    "sql": None,
    "status": "COMPLETED"
}

print(f"Risk Classification Summary for {TEST_STUDY}:")
print(f"  Total risks identified: {len(risk_df)}")
if not risk_df.empty:
    print(f"  By severity: {dict(risk_df['Severity'].value_counts())}")
    print(f"  By type: {dict(risk_df['Risk Type'].value_counts())}")
    display(risk_df)

# COMMAND ----------

# DBTITLE 1,Cross-Domain Analysis & Narrative Engine
# ============================================================
# Cross-Domain Analysis & Narrative Engine
# Fetches study / country / milestone / site data via direct SQL,
# builds cross-domain flags, and generates analytical narratives
# that mirror the rich interpretive style of clinical operations
# status reports (executive narrative, country action matrix,
# KPI scorecards with targets, post-SIV inactivity analysis).
# ============================================================
import pandas as pd
import numpy as np
from datetime import datetime

# ----------------------------------------------------------------
# 1. DATA FETCHING  (direct SQL — no Genie dependency)
# ----------------------------------------------------------------
def fetch_study_kpis(study_code):
    """Study-level KPIs + metadata: enrolled, screened, SFR, rate, study_name, study_phase."""
    df = spark.sql(f"""
        SELECT metric_id, metric_value, metric_business_name, study_name, study_phase
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_recruitment_performance
        WHERE study_code_alias = '{study_code}'
          AND metric_id IN (
            's_tot_enrolled_act','s_tot_enrolled_pln',
            's_tot_screened_act','s_tot_screened_pln',
            's_screen_failure_rate_act','s_screen_failure_rate_pln',
            's_enrollment_rate_act','s_enrollment_rate_pln',
            's_no_sites_set_up','s_no_of_sites_pln',
            's_no_of_countries_pln','s_no_countries_set_up'
          )
    """).toPandas()
    kpis = {}
    for _, r in df.iterrows():
        kpis[r['metric_id']] = float(r['metric_value']) if pd.notna(r['metric_value']) else 0
    if not df.empty:
        kpis['_study_name'] = str(df.iloc[0].get('study_name', '') or '').strip()
        kpis['_study_phase'] = str(df.iloc[0].get('study_phase', '') or '').strip()
    return kpis

def fetch_country_matrix(study_code):
    """Country-level: enrollment, screening, SFR, sites set up/planned."""
    df = spark.sql(f"""
        SELECT country_name,
            MAX(CASE WHEN metric_id='sc_tot_enrolled_act' THEN metric_value END) AS enrolled_act,
            MAX(CASE WHEN metric_id='sc_tot_enrolled_pln' THEN metric_value END) AS enrolled_pln,
            MAX(CASE WHEN metric_id='sc_tot_screened_act' THEN metric_value END) AS screened_act,
            MAX(CASE WHEN metric_id='sc_tot_screened_pln' THEN metric_value END) AS screened_pln,
            MAX(CASE WHEN metric_id='sc_screen_failure_rate_act' THEN metric_value END) AS sfr_act,
            MAX(CASE WHEN metric_id='sc_screen_failure_rate_pln' THEN metric_value END) AS sfr_pln,
            MAX(CASE WHEN metric_id='sc_enrollment_rate_act' THEN metric_value END) AS enroll_rate,
            MAX(sites_set_up) AS sites_active,
            MAX(sites_planned) AS sites_planned
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_country_performance
        WHERE study_code_alias = '{study_code}'
        GROUP BY country_name
        HAVING MAX(sites_planned) > 0 OR MAX(sites_set_up) > 0
        ORDER BY enrolled_act DESC
    """).toPandas()
    for c in ['enrolled_act','enrolled_pln','screened_act','screened_pln','sfr_act','sfr_pln','enroll_rate','sites_active','sites_planned']:
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0)
    return df

def fetch_milestone_health(study_code):
    """Milestones: overdue, pending, completed with days variance."""
    df = spark.sql(f"""
        SELECT event_name, event_category, milestone_progress_status,
               actual_date, baseline_date, scheduled_date,
               CASE
                 WHEN milestone_progress_status = 'Overdue' AND scheduled_date IS NOT NULL
                 THEN DATEDIFF(CURRENT_DATE(), scheduled_date)
                 ELSE NULL
               END AS days_overdue,
               days_variance_from_baseline
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_milestones
        WHERE study_code_alias = '{study_code}'
        ORDER BY milestone_progress_status, days_overdue DESC NULLS LAST
    """).toPandas()
    return df

def fetch_site_summary(study_code):
    """Site-level: count by status, identify inactive post-SIV sites."""
    df = spark.sql(f"""
        SELECT country_name, site_status,
            MAX(CASE WHEN metric_id='ss_tot_screened_act' THEN metric_value END) AS screened,
            MAX(CASE WHEN metric_id='ss_tot_enrolled_act' THEN metric_value END) AS enrolled
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_site_performance
        WHERE study_code_alias = '{study_code}'
        GROUP BY country_name, site_status
    """).toPandas()
    for c in ['screened','enrolled']:
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0)
    return df

def fetch_scenario_data(study_code):
    """Scenario planning: approved scenarios with rates."""
    df = spark.sql(f"""
        SELECT scenario_name, scenario_status, screening_rate, randomization_rate
        FROM nextgen_eu_development_sandbox.clinops_research.mv_scenario_planning
        WHERE study_code_alias = '{study_code}'
        ORDER BY scenario_status, scenario_name
    """).toPandas()
    return df

def fetch_ha_ec_approvals(study_code):
    """Derive HA and EC/IRB approval coverage from milestone events."""
    df = spark.sql(f"""
        SELECT event_name, milestone_progress_status, actual_date, scheduled_date
        FROM nextgen_eu_development_sandbox.clinops_research.mv_study_milestones
        WHERE study_code_alias = '{study_code}'
          AND (UPPER(event_name) LIKE '%HA %' OR UPPER(event_name) LIKE '%HA\\_%'
               OR UPPER(event_name) LIKE '%HEALTH AUTH%'
               OR UPPER(event_name) LIKE '%EC %' OR UPPER(event_name) LIKE '%EC\\_%'
               OR UPPER(event_name) LIKE '%IRB%' OR UPPER(event_name) LIKE '%ETHICS%')
    """).toPandas()
    ha_mask = df['event_name'].str.upper().str.contains(r'\bHA\b|HEALTH.AUTH', regex=True, na=False)
    ec_mask = df['event_name'].str.upper().str.contains(r'\bEC\b|IRB|ETHICS', regex=True, na=False)
    return {
        'ha_total': int(ha_mask.sum()),
        'ha_done': int((ha_mask & (df['milestone_progress_status']=='Completed')).sum()),
        'ha_pending': int((ha_mask & (df['milestone_progress_status']=='Pending')).sum()),
        'ha_overdue': int((ha_mask & (df['milestone_progress_status']=='Overdue')).sum()),
        'ec_total': int(ec_mask.sum()),
        'ec_done': int((ec_mask & (df['milestone_progress_status']=='Completed')).sum()),
        'ec_pending': int((ec_mask & (df['milestone_progress_status']=='Pending')).sum()),
        'ec_overdue': int((ec_mask & (df['milestone_progress_status']=='Overdue')).sum()),
    }

def generate_regulatory_narrative(ha_ec):
    """Generate regulatory throughput narrative from HA/EC milestone data."""
    lines = []
    ha_t, ha_d, ec_t, ec_d = ha_ec['ha_total'], ha_ec['ha_done'], ha_ec['ec_total'], ha_ec['ec_done']
    if ha_t > 0:
        ha_pct = ha_d / ha_t * 100
        status = 'on track' if ha_pct >= 80 else 'at risk' if ha_pct >= 50 else 'critical'
        lines.append(f'**HA Approvals:** {ha_d}/{ha_t} ({ha_pct:.0f}%) \u2014 {status}.')
        if ha_ec['ha_overdue'] > 0:
            lines.append(f'\U0001f534 {ha_ec["ha_overdue"]} HA approvals overdue \u2014 escalate regulatory submissions.')
        if ha_ec['ha_pending'] > 0:
            lines.append(f'\u23F1 {ha_ec["ha_pending"]} HA approvals pending \u2014 monitor timeline.')
    else:
        lines.append('**HA Approvals:** No HA milestone events found in current tracking data.')
    if ec_t > 0:
        ec_pct = ec_d / ec_t * 100
        status = 'on track' if ec_pct >= 80 else 'at risk' if ec_pct >= 50 else 'critical'
        lines.append(f'**EC/IRB Approvals:** {ec_d}/{ec_t} ({ec_pct:.0f}%) \u2014 {status}.')
        if ha_ec['ec_overdue'] > 0:
            lines.append(f'\U0001f534 {ha_ec["ec_overdue"]} EC/IRB approvals overdue \u2014 prioritize submissions.')
    else:
        lines.append('**EC/IRB Approvals:** No EC/IRB milestone events found in current tracking data.')
    if ha_t == 0 and ec_t == 0:
        lines.append('\u26A0 Regulatory milestone coverage not available \u2014 HA/EC events not found via event name pattern matching. Direct approval tracking table would improve coverage.')
    return '\n\n'.join(lines)

def build_post_siv_analysis(country_df, site_summary):
    """Build dedicated post-SIV inactivity analysis."""
    inactive = country_df[(country_df['sites_active'] > 0) & (country_df['screened_act'] == 0)]
    analysis = {'countries': [], 'total_inactive': len(inactive), 'narrative': ''}
    for _, c in inactive.iterrows():
        analysis['countries'].append({
            'country': c['country_name'], 'sites_active': int(c['sites_active']),
            'sites_planned': int(c['sites_planned']), 'enrolled': int(c['enrolled_act'])
        })
    if len(inactive) > 0:
        names = ', '.join(inactive['country_name'].tolist()[:6])
        extra = f' (+{len(inactive)-6} more)' if len(inactive) > 6 else ''
        analysis['narrative'] = f'**Post-SIV Inactivity:** {len(inactive)} countries have active sites but 0 patients screened: {names}{extra}.\n\n'
        analysis['narrative'] += 'These countries completed Site Initiation Visits but have not begun screening. Root causes may include:\n'
        analysis['narrative'] += '- Regulatory/EC delays preventing patient contact\n'
        analysis['narrative'] += '- Staffing gaps or PI availability constraints\n'
        analysis['narrative'] += '- Referral pipeline not yet established\n\n'
        analysis['narrative'] += '**Recommended action:** CRA-led screening kick-off call within 2 weeks for each inactive site.'
    else:
        analysis['narrative'] = 'No post-SIV inactivity detected. All countries with active sites have begun screening.'
    return analysis

# ----------------------------------------------------------------
# 2. CROSS-DOMAIN FLAG GENERATION
# ----------------------------------------------------------------
def generate_cross_domain_flags(country_df, milestone_df):
    """Connect enrollment gaps to milestone delays per country."""
    flags = []
    # Get country-level overdue milestones
    overdue = milestone_df[milestone_df['milestone_progress_status'] == 'Overdue']
    overdue_events = {}
    for _, m in overdue.iterrows():
        en = m['event_name']
        # Try to extract country from event_category or name
        # Study-level milestones apply to all countries
        if en not in overdue_events:
            overdue_events[en] = int(m['days_overdue']) if pd.notna(m['days_overdue']) else 0

    for _, c in country_df.iterrows():
        country = c['country_name']
        cf = {'country': country, 'flags': [], 'actions': [], 'severity': 'Low'}

        # Flag 1: Zero enrollment with active sites
        if c['sites_active'] > 0 and c['enrolled_act'] == 0:
            cf['flags'].append('\U0001f534 0 enrolled (active site present)')
            cf['severity'] = 'Critical'
            cf['actions'].append('Funnel check: confirm screening start + referral sources')

        # Flag 2: Enrollment significantly behind plan
        elif c['enrolled_pln'] > 0 and c['enrolled_act'] < c['enrolled_pln']:
            gap_pct = ((c['enrolled_pln'] - c['enrolled_act']) / c['enrolled_pln']) * 100
            if gap_pct >= 50:
                cf['flags'].append(f'\U0001f534 {int(c["enrolled_act"])}/{int(c["enrolled_pln"])} enrolled ({gap_pct:.0f}% gap)')
                cf['severity'] = 'Critical'
                cf['actions'].append('Add sites or reallocate patients from overperforming countries')
            elif gap_pct >= 20:
                cf['flags'].append(f'\U0001f7e0 {int(c["enrolled_act"])}/{int(c["enrolled_pln"])} enrolled ({gap_pct:.0f}% gap)')
                cf['severity'] = max(cf['severity'], 'High', key=lambda x: ['Low','Medium','High','Critical'].index(x))
                cf['actions'].append('Monitor enrollment trajectory; prepare contingency plan')

        # Flag 3: High screen failure rate
        if c['sfr_act'] >= 40:
            cf['flags'].append(f'\U0001f534 SFR {c["sfr_act"]:.0f}%' + (f' (plan {c["sfr_pln"]:.0f}%)' if c['sfr_pln'] > 0 else ''))
            cf['actions'].append('Review eligibility criteria + pre-screening workflows')
            cf['severity'] = max(cf['severity'], 'High', key=lambda x: ['Low','Medium','High','Critical'].index(x))
        elif c['sfr_act'] >= 30:
            cf['flags'].append(f'\U0001f7e0 SFR {c["sfr_act"]:.0f}%')
            cf['actions'].append('Monitor SFR trend; consider pre-screening tools')

        # Flag 4: Site activation behind plan
        if c['sites_planned'] > 0 and c['sites_active'] < c['sites_planned']:
            site_gap = ((c['sites_planned'] - c['sites_active']) / c['sites_planned']) * 100
            if site_gap >= 50:
                cf['flags'].append(f'\u23F1 {int(c["sites_active"])}/{int(c["sites_planned"])} sites active ({site_gap:.0f}% gap)')
                cf['actions'].append('Accelerate HA/EC submissions; allocate CRA resources')
                cf['severity'] = max(cf['severity'], 'High', key=lambda x: ['Low','Medium','High','Critical'].index(x))

        # Flag 5: Cross-domain — overdue milestones affecting this study
        if overdue_events:
            top_overdue = sorted(overdue_events.items(), key=lambda x: x[1], reverse=True)[:2]
            milestone_flag = ', '.join(f'{e} ({d}d)' for e, d in top_overdue if d > 30)
            if milestone_flag:
                cf['flags'].append(f'\u23F1 Overdue: {milestone_flag}')

        if cf['flags']:
            flags.append(cf)

    # Sort by severity
    sev_order = {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3}
    flags.sort(key=lambda x: sev_order.get(x['severity'], 3))
    return flags

# ----------------------------------------------------------------
# 3. KPI SCORECARD BUILDER
# ----------------------------------------------------------------
def build_kpi_scorecards(kpis, country_df, milestone_df, ha_ec=None):
    """Build structured KPI cards with actual/plan/target/status."""
    cards = []

    # 1. Enrollment vs Plan
    enr_act = kpis.get('s_tot_enrolled_act', 0)
    enr_pln = kpis.get('s_tot_enrolled_pln', 0)
    enr_status = 'green' if enr_act >= enr_pln else ('amber' if enr_act >= enr_pln * 0.8 else 'red')
    if enr_pln > 0 and enr_act > enr_pln:
        enr_detail = f'Target met (+{int(enr_act - enr_pln)} over plan)'
    elif enr_pln > 0:
        enr_detail = f'{((enr_pln - enr_act) / enr_pln * 100):.0f}% behind plan'
    else:
        enr_detail = f'{int(enr_act)} enrolled (no plan available)'
    cards.append({
        'title': 'ENROLLMENT VS PLAN (TO-DATE)',
        'value': f'{int(enr_act)} actual vs {int(enr_pln)} plan-to-date',
        'detail': enr_detail,
        'target': 'Actual >= Plan Until Today',
        'status': enr_status
    })

    # 2. Active Sites vs Plan (use STUDY-level KPIs, not sparse country sums)
    sites_act = int(kpis.get('s_no_sites_set_up', country_df['sites_active'].sum()))
    sites_pln = int(kpis.get('s_no_of_sites_pln', 0)) or int(country_df['sites_planned'].sum())
    site_status = 'green' if sites_act >= sites_pln else ('amber' if sites_act >= sites_pln * 0.8 else 'red')
    if sites_pln > 0 and sites_act > sites_pln:
        site_detail = f'Target exceeded (+{sites_act - sites_pln} over plan)'
    elif sites_pln > 0:
        site_detail = f'{sites_act/sites_pln*100:.0f}% activated'
    else:
        site_detail = f'{sites_act} active (no plan available)'
    cards.append({
        'title': 'ACTIVE SITES VS PLAN',
        'value': f'{sites_act} active vs {sites_pln} planned',
        'detail': site_detail,
        'target': 'Active Sites >= Sites Planned as of Today',
        'status': site_status
    })

    # 3. Screen Failure Rate
    sfr_act = kpis.get('s_screen_failure_rate_act', 0)
    sfr_pln = kpis.get('s_screen_failure_rate_pln', 0)
    sfr_target = sfr_pln if sfr_pln > 0 else 25.0
    sfr_status = 'green' if sfr_act <= sfr_target else ('amber' if sfr_act <= sfr_target * 1.5 else 'red')
    cards.append({
        'title': 'SCREEN FAILURE RATE',
        'value': f'{sfr_act:.1f}% actual' + (f' vs {sfr_pln:.1f}% plan' if sfr_pln > 0 else ''),
        'detail': 'Within target' if sfr_act <= sfr_target else f'{sfr_act - sfr_target:.1f}pp above target',
        'target': f'<= {sfr_target:.1f}%',
        'status': sfr_status
    })

    # 4. Screening Rate
    rate_act = kpis.get('s_enrollment_rate_act', 0)
    rate_pln = kpis.get('s_enrollment_rate_pln', 0)
    rate_status = 'green' if rate_act >= rate_pln else ('amber' if rate_act >= rate_pln * 0.7 else 'red')
    cards.append({
        'title': 'ENROLLMENT RATE',
        'value': f'{rate_act:.2f} actual' + (f' vs {rate_pln:.2f} plan' if rate_pln > 0 else ''),
        'detail': 'On track' if rate_act >= rate_pln else 'Below target',
        'target': f'>= {rate_pln:.2f}' if rate_pln > 0 else 'N/A',
        'status': rate_status
    })

    # 5. Overdue Milestones
    overdue = milestone_df[milestone_df['milestone_progress_status'] == 'Overdue']
    n_overdue = len(overdue)
    ms_status = 'green' if n_overdue == 0 else ('amber' if n_overdue <= 2 else 'red')
    cards.append({
        'title': 'STUDY-LEVEL OVERDUE MILESTONES',
        'value': f'{n_overdue} overdue milestone{"s" if n_overdue != 1 else ""}',
        'detail': 'All on track' if n_overdue == 0 else f'Top: {overdue.iloc[0]["event_name"]}' if len(overdue) > 0 else '',
        'target': '0 overdue milestones',
        'status': ms_status
    })

    # 6. Countries with active enrollment (use STUDY-level KPIs for plan)
    n_countries_active = int(kpis.get('s_no_countries_set_up', len(country_df[country_df['sites_active'] > 0])))
    n_countries_plan = int(kpis.get('s_no_of_countries_pln', 0)) or len(country_df[country_df['sites_planned'] > 0])
    cov_status = 'green' if n_countries_active >= n_countries_plan else ('amber' if n_countries_active >= n_countries_plan * 0.8 else 'red')
    if n_countries_plan > 0 and n_countries_active > n_countries_plan:
        cov_detail = f'Target exceeded (+{n_countries_active - n_countries_plan} over plan)'
        cov_value = f'{n_countries_active} of {n_countries_plan} planned'
    elif n_countries_plan > 0:
        cov_pct = n_countries_active / n_countries_plan * 100
        cov_detail = f'{n_countries_plan - n_countries_active} countries pending'
        cov_value = f'{n_countries_active}/{n_countries_plan} countries ({cov_pct:.0f}%)'
    else:
        cov_detail = f'{n_countries_active} countries active'
        cov_value = f'{n_countries_active} countries'
    cards.append({
        'title': 'COUNTRY ACTIVATION COVERAGE',
        'value': cov_value,
        'detail': cov_detail,
        'target': '100% countries activated',
        'status': cov_status
    })

    # 7. HA Approvals Coverage
    if ha_ec and ha_ec.get('ha_total', 0) > 0:
        ha_pct = ha_ec['ha_done'] / ha_ec['ha_total'] * 100
        ha_status = 'green' if ha_pct >= 80 else ('amber' if ha_pct >= 50 else 'red')
        cards.append({
            'title': 'HA APPROVALS COVERAGE',
            'value': f'{ha_ec["ha_done"]}/{ha_ec["ha_total"]} ({ha_pct:.0f}%)',
            'detail': 'On track' if ha_pct >= 80 else f'{ha_ec["ha_overdue"]} overdue',
            'target': '100% HA approvals',
            'status': ha_status
        })

    # 8. EC/IRB Approvals Coverage
    if ha_ec and ha_ec.get('ec_total', 0) > 0:
        ec_pct = ha_ec['ec_done'] / ha_ec['ec_total'] * 100
        ec_status = 'green' if ec_pct >= 80 else ('amber' if ec_pct >= 50 else 'red')
        cards.append({
            'title': 'EC/IRB APPROVALS COVERAGE',
            'value': f'{ha_ec["ec_done"]}/{ha_ec["ec_total"]} ({ec_pct:.0f}%)',
            'detail': 'On track' if ec_pct >= 80 else f'{ha_ec["ec_overdue"]} overdue',
            'target': '100% EC/IRB approvals',
            'status': ec_status
        })

    return cards

# ----------------------------------------------------------------
# 4. NARRATIVE GENERATION
# ----------------------------------------------------------------
def generate_executive_narrative(kpis, country_df, milestone_df, risk_df):
    """Generate rich interpretive executive summary narrative."""
    lines = []
    enr_act = kpis.get('s_tot_enrolled_act', 0)
    enr_pln = kpis.get('s_tot_enrolled_pln', 0)
    sfr_act = kpis.get('s_screen_failure_rate_act', 0)

    # Enrollment status
    if enr_act >= enr_pln and enr_pln > 0:
        top_countries = country_df.nlargest(3, 'enrolled_act')['country_name'].tolist()
        lines.append(f'Recruitment pace is currently protected by strong contributions from {", ".join(top_countries[:-1])}, and {top_countries[-1]}.' if len(top_countries) >= 2 else f'Recruitment is on track led by {top_countries[0]}.')
    elif enr_pln > 0:
        gap = ((enr_pln - enr_act) / enr_pln) * 100
        lines.append(f'Enrollment is {gap:.0f}% behind plan-to-date ({int(enr_act)} actual vs {int(enr_pln)} planned). Immediate action needed to close the gap.')
    else:
        lines.append(f'Study enrollment data shows {int(enr_act)} patients enrolled.')

    # Screen failure assessment
    if sfr_act >= 40:
        high_sfr = country_df[country_df['sfr_act'] >= 40].nlargest(3, 'sfr_act')['country_name'].tolist()
        sfr_countries = ', '.join(high_sfr) if high_sfr else 'multiple countries'
        lines.append(f'\U0001f534 High screen failures ({sfr_act:.0f}%) are suppressing the screening funnel and will cap enrollment even where sites are active (priority focus: {sfr_countries}).')
    elif sfr_act >= 30:
        lines.append(f'\U0001f7e0 Screen failure rate ({sfr_act:.0f}%) is elevated. Monitor trend and consider pre-screening optimizations.')

    # Site activation assessment (use study-level KPIs, not sparse country sums)
    total_active = int(kpis.get('s_no_sites_set_up', country_df['sites_active'].sum()))
    total_planned = int(kpis.get('s_no_of_sites_pln', 0)) or int(country_df['sites_planned'].sum())
    if total_planned > 0:
        act_pct = total_active / total_planned * 100
        if total_active > total_planned:
            lines.append(f'Site activation target exceeded: {total_active} sites active vs {total_planned} planned (+{total_active - total_planned} additional).')
        elif act_pct >= 90:
            lines.append(f'Site activation is on track ({total_active}/{total_planned} sites, {act_pct:.0f}%).')
        else:
            site_gaps = country_df[country_df['sites_active'] < country_df['sites_planned']].nlargest(3, 'sites_planned')['country_name'].tolist()
            gap_names = ', '.join(site_gaps) if site_gaps else 'several countries'
            lines.append(f'Activation is at {act_pct:.0f}% ({total_active}/{total_planned} sites), but gaps remain in {gap_names}.')

    # Post-SIV inactivity
    zero_screen = country_df[(country_df['sites_active'] > 0) & (country_df['screened_act'] == 0)]
    if len(zero_screen) > 0:
        inactive_names = zero_screen['country_name'].tolist()
        names_str = ', '.join(inactive_names[:4]) + (f' (+{len(inactive_names)-4} more)' if len(inactive_names) > 4 else '')
        lines.append(f'Post-SIV inactivity detected in {len(zero_screen)} countries with active sites but 0 screened: {names_str}. Prioritize re-activation with CRA-led screening kick-off.')

    # Milestone health
    overdue = milestone_df[milestone_df['milestone_progress_status'] == 'Overdue']
    if len(overdue) > 0:
        top_overdue = overdue.nlargest(2, 'days_overdue')
        ms_details = '; '.join(f'{r["event_name"]} ({int(r["days_overdue"])}d)' for _, r in top_overdue.iterrows() if pd.notna(r['days_overdue']))
        lines.append(f'\u23F1 {len(overdue)} overdue milestones. Most critical: {ms_details}.')

    # Risk summary
    if risk_df is not None and not risk_df.empty:
        n_crit = len(risk_df[risk_df['Severity'] == 'Critical'])
        n_high = len(risk_df[risk_df['Severity'] == 'High'])
        if n_crit > 0:
            lines.append(f'\U0001f534 {n_crit} critical risk{"s" if n_crit > 1 else ""} and {n_high} high risk{"s" if n_high > 1 else ""} require CTT escalation.')

    return '\n\n'.join(lines)

def generate_enrollment_narrative(country_df, kpis=None):
    """Generate enrollment challenges section narrative using study-level KPIs."""
    lines = []
    # Use study-level KPIs (accurate) instead of sparse country-level sums
    if kpis:
        total_act = int(kpis.get('s_tot_enrolled_act', 0))
        total_pln = int(kpis.get('s_tot_enrolled_pln', 0))
    else:
        total_act = int(country_df['enrolled_act'].sum())
        total_pln = int(country_df['enrolled_pln'].sum())

    if total_pln > 0 and total_act >= total_pln:
        over = total_act - total_pln
        lines.append(f'**Enrolled vs Plan-to-date: Target Met** \u2014 {total_act} actual vs {total_pln} planned (+{over} over plan).')
    elif total_pln > 0:
        gap_pct = (total_pln - total_act) / total_pln * 100
        lines.append(f'**Enrolled vs Plan-to-date: {gap_pct:.0f}% Behind** \u2014 {total_act} actual vs {total_pln} planned.')
    elif total_act > 0:
        lines.append(f'**Enrolled:** {total_act} patients (no plan-to-date target available).')

    # Identify dominant risk driver
    high_sfr_countries = country_df[country_df['sfr_act'] >= 40]
    zero_enroll_countries = country_df[(country_df['sites_active'] > 0) & (country_df['enrolled_act'] == 0)]

    if len(high_sfr_countries) > 0:
        names = ', '.join(high_sfr_countries.nlargest(3, 'sfr_act')['country_name'].tolist())
        lines.append(f'\U0001f534 Screening funnel underperformance is the dominant risk driver; prioritize eligibility clarification + pre-screening workflows in {names}.')

    if len(zero_enroll_countries) > 0:
        lines.append(f'\U0001f534 {len(zero_enroll_countries)} countries with active sites have 0 enrolled — immediate funnel check required.')

    return '\n\n'.join(lines)

def generate_milestone_narrative(milestone_df):
    """Generate milestone health narrative."""
    status_counts = milestone_df['milestone_progress_status'].value_counts()
    total = len(milestone_df)
    overdue = milestone_df[milestone_df['milestone_progress_status'] == 'Overdue']
    completed = status_counts.get('Completed', 0)
    pending = status_counts.get('Pending', 0)

    lines = []
    lines.append(f'**Milestone Portfolio:** {total} milestones tracked — {completed} completed, {pending} pending, {len(overdue)} overdue.')

    if len(overdue) > 0:
        # Group by category
        cats = overdue['event_category'].value_counts()
        cat_str = ', '.join(f'{c} ({n})' for c, n in cats.items())
        lines.append(f'**Overdue breakdown by category:** {cat_str}.')

        # Top 3 most overdue
        top3 = overdue.nlargest(3, 'days_overdue')
        for _, m in top3.iterrows():
            d = int(m['days_overdue']) if pd.notna(m['days_overdue']) else 0
            sev = 'Critical' if d >= 365 else 'High' if d >= 90 else 'Medium'
            lines.append(f'- **{m["event_name"]}** ({m["event_category"]}): {d} days overdue — {sev} priority')

        lines.append(f'\n**Recommended action:** Escalate the {len(overdue)} overdue milestones to CTT review. Prioritize milestones blocking downstream site activation and enrollment.')
    else:
        lines.append('All milestones are on track or completed. No escalation required.')

    return '\n'.join(lines)

# ----------------------------------------------------------------
# 5. EXECUTE ANALYSIS
# ----------------------------------------------------------------
print(f"Fetching cross-domain analysis data for {TEST_STUDY}...")

study_kpis = fetch_study_kpis(TEST_STUDY)
study_name = study_kpis.get('_study_name', '')
study_phase = study_kpis.get('_study_phase', '')
country_matrix = fetch_country_matrix(TEST_STUDY)
milestone_health = fetch_milestone_health(TEST_STUDY)
site_summary = fetch_site_summary(TEST_STUDY)
scenario_data = fetch_scenario_data(TEST_STUDY)
ha_ec_data = fetch_ha_ec_approvals(TEST_STUDY)

print(f"  Study: {study_name or '(name unavailable)'} | Phase: {study_phase or '(unavailable)'}")
print(f"  Study KPIs: {len(study_kpis)} metrics")
print(f"  Countries: {len(country_matrix)}")
print(f"  Milestones: {len(milestone_health)}")
print(f"  Sites: {len(site_summary)}")
print(f"  Scenarios: {len(scenario_data)}")
print(f"  HA Approvals: {ha_ec_data['ha_done']}/{ha_ec_data['ha_total']} | EC/IRB: {ha_ec_data['ec_done']}/{ha_ec_data['ec_total']}")

# Build cross-domain flags
cross_domain_flags = generate_cross_domain_flags(country_matrix, milestone_health)
print(f"  Cross-domain flags: {len(cross_domain_flags)} countries flagged")

# Build KPI scorecards
risk_df_for_cards = pd.DataFrame(results.get('CQ-RISK', {}).get('rows', []),
                                  columns=results.get('CQ-RISK', {}).get('columns', []))
kpi_cards = build_kpi_scorecards(study_kpis, country_matrix, milestone_health, ha_ec=ha_ec_data)
print(f"  KPI scorecards: {len(kpi_cards)} cards")

# Generate narratives
exec_narrative = generate_executive_narrative(study_kpis, country_matrix, milestone_health, risk_df_for_cards)
enroll_narrative = generate_enrollment_narrative(country_matrix, kpis=study_kpis)
milestone_narrative_text = generate_milestone_narrative(milestone_health)
regulatory_narrative = generate_regulatory_narrative(ha_ec_data)
post_siv = build_post_siv_analysis(country_matrix, site_summary)

# Enrollment status badge
enr_act = study_kpis.get('s_tot_enrolled_act', 0)
enr_pln = study_kpis.get('s_tot_enrolled_pln', 0)
enrollment_badge = 'Ahead' if enr_act >= enr_pln and enr_pln > 0 else ('Behind' if enr_pln > 0 else 'N/A')
enrollment_badge_color = '#28a745' if enrollment_badge == 'Ahead' else '#C0504D'

print(f"\n--- Executive Narrative Preview ---")
print(exec_narrative[:500])
print(f"\n--- Enrollment Badge: {enrollment_badge} ---")
print(f"\n--- KPI Cards ({len(kpi_cards)}) ---")
for card in kpi_cards:
    icon = '\U0001f7e2' if card['status'] == 'green' else '\U0001f7e0' if card['status'] == 'amber' else '\U0001f534'
    print(f"  {icon} {card['title']}: {card['value']} | {card['detail']}")
print(f"\n--- HA/EC Approvals ---")
print(f"  HA: {ha_ec_data['ha_done']}/{ha_ec_data['ha_total']} done, {ha_ec_data['ha_overdue']} overdue")
print(f"  EC: {ha_ec_data['ec_done']}/{ha_ec_data['ec_total']} done, {ha_ec_data['ec_overdue']} overdue")
print(f"\n--- Post-SIV Inactivity: {post_siv['total_inactive']} countries ---")
print(f"\n--- Country Flags ({len(cross_domain_flags)}) ---")
for f in cross_domain_flags[:8]:
    print(f"  [{f['severity']}] {f['country']}: {'; '.join(f['flags'][:2])}")
    print(f"           Action: {'; '.join(f['actions'][:2])}")

# COMMAND ----------

# DBTITLE 1,Generate HTML Reports with Charts
# ============================================================
# Generate enhanced HTML reports with narratives, KPI cards,
# cross-domain flags, and charts (matches clinical ops style)
# ============================================================
import html as html_mod
import re, io, base64, os
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

today = datetime.now().strftime("%Y-%m-%d")

# ---- Novartis Logo (official SVG) ----
NOVARTIS_LOGO_URI = "https://upload.wikimedia.org/wikipedia/commons/6/68/Novartis-Logo.svg"

# ---- Chart helpers ----
def fig_to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=130, bbox_inches='tight', facecolor='white')
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode('utf-8')
    plt.close(fig)
    return f'<img src="data:image/png;base64,{b64}" style="max-width:100%;margin:10px 0;"/>'

def chart_country_enrollment_grouped(cm):
    """Grouped bar: enrolled actual vs planned by country."""
    df = cm[cm['enrolled_pln'] > 0].sort_values('enrolled_act', ascending=True).tail(15)
    if df.empty:
        return ""
    fig, ax = plt.subplots(figsize=(8, max(3, len(df)*0.5)))
    y = range(len(df))
    ax.barh([i-0.2 for i in y], df['enrolled_act'], height=0.35, label='Actual', color='#4472C4')
    ax.barh([i+0.2 for i in y], df['enrolled_pln'], height=0.35, label='Planned', color='#C0504D', alpha=0.6)
    ax.set_yticks(list(y))
    ax.set_yticklabels(df['country_name'], fontsize=9)
    ax.set_xlabel('Patients')
    ax.set_title(f'Enrolled Actual vs Planned by Country \u2014 {TEST_STUDY}', fontsize=11, fontweight='bold')
    ax.legend(loc='lower right')
    ax.grid(axis='x', alpha=0.3)
    for s in ['top','right']: ax.spines[s].set_visible(False)
    return fig_to_base64(fig)

def chart_milestone_donut(mh):
    """Donut chart of milestone status distribution."""
    counts = mh['milestone_progress_status'].value_counts()
    color_map = {'Completed':'#70AD47','Pending':'#FFC000','Overdue':'#C0504D'}
    colors = [color_map.get(s,'#9999CC') for s in counts.index]
    fig, ax = plt.subplots(figsize=(5,4))
    wedges, texts, autos = ax.pie(counts, labels=counts.index, colors=colors,
        autopct='%1.0f%%', startangle=90, pctdistance=0.75, wedgeprops=dict(width=0.4))
    for t in autos: t.set_fontsize(10); t.set_fontweight('bold')
    ax.set_title(f'Milestone Status ({len(mh)} total)', fontsize=11, fontweight='bold')
    return fig_to_base64(fig)

def chart_risk_stacked(risk_data):
    """Stacked bar of risk types by severity."""
    if not risk_data.get('rows'): return ''
    df = pd.DataFrame(risk_data['rows'], columns=risk_data['columns'])
    pivot = df.groupby(['Risk Type','Severity']).size().unstack(fill_value=0)
    order = [s for s in ['Critical','High','Medium','Low'] if s in pivot.columns]
    pivot = pivot.reindex(columns=order, fill_value=0)
    sev_c = {'Critical':'#8B0000','High':'#C0504D','Medium':'#E6A817','Low':'#70AD47'}
    fig, ax = plt.subplots(figsize=(8, max(3, len(pivot)*0.6)))
    left = [0]*len(pivot)
    for sev in order:
        v = pivot[sev].values
        ax.barh(pivot.index, v, left=left, color=sev_c[sev], label=sev, height=0.5)
        left = [l+vv for l,vv in zip(left,v)]
    ax.set_xlabel('Number of Risks')
    ax.set_title(f'Risk Distribution \u2014 {TEST_STUDY}', fontsize=11, fontweight='bold')
    ax.legend(loc='lower right')
    ax.grid(axis='x', alpha=0.3)
    for s in ['top','right']: ax.spines[s].set_visible(False)
    return fig_to_base64(fig)

def chart_overdue_bars(mh):
    """Bar chart of overdue milestones by days overdue."""
    od = mh[mh['milestone_progress_status']=='Overdue'].copy()
    od['days_overdue'] = pd.to_numeric(od['days_overdue'], errors='coerce')
    od = od.dropna(subset=['days_overdue']).sort_values('days_overdue').tail(15)
    if od.empty: return ''
    fig, ax = plt.subplots(figsize=(8, max(3, len(od)*0.45)))
    colors = ['#8B0000' if d>=365 else '#C0504D' if d>=90 else '#FFC000' for d in od['days_overdue']]
    ax.barh(od['event_name'], od['days_overdue'], color=colors, height=0.6)
    ax.set_xlabel('Days Overdue')
    ax.set_title('Most Overdue Milestones', fontsize=11, fontweight='bold')
    ax.grid(axis='x', alpha=0.3)
    for s in ['top','right']: ax.spines[s].set_visible(False)
    return fig_to_base64(fig)

# ---- Narrative formatter ----
def severity_chip(severity):
    sev = (severity or '').strip().lower()
    label_map = {
        'critical': ('⛔', 'Critical', 'chip-critical'),
        'high': ('▲', 'High', 'chip-high'),
        'medium': ('●', 'Medium', 'chip-medium'),
        'low': ('✓', 'Low', 'chip-low'),
    }
    icon, label, cls = label_map.get(sev, ('•', severity or 'Info', 'chip-medium'))
    return f'<span class="sev-chip {cls}">{icon} {html_mod.escape(label)}</span>'


def format_inline_markup(text):
    txt = html_mod.escape(text)
    txt = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', txt)
    txt = re.sub(
        r'\[(Critical|High|Medium|Low)\]',
        lambda m: severity_chip(m.group(1)),
        txt,
    )
    return txt


def format_narrative(text):
    if not text:
        return ''
    lines = text.split('\n')
    lines = [l for l in lines if not re.match(r'^(Would you|Do you want|Should I|Shall I|Can I|Let me know if)', l.strip())]
    t = '\n'.join(lines).strip()
    if not t:
        return ''

    paragraphs = [p.strip() for p in re.split(r'\n\s*\n', t[:5000]) if p.strip()]
    blocks = []
    for para in paragraphs:
        para_lines = [ln.strip() for ln in para.split('\n') if ln.strip()]
        if para_lines and all(ln.startswith('- ') for ln in para_lines):
            items = ''.join(f'<li>{format_inline_markup(ln[2:])}</li>' for ln in para_lines)
            blocks.append(f'<ul class="compact-list">{items}</ul>')
        else:
            inline = '<br/>'.join(format_inline_markup(ln) for ln in para_lines)
            blocks.append(f'<p>{inline}</p>')
    return f'<div class="narrative">{"".join(blocks)}</div>'

# ---- CSS (enhanced) ----
CSS = """
<style>
  @page { size: A4; margin: 15mm; }
  @media print { body { margin: 0; } .no-print, .page-break-avoid { break-inside: avoid; } }
  body { font-family: 'Segoe UI', Helvetica, Arial, sans-serif; max-width: 960px; margin: 30px auto; color: #222; font-size: 13px; line-height: 1.5; }
  .report-header { display: flex; align-items: center; justify-content: space-between; border-bottom: 3px solid #0460A9; padding-bottom: 10px; margin-bottom: 4px; }
  .report-header img { height: 39px; }
  h1 { font-size: 22px; color: #1a3a5c; margin: 0; padding: 0; border: none; }
  .meta { color: #555; font-size: 12px; margin-bottom: 20px; padding: 6px 0; border-bottom: 1px solid #ddd; }
  .meta .badge { background: #28a745; color: white; padding: 2px 8px; border-radius: 4px; font-size: 11px; }
  .section-count { background: #0460A9; color: white; padding: 1px 7px; border-radius: 3px; font-size: 11px; margin-left: 6px; }
  h2 { font-size: 15px; background: linear-gradient(135deg, #e8eaf6 0%, #c5cae9 100%); padding: 8px 12px; margin-top: 28px; border-left: 4px solid #3f51b5; border-radius: 0 4px 4px 0; }
  /* KPI Cards */
  .kpi-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin: 16px 0; }
  .kpi-card { border: 1px solid #ddd; border-radius: 8px; padding: 14px 16px; background: white; position: relative; overflow: hidden; }
  .kpi-card .kpi-bar { position: absolute; top: 0; left: 0; width: 4px; height: 100%; }
  .kpi-card .kpi-title { font-size: 10px; font-weight: 600; color: #666; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
  .kpi-card .kpi-value { font-size: 15px; font-weight: 700; color: #1a3a5c; margin-bottom: 4px; }
  .kpi-card .kpi-detail { font-size: 11px; color: #555; margin-bottom: 2px; }
  .kpi-card .kpi-target { font-size: 10px; color: #888; font-style: italic; }
  .kpi-green .kpi-bar { background: #28a745; }
  .kpi-amber .kpi-bar { background: #E6A817; }
  .kpi-red .kpi-bar { background: #C0504D; }
  .kpi-green { border-color: #28a74540; }
  .kpi-amber { border-color: #E6A81740; }
  .kpi-red { border-color: #C0504D40; }
  /* Tables */
  table { border-collapse: collapse; width: 100%; font-size: 11px; margin: 10px 0; }
  th { background: #37474f; color: white; text-align: left; padding: 6px 10px; font-size: 11px; }
  td { padding: 5px 10px; border-bottom: 1px solid #e0e0e0; }
  tr:nth-child(even) { background: #fafafa; }
  tr:hover { background: #e8eaf6; }
  .status-overdue, .sev-critical { color: #8B0000; font-weight: bold; }
  .status-ok, .sev-low { color: #28a745; font-weight: bold; }
  .status-pending, .sev-medium { color: #e6a817; font-weight: bold; }
  .sev-high { color: #C0504D; font-weight: bold; }
  /* Narrative */
  .narrative { font-size: 13px; line-height: 1.55; margin: 8px 0 14px 0; padding: 12px 14px; background: #f8f9fa; border-left: 3px solid #90a4ae; border-radius: 0 4px 4px 0; }
  .narrative p { margin: 0 0 8px 0; }
  .narrative p:last-child { margin-bottom: 0; }
  .narrative ul { margin: 4px 0; padding-left: 20px; }
  .narrative ul.compact-list { margin: 2px 0 0 18px; padding-left: 0; }
  .narrative li { margin: 3px 0; }
  .narrative ul.compact-list li { margin: 4px 0; line-height: 1.4; }
  .narrative strong { color: #1a3a5c; }
  .narrative-exec { background: #e8f5e9; border-left-color: #43a047; }
  .narrative-warn { background: #fff3e0; border-left-color: #e65100; }
  .sev-chip { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 999px; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; border: 1px solid transparent; vertical-align: middle; }
  .chip-critical { background: #fdecea; color: #9b1c1c; border-color: #f5c2c0; }
  .chip-high { background: #fff1eb; color: #b54708; border-color: #f7c59f; }
  .chip-medium { background: #fff8e1; color: #8a5a00; border-color: #ffe082; }
  .chip-low { background: #e8f5e9; color: #1b5e20; border-color: #a5d6a7; }
  .insight-group { margin: 10px 0 12px 0; padding: 10px 12px; background: #fbfcfe; border: 1px solid #e2e8f0; border-radius: 8px; }
  .insight-title { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; font-size: 12px; font-weight: 700; color: #1a3a5c; margin-bottom: 6px; }
  .action-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; margin: 10px 0 14px 0; }
  .action-card { display: flex; gap: 10px; align-items: flex-start; padding: 10px 12px; border: 1px solid #d9e2ec; border-radius: 8px; background: white; }
  .action-icon { font-size: 16px; line-height: 1; margin-top: 2px; }
  .action-title { font-size: 12px; font-weight: 700; color: #1a3a5c; margin-bottom: 3px; }
  .action-body { font-size: 11px; color: #4d5b6a; line-height: 1.4; }
  .action-critical { border-left: 4px solid #8B0000; }
  .action-high { border-left: 4px solid #C0504D; }
  .action-medium { border-left: 4px solid #E6A817; }
  .action-low { border-left: 4px solid #28a745; }
  .muted { color: #888; font-size: 11px; font-style: italic; }
  .chart-container { text-align: center; margin: 12px 0; }
  /* Risk */
  .risk-summary-box { display: flex; gap: 12px; flex-wrap: wrap; margin: 12px 0; }
  .risk-count { text-align: center; padding: 10px 18px; border-radius: 6px; font-size: 13px; min-width: 90px; }
  .risk-count .num { font-size: 24px; font-weight: bold; display: block; }
  /* Country Action Table */
  .action-table td:first-child { font-weight: 600; white-space: nowrap; }
  .action-table .flag-cell { font-size: 12px; }
  .action-table .action-cell { font-size: 11px; color: #1a3a5c; font-style: italic; }
  /* Section divider */
  .section-divider { border: none; border-top: 1px solid #e0e0e0; margin: 24px 0 8px 0; }
  /* Data gap notice */
  .data-gap { background: #fff8e1; border: 1px solid #ffe082; border-radius: 4px; padding: 8px 12px; font-size: 11px; color: #795548; margin: 10px 0; }
  /* Enrollment Badge */
  .enrollment-badge { display: inline-block; padding: 3px 12px; border-radius: 4px; font-weight: bold; font-size: 12px; color: white; margin: 0 6px; vertical-align: middle; }
  .badge-ahead { background: #28a745; }
  .badge-behind { background: #C0504D; }
  /* TOC */
  .toc { background: #f5f7fa; border: 1px solid #e0e0e0; border-radius: 6px; padding: 12px 18px; margin: 10px 0 20px 0; font-size: 12px; }
  .toc-title { font-weight: 600; color: #1a3a5c; font-size: 13px; margin-bottom: 6px; }
  .toc a { color: #0460A9; text-decoration: none; margin-right: 14px; }
  .toc a:hover { text-decoration: underline; }
  /* Summary strip */
  .summary-strip { display: flex; gap: 8px; flex-wrap: wrap; margin: 12px 0; }
  .summary-pill { background: #f0f4f8; border: 1px solid #c5cae9; border-radius: 20px; padding: 4px 12px; font-size: 11px; font-weight: 600; color: #1a3a5c; }
  .pill-red { background: #fce4ec; border-color: #ef9a9a; color: #b71c1c; }
  .pill-green { background: #e8f5e9; border-color: #a5d6a7; color: #1b5e20; }
  .pill-amber { background: #fff8e1; border-color: #ffe082; color: #e65100; }
  /* Study metadata */
  .study-meta { font-size: 11px; color: #666; margin-top: 2px; }
  /* Post-SIV table */
  .postsiv-table td:first-child { font-weight: 600; }
  /* Print */
  @media print { @page { margin-top: 15mm; } .toc { break-inside: avoid; } h2 { break-after: avoid; } }
</style>
"""

# ---- HTML builders ----
def build_kpi_cards_html(cards):
    h = '<div class="kpi-grid">'
    for c in cards:
        cls = f'kpi-{c["status"]}'
        h += f'''<div class="kpi-card {cls}">
          <div class="kpi-bar"></div>
          <div class="kpi-title">{html_mod.escape(c['title'])}</div>
          <div class="kpi-value">{html_mod.escape(c['value'])}</div>
          <div class="kpi-detail">{html_mod.escape(c['detail'])}</div>
          <div class="kpi-target">Target: {html_mod.escape(c['target'])}</div>
        </div>'''
    h += '</div>'
    return h

def build_country_action_table(flags):
    if not flags: return '<p class="muted">No country-level flags detected.</p>'
    h = '<table class="action-table"><thead><tr><th>Country</th><th>Enrollment Status</th><th>Cross-Domain Flags</th><th>Immediate Action</th></tr></thead><tbody>'
    for f in flags:
        sev_cls = f'sev-{f["severity"].lower()}'
        flag_text = '<br/>'.join(html_mod.escape(fl) for fl in f['flags'])
        action_text = '<br/>'.join(html_mod.escape(a) for a in f['actions']) if f['actions'] else '<span class="muted">Monitor</span>'
        h += f'<tr><td class="{sev_cls}">{html_mod.escape(f["country"])}</td>'
        # Get enrollment numbers from country_matrix
        cm_row = country_matrix[country_matrix['country_name'] == f['country']]
        if not cm_row.empty:
            r = cm_row.iloc[0]
            enr = f'{int(r["enrolled_act"])}/{int(r["enrolled_pln"])} enrolled' if r['enrolled_pln'] > 0 else f'{int(r["enrolled_act"])} enrolled'
            sites = f'{int(r["sites_active"])} sites active'
            h += f'<td>{html_mod.escape(enr)}<br/><span class="muted">{sites}</span></td>'
        else:
            h += '<td>\u2014</td>'
        h += f'<td class="flag-cell">{flag_text}</td><td class="action-cell">{action_text}</td></tr>'
    h += '</tbody></table>'
    return h

def build_risk_summary_html(risk_data):
    if not risk_data.get('rows'): return '<p class="muted">No risks identified</p>'
    df = pd.DataFrame(risk_data['rows'], columns=risk_data['columns'])
    sev_counts = df['Severity'].value_counts()
    sev_c = {'Critical':'#8B0000','High':'#C0504D','Medium':'#E6A817','Low':'#70AD47'}
    h = '<div class="risk-summary-box">'
    for sev in ['Critical','High','Medium','Low']:
        cnt = sev_counts.get(sev,0)
        bg = sev_c.get(sev,'#999')
        h += f'<div class="risk-count" style="background:{bg}20;border:2px solid {bg}"><span class="num" style="color:{bg}">{cnt}</span>{sev}</div>'
    h += '</div>'
    return h


def build_risk_highlights_html(rdf, top_critical=5, top_high=3):
    if rdf.empty:
        return '<p class="muted">No risk highlights available.</p>'

    n_crit = len(rdf[rdf['Severity'] == 'Critical'])
    n_high = len(rdf[rdf['Severity'] == 'High'])
    n_med = len(rdf[rdf['Severity'] == 'Medium'])
    n_low = len(rdf[rdf['Severity'] == 'Low'])
    type_summary = ', '.join(f'{n} {t}' for t, n in rdf['Risk Type'].value_counts().items())

    summary_text = (
        f'<p><strong>Risk Summary:</strong> {len(rdf)} risks across {rdf["Risk Type"].nunique()} categories '
        f'({type_summary}).'
    )
    if n_crit > 0:
        summary_text += f' <strong>{n_crit} Critical</strong> require immediate CTT escalation.'
    if n_high > 0:
        summary_text += f' <strong>{n_high} High</strong> need action within 2 weeks.'
    if n_med + n_low > 0:
        summary_text += f' {n_med + n_low} Medium/Low should be monitored on a regular cadence.'
    summary_text += '</p>'

    sections = [f'<div class="insight-group"><div class="insight-title"><strong>Risk Summary</strong> {len(rdf)} risks across {rdf["Risk Type"].nunique()} categories</div>{summary_text}</div>']

    urgency_map = {
        'Critical': 'These items require immediate Clinical Trial Team (CTT) escalation and an emergency meeting to assign corrective actions with named owners.',
        'High': 'These items need action within two weeks. Review at next CTT meeting and assign recovery owners.',
    }
    for severity, limit, label in [('Critical', top_critical, 'Immediate CTT escalation required'), ('High', top_high, 'Action required within 2 weeks')]:
        subset = rdf[rdf['Severity'] == severity].head(limit)
        if subset.empty:
            continue
        items = ''.join(
            f'<li><strong>{html_mod.escape(r["Risk Type"])}:</strong> {html_mod.escape(r["Detail"])} '
            f'\u2014 {html_mod.escape(r["Metric"])}. '
            f'<em>Action: {html_mod.escape(r["Recommended Action"])}</em></li>'
            for _, r in subset.iterrows()
        )
        urgency_note = urgency_map.get(severity, '')
        remaining = len(rdf[rdf['Severity'] == severity]) - limit
        more_text = f'<p class="muted">... and {remaining} more {severity.lower()} risks. See full risk table below.</p>' if remaining > 0 else ''
        sections.append(
            f'<div class="insight-group">'
            f'<div class="insight-title">{severity_chip(severity)} {len(rdf[rdf["Severity"] == severity])} {severity} \u2014 {label}</div>'
            f'<p class="muted" style="margin:0 0 6px 0;">{urgency_note}</p>'
            f'<ul class="compact-list">{items}</ul>'
            f'{more_text}'
            f'</div>'
        )
    return ''.join(sections)


def build_action_recommendations_html(rdf):
    if rdf.empty:
        return ''
    actions = {
        'Overdue Milestone': (
            '\u23f1', 'action-critical',
            'Review resource allocation and timeline dependencies across data management, medical writing, and biostatistics teams. '
            'Prioritize milestones that are blocking downstream activities such as database lock, CSR publication, or regulatory submissions. '
            'Schedule an emergency CTT meeting to assign named owners to each overdue milestone and establish weekly progress tracking cadence. '
            'For milestones overdue >365 days, escalate to the Study Steering Committee and evaluate whether protocol amendments or '
            'additional vendor support are needed. Create individual recovery plans with realistic timelines and contingency actions.'
        ),
        'Enrollment Gap': (
            '\u2198', 'action-high',
            'Evaluate site-level enrollment performance to identify underperforming sites and consider reallocation of patient targets '
            'to higher-performing sites or geographies. Review protocol eligibility criteria with the medical team to determine if '
            'amendments could broaden the eligible patient population without compromising study integrity. '
            'Consider activating additional countries or sites in regions with higher disease prevalence. '
            'Implement targeted patient recruitment campaigns and strengthen referral networks. '
            'Track weekly enrollment run-rate against plan and escalate to CTT if gap widens.'
        ),
        'Screen Failure Alert': (
            '\u25d4', 'action-medium',
            'Conduct a root-cause analysis of screen failures by reviewing the most common exclusion criteria triggered. '
            'Assess whether protocol complexity, narrow eligibility windows, or patient population mismatch are driving elevated SFR. '
            'Implement pre-screening tools and checklists at high-SFR sites. Provide additional investigator training on inclusion/exclusion criteria. '
            'Consider protocol amendments if specific criteria are responsible for >50% of screen failures. '
            'Monitor SFR trend monthly and compare across sites to identify best practices from low-SFR sites.'
        ),
        'Site Activation Delay': (
            '\u2301', 'action-high',
            'Expedite Health Authority (HA) and Ethics Committee (EC/IRB) submissions for countries with pending regulatory approvals. '
            'Allocate dedicated CRA resources to sites with outstanding activation tasks. '
            'Identify and resolve site-specific blockers such as contract negotiations, budget approvals, or IRB feedback. '
            'For countries with systemic regulatory delays, engage local regulatory affairs teams and consider parallel submission strategies. '
            'Track site activation milestones (regulatory submission, approval, SIV scheduling) on a weekly basis.'
        ),
    }
    counts = rdf['Risk Type'].value_counts()
    h = '<div class="action-grid">'
    for rtype, n in counts.items():
        icon, cls, body = actions.get(rtype, ('\u2022', 'action-low', 'Monitor and escalate as needed.'))
        h += (
            f'<div class="action-card {cls}">'
            f'<div class="action-icon">{icon}</div>'
            f'<div><div class="action-title">{html_mod.escape(rtype)} ({n})</div>'
            f'<div class="action-body">{html_mod.escape(body)}</div></div></div>'
        )
    h += '</div>'
    return h


def build_milestone_overview_cards(mh):
    if mh.empty:
        return '<p class="muted">No milestone data returned.</p>'
    overdue_df = mh[mh['milestone_progress_status'] == 'Overdue'].copy()
    overdue_df['days_overdue'] = pd.to_numeric(overdue_df['days_overdue'], errors='coerce')
    top_overdue = overdue_df.sort_values('days_overdue', ascending=False).head(1)
    top_name = top_overdue.iloc[0]['event_name'] if not top_overdue.empty else 'None'
    top_days = int(top_overdue.iloc[0]['days_overdue']) if not top_overdue.empty and pd.notna(top_overdue.iloc[0]['days_overdue']) else 0
    n_total = len(mh)
    n_completed = len(mh[mh['milestone_progress_status'] == 'Completed'])
    n_pending = len(mh[mh['milestone_progress_status'] == 'Pending'])
    n_overdue = len(overdue_df)
    cards = [
        {
            'title': 'Milestones Tracked',
            'value': f'{n_total} total milestones',
            'detail': f'{n_completed} completed, {n_pending} pending, {n_overdue} overdue',
            'target': 'Target: complete planned milestones to baseline',
            'status': 'green' if n_overdue == 0 else 'amber' if n_overdue <= 5 else 'red'
        },
        {
            'title': 'Completed Milestones',
            'value': f'{n_completed} completed',
            'detail': 'Milestones already delivered',
            'target': 'Target: maximize completed milestones',
            'status': 'green'
        },
        {
            'title': 'Pending Milestones',
            'value': f'{n_pending} pending',
            'detail': 'Upcoming milestones requiring tracking',
            'target': 'Target: convert pending to completed on schedule',
            'status': 'amber' if n_pending > 0 else 'green'
        },
        {
            'title': 'Overdue Milestones',
            'value': f'{n_overdue} overdue milestones',
            'detail': f'Top overdue: {top_name}' + (f' ({top_days}d)' if top_days else ''),
            'target': 'Target: 0 overdue milestones',
            'status': 'green' if n_overdue == 0 else 'amber' if n_overdue <= 5 else 'red'
        },
    ]
    return build_kpi_cards_html(cards)


def build_risk_table_html(risk_data, max_rows=30):
    if not risk_data.get('rows'): return ''
    cols = risk_data['columns']; rows = risk_data['rows'][:max_rows]
    h = '<table><thead><tr>' + ''.join(f'<th>{html_mod.escape(str(c))}</th>' for c in cols) + '</tr></thead><tbody>'
    for row in rows:
        h += '<tr>'
        for i, val in enumerate(row):
            cell = str(val if val is not None else '\u2014')
            style = f' class="sev-{cell.lower()}"' if cols[i] == 'Severity' else ''
            h += f'<td{style}>{html_mod.escape(cell)}</td>'
        h += '</tr>'
    h += '</tbody></table>'
    if len(risk_data['rows']) > max_rows:
        h += f'<p class="muted">... and {len(risk_data["rows"]) - max_rows} more rows</p>'
    return h

def make_table_html(columns, rows, max_rows=30):
    if not columns or not rows: return '<p class="muted">No data returned</p>'
    n = min(len(columns), 8)
    h = '<table><thead><tr>' + ''.join(f'<th>{html_mod.escape(str(c))}</th>' for c in columns[:n]) + '</tr></thead><tbody>'
    for row in rows[:max_rows]:
        h += '<tr>'
        for i, val in enumerate(row[:n]):
            cell = str(val if val is not None else '\u2014')
            cn = columns[i].lower() if i < len(columns) else ''
            st = ''
            if 'status' in cn:
                if 'Overdue' in cell: st = ' class="status-overdue"'
                elif 'Completed' in cell: st = ' class="status-ok"'
                elif 'Pending' in cell: st = ' class="status-pending"'
            h += f'<td{st}>{html_mod.escape(cell)}</td>'
        h += '</tr>'
    h += '</tbody></table>'
    if len(rows) > max_rows: h += f'<p class="muted">... and {len(rows)-max_rows} more rows</p>'
    return h

def build_milestone_table(mh, max_rows=50):
    cols = ['event_name','event_category','milestone_progress_status','actual_date','scheduled_date','days_overdue']
    present = [c for c in cols if c in mh.columns]
    df = mh[present].head(max_rows)
    h = '<table><thead><tr>' + ''.join(f'<th>{c.replace("_"," ").title()}</th>' for c in present) + '</tr></thead><tbody>'
    for _, row in df.iterrows():
        h += '<tr>'
        for c in present:
            val = str(row[c]) if pd.notna(row[c]) else '\u2014'
            st = ''
            if c == 'milestone_progress_status':
                if 'Overdue' in val: st = ' class="status-overdue"'
                elif 'Completed' in val: st = ' class="status-ok"'
                elif 'Pending' in val: st = ' class="status-pending"'
            h += f'<td{st}>{html_mod.escape(val)}</td>'
        h += '</tr>'
    h += '</tbody></table>'
    if len(mh) > max_rows: h += f'<p class="muted">... and {len(mh)-max_rows} more rows</p>'
    return h

def build_scenario_table(sd):
    if sd.empty: return '<p class="muted">No scenario data available</p>'
    h = '<table><thead><tr><th>Scenario</th><th>Status</th><th>Screening Rate</th><th>Randomization Rate</th></tr></thead><tbody>'
    for _, r in sd.iterrows():
        h += f'<tr><td>{html_mod.escape(str(r["scenario_name"]))}</td><td>{html_mod.escape(str(r["scenario_status"]))}</td><td>{r["screening_rate"]:.2f}</td><td>{r["randomization_rate"]:.2f}</td></tr>'
    h += '</tbody></table>'
    return h

def build_country_enrollment_table(cm):
    h = '<table><thead><tr><th>Country</th><th>Enrolled Act</th><th>Enrolled Pln</th><th>Screened Act</th><th>SFR %</th><th>Sites Active</th><th>Sites Planned</th></tr></thead><tbody>'
    for _, r in cm.iterrows():
        sfr_cls = ' class="status-overdue"' if r['sfr_act'] >= 40 else ' class="status-pending"' if r['sfr_act'] >= 30 else ''
        h += f'<tr><td><strong>{html_mod.escape(str(r["country_name"]))}</strong></td><td>{int(r["enrolled_act"])}</td><td>{int(r["enrolled_pln"])}</td><td>{int(r["screened_act"])}</td><td{sfr_cls}>{r["sfr_act"]:.1f}%</td><td>{int(r["sites_active"])}</td><td>{int(r["sites_planned"])}</td></tr>'
    h += '</tbody></table>'
    return h

# ---- Build the two reports ----
n_sections_exec = 8
n_sections_mile = 6

# ==== EXECUTIVE SUMMARY ====
exec_html = CSS
study_title = f'{study_name} ({TEST_STUDY})' if study_name else TEST_STUDY
phase_str = f' &nbsp;|&nbsp; Phase: <strong>{study_phase}</strong>' if study_phase else ''
badge_cls = 'badge-ahead' if enrollment_badge == 'Ahead' else 'badge-behind'
exec_html += f'<div class="report-header"><div><h1>CLINICAL TRIAL STATUS REPORT</h1>'
exec_html += f'<div class="study-meta">{study_title}</div></div>'
exec_html += f'<img src="{NOVARTIS_LOGO_URI}" alt="Novartis"/></div>'
exec_html += f'<div class="meta">Study: <strong>{TEST_STUDY}</strong>{phase_str} &nbsp;|&nbsp; Generated: {today}, {datetime.now().strftime("%H:%M")} &nbsp;|&nbsp; '
exec_html += f'<span class="enrollment-badge {badge_cls}">Enrollment: {enrollment_badge}</span> '
exec_html += f'<span class="section-count">{n_sections_exec} sections</span></div>'

# TOC
exec_html += '<div class="toc"><div class="toc-title">Contents</div>'
for i, t in enumerate(['Overview','KPIs','Enrollment Challenges','Milestone Health',
                       'Regulatory Throughput','Post-SIV Analysis','Risks & Actions','Data Sources'], 1):
    exec_html += f'<a href="#es{i}">\u25B8 {t}</a>'
exec_html += '</div>'

# Summary strip
sfr_v = study_kpis.get('s_screen_failure_rate_act', 0)
n_overdue = len(milestone_health[milestone_health['milestone_progress_status']=='Overdue'])
exec_html += '<div class="summary-strip">'
exec_html += f'<span class="summary-pill {"pill-green" if enr_act >= enr_pln else "pill-red"}">{int(enr_act)}/{int(enr_pln)} Enrolled</span>'
exec_html += f'<span class="summary-pill {"pill-red" if sfr_v >= 40 else "pill-amber" if sfr_v >= 30 else "pill-green"}">SFR {sfr_v:.0f}%</span>'
exec_html += f'<span class="summary-pill {"pill-red" if n_overdue > 5 else "pill-amber" if n_overdue > 0 else "pill-green"}">{n_overdue} Overdue</span>'
exec_html += f'<span class="summary-pill">{len(country_matrix)} Countries</span>'
exec_html += f'<span class="summary-pill">{int(country_matrix["sites_active"].sum())} Sites Active</span>'
if ha_ec_data['ha_total'] > 0:
    exec_html += f'<span class="summary-pill">HA {ha_ec_data["ha_done"]}/{ha_ec_data["ha_total"]}</span>'
if ha_ec_data['ec_total'] > 0:
    exec_html += f'<span class="summary-pill">EC {ha_ec_data["ec_done"]}/{ha_ec_data["ec_total"]}</span>'
exec_html += '</div>'

# S1: Executive Summary Narrative
exec_html += '<h2 id="es1">\u25B6 OVERVIEW \u2014 Executive Summary</h2>'
exec_html += f'<div class="narrative narrative-exec">{html_mod.escape(exec_narrative)}</div>'

# S2: KPI Scorecards
exec_html += '<h2 id="es2">\u25B6 KEY PERFORMANCE INDICATORS</h2>'
kpi_intro = f'The following KPI dashboard provides an at-a-glance view of the key operational metrics for study {TEST_STUDY}. '
kpi_intro += 'Each card shows the current value against the study plan, color-coded by status: green (on track or target exceeded), amber (close to target), and red (significantly behind plan). '
kpi_intro += 'Targets are derived from the approved study plan in mv_study_recruitment_performance.'
exec_html += format_narrative(kpi_intro)
exec_html += build_kpi_cards_html(kpi_cards)

# S3: Enrollment Challenges (country flags + root-cause)
exec_html += '<h2 id="es3">\u25B6 ENROLLMENT CHALLENGES</h2>'
# Build a verbose enrollment narrative
enroll_verbose = enroll_narrative + '\n\n'
if len(cross_domain_flags) > 0:
    enroll_verbose += f'**Cross-domain analysis** identified {len(cross_domain_flags)} countries with flags requiring attention. '
    enroll_verbose += 'The table below cross-references enrollment gaps, screen failure rates, milestone delays, and site activation status '
    enroll_verbose += 'to provide an integrated view of country-level risk. Immediate actions are prioritized by severity.'
else:
    enroll_verbose += 'No critical cross-domain flags were detected at the country level. All countries with active sites show acceptable enrollment and screening performance relative to plan.'
enroll_verbose += '\n\n**Data Limitation:** Country-level planned enrollment values (sc_tot_enrolled_pln) are sparse in the source data \u2014 '
enroll_verbose += 'NULL for the majority of countries. The study-level totals from mv_study_recruitment_performance are more reliable for overall plan vs actual comparisons.'
exec_html += f'<div class="narrative narrative-warn">{html_mod.escape(enroll_verbose)}</div>'
exec_html += build_country_action_table(cross_domain_flags)
ce = chart_country_enrollment_grouped(country_matrix)
if ce: exec_html += f'<div class="chart-container">{ce}</div>'

# S4: Milestone Health
exec_html += '<h2 id="es4">\u25B6 MILESTONE HEALTH</h2>'
# Build verbose milestone narrative
ms_total = len(milestone_health)
ms_completed = len(milestone_health[milestone_health['milestone_progress_status']=='Completed'])
ms_pending = len(milestone_health[milestone_health['milestone_progress_status']=='Pending'])
ms_overdue_exec = len(milestone_health[milestone_health['milestone_progress_status']=='Overdue'])
overdue_exec = milestone_health[milestone_health['milestone_progress_status']=='Overdue'].copy()
overdue_exec['days_overdue'] = pd.to_numeric(overdue_exec['days_overdue'], errors='coerce')
top_overdue_exec = overdue_exec.sort_values('days_overdue', ascending=False).head(3)
mile_verbose = f'**Milestone Portfolio:** {ms_total} milestones tracked \u2014 {ms_completed} completed, {ms_pending} pending, {ms_overdue_exec} overdue.\n\n'
if ms_overdue_exec > 0:
    mile_verbose += '**Overdue breakdown by severity:**\n'
    for _, r in top_overdue_exec.iterrows():
        d = int(r['days_overdue']) if pd.notna(r['days_overdue']) else 0
        sev = 'Critical' if d >= 365 else 'High' if d >= 90 else 'Medium'
        cat = f' ({r["event_category"]})' if pd.notna(r.get('event_category')) and str(r.get('event_category','')) != 'None' else ''
        mile_verbose += f'- **{r["event_name"]}**{cat}: {d} days overdue \u2014 [{sev}] priority\n'
    mile_verbose += f'\n**Recommended action:** Escalate the {ms_overdue_exec} overdue milestones to CTT review. '
    mile_verbose += 'Prioritize milestones blocking downstream site activation, database lock, and enrollment activities. '
    mile_verbose += 'For milestones >365 days overdue, escalate to the Study Steering Committee for resource reallocation.'
else:
    mile_verbose += 'All milestones are on track or completed. No overdue items requiring escalation.'
mile_verbose += '\n\n**Data Limitation:** Milestones are tracked at the study level only. Country-level milestone breakdowns are not available in the current data source (mv_study_milestones).'
exec_html += format_narrative(mile_verbose)
md = chart_milestone_donut(milestone_health)
if md: exec_html += f'<div class="chart-container">{md}</div>'

# S5: Regulatory Throughput
exec_html += '<h2 id="es5">\u25B6 REGULATORY THROUGHPUT</h2>'
reg_verbose = regulatory_narrative + '\n\n'
reg_verbose += 'Regulatory throughput tracks Health Authority (HA) submissions and approvals alongside Ethics Committee/IRB reviews. '
reg_verbose += 'Timely regulatory approvals are critical path items for site activation and patient enrollment.\n\n'
if ha_ec_data.get('ha_overdue', 0) > 0 or ha_ec_data.get('ec_overdue', 0) > 0:
    reg_verbose += f'**\u26A0 Attention:** {ha_ec_data.get("ha_overdue",0)} HA and {ha_ec_data.get("ec_overdue",0)} EC submissions are overdue. '
    reg_verbose += 'Delayed approvals directly impact site activation timelines and should be escalated to the regulatory affairs team.\n\n'
reg_verbose += '**Data Limitation:** HA/EC approval data is derived from milestone event names matching approval-related patterns (e.g., "HA Approval", "EC Approval"), '
reg_verbose += 'not from a direct regulatory approval tracking table. A dedicated HA/EC submission and approval table would improve accuracy and enable submission-to-approval cycle time analysis.'
exec_html += format_narrative(reg_verbose)

# S6: Post-SIV Inactivity Analysis
exec_html += '<h2 id="es6">\u25B6 POST-SIV INACTIVITY ANALYSIS</h2>'
postsiv_verbose = post_siv['narrative'] + '\n\n'
postsiv_verbose += 'Post-SIV inactivity identifies countries where sites have been initiated (SIV completed, sites marked active) '
postsiv_verbose += 'but no patients have yet been screened. This may indicate operational barriers such as regulatory delays, '
postsiv_verbose += 'staffing issues, slow patient referral pipelines, or contract/budget disputes at specific sites.\n\n'
if not post_siv['countries']:
    postsiv_verbose += '**Status:** All countries with active sites have begun screening \u2014 no post-SIV inactivity detected. '
    postsiv_verbose += 'This is a positive indicator of operational readiness across the study footprint.\n\n'
else:
    postsiv_verbose += f'**{len(post_siv["countries"])} countries** have active sites with zero screening. '
    postsiv_verbose += 'Recommend immediate investigation into site-level barriers and CRA follow-up.\n\n'
postsiv_verbose += '**Data Limitation:** Per-site SIV dates are not available in mv_study_site_performance. '
postsiv_verbose += 'Post-SIV analysis uses a country-level approximation (sites_active > 0 AND screened_act = 0). '
postsiv_verbose += 'A per-site SIV date would enable more granular days-since-SIV tracking.'
exec_html += format_narrative(postsiv_verbose)
if post_siv['countries']:
    exec_html += '<table class="postsiv-table"><thead><tr><th>Country</th><th>Sites Active</th><th>Sites Planned</th><th>Screened</th><th>Enrolled</th></tr></thead><tbody>'
    for c in post_siv['countries']:
        exec_html += f'<tr><td>{html_mod.escape(c["country"])}</td><td>{c["sites_active"]}</td><td>{c["sites_planned"]}</td><td>0</td><td>{c["enrolled"]}</td></tr>'
    exec_html += '</tbody></table>'

# S7: Risks & Recommended Actions
exec_html += '<h2 id="es7">\u25B6 RISKS &amp; RECOMMENDED ACTIONS</h2>'
risk_data = results.get('CQ-RISK', {})
risk_intro = 'The risk engine performs a comprehensive cross-domain analysis combining overdue milestones, enrollment gaps, '
risk_intro += 'screen failure alerts, and site activation delays into a unified risk register. '
risk_intro += 'Each risk is classified by severity (Critical \u2265 365d / \u2265 50% gap, High \u2265 90d / \u2265 20%, Medium \u2265 30d / \u2265 10%, Low < 30d) '
risk_intro += 'and assigned a recommended action based on clinical operations best practices.'
exec_html += format_narrative(risk_intro)
exec_html += build_risk_summary_html(risk_data)
rc = chart_risk_stacked(risk_data)
if rc: exec_html += f'<div class="chart-container">{rc}</div>'
# Insights narrative
if risk_data.get('rows'):
    rdf = pd.DataFrame(risk_data['rows'], columns=risk_data['columns'])
    exec_html += build_risk_highlights_html(rdf)
    exec_html += build_action_recommendations_html(rdf)
exec_html += build_risk_table_html(risk_data, 20)

# S8: Data Sources & Gaps
exec_html += '<h2 id="es8">\u25B6 DATA SOURCES &amp; KNOWN GAPS</h2>'
data_intro = 'This report is generated from 5 metric views in the nextgen_eu_development_sandbox.clinops_research schema, '
data_intro += 'sourced from nextgen_eu_development_clinical_operations.curated_study_management. '
data_intro += 'The limitations below document known data gaps that may affect the accuracy or completeness of specific sections. '
data_intro += 'Each gap includes the impact on this report and the current mitigation strategy.'
exec_html += format_narrative(data_intro)
exec_html += '<div class="data-gap">\u26A0 <strong>Data sourced from:</strong> nextgen_eu_development_sandbox.clinops_research (5 metric views: mv_study_recruitment_performance, mv_study_country_performance, mv_study_site_performance, mv_study_milestones, mv_scenario_planning)</div>'
exec_html += '<table><thead><tr><th>#</th><th>Limitation</th><th>Impact</th><th>Mitigation</th></tr></thead><tbody>'
gaps_exec = [
    ('D1','Daily enrollment curves unavailable','No plan-as-of-today tracking for enrollment trajectory','Snapshot comparison (enrolled actual vs plan-to-date)'),
    ('D2','Country-level milestones not available','Milestones are study-level; cannot drill to country-specific delays','Study-level overdue flags applied to all countries'),
    ('D3','HA/EC approval coverage is pattern-matched','Derived from milestone event names, not direct approval tracking table','Accuracy depends on milestone naming conventions'),
    ('D4','Per-site SIV date unavailable','Cannot calculate days-since-SIV per site for post-SIV analysis','Country-level approximation (sites_active > 0 AND screened = 0)'),
    ('D5','study_name 98.6% NULL in source data','Some studies show only code, not name','Falls back to study_code when name unavailable'),
    ('D6','Screening rate per site/month not normalized','Enrollment rate shown at study level, not per-site/month','Would need monthly site count time series'),
    ('D7','Post-SIV section empty for high-performing studies','Well-performing studies have all sites screening','Section correctly reports no inactivity when data supports it'),
    ('D8','CRA activity logs not in metric views','Operational data not available for site-level productivity analysis','Not a current data source; would need operational systems integration'),
]
for gid, desc, impact, mitigation in gaps_exec:
    exec_html += f'<tr><td>{gid}</td><td>{html_mod.escape(desc)}</td><td>{html_mod.escape(impact)}</td><td>{html_mod.escape(mitigation)}</td></tr>'
exec_html += '</tbody></table>'

# ==== MILESTONE ANALYSIS ====
n_sections_mile = 7
mile_html = CSS
mile_html += f'<div class="report-header"><div><h1>MILESTONE ANALYSIS</h1>'
mile_html += f'<div class="study-meta">{study_title}</div></div>'
mile_html += f'<img src="{NOVARTIS_LOGO_URI}" alt="Novartis"/></div>'
mile_html += f'<div class="meta">Study: <strong>{TEST_STUDY}</strong>{phase_str} &nbsp;|&nbsp; Generated: {today}, {datetime.now().strftime("%H:%M")} &nbsp;|&nbsp; '
mile_html += f'<span class="enrollment-badge {badge_cls}">Enrollment: {enrollment_badge}</span> '
mile_html += f'<span class="section-count">{n_sections_mile} sections</span></div>'

# Milestone TOC
mile_html += '<div class="toc"><div class="toc-title">Contents</div>'
for i, t in enumerate(['Milestone Overview','All Milestones','Overdue & Variance','Country & Site',
                       'Scenario Planning','Risk Insights','Known Limitations'], 1):
    mile_html += f'<a href="#ms{i}">\u25B8 {t}</a>'
mile_html += '</div>'

# Milestone Summary strip
mile_html += '<div class="summary-strip">'
n_completed = len(milestone_health[milestone_health['milestone_progress_status']=='Completed'])
n_pending = len(milestone_health[milestone_health['milestone_progress_status']=='Pending'])
mile_html += f'<span class="summary-pill">{len(milestone_health)} Total Milestones</span>'
mile_html += f'<span class="summary-pill pill-green">{n_completed} Completed</span>'
mile_html += f'<span class="summary-pill pill-amber">{n_pending} Pending</span>'
mile_html += f'<span class="summary-pill {"pill-red" if n_overdue > 5 else "pill-amber" if n_overdue > 0 else "pill-green"}">{n_overdue} Overdue</span>'
mile_html += f'<span class="summary-pill">{len(country_matrix)} Countries</span>'
mile_html += f'<span class="summary-pill">{len(scenario_data)} Scenarios</span>'
mile_html += '</div>'

# M1: Milestone Overview Narrative
mile_html += '<h2 id="ms1">▶ MILESTONE HEALTH</h2>'
mile_html += build_milestone_overview_cards(milestone_health)
mile_html += format_narrative(milestone_narrative_text)
md2 = chart_milestone_donut(milestone_health)
if md2: mile_html += f'<div class="chart-container">{md2}</div>'

# M2: All Milestones Table
mile_html += '<h2 id="ms2">\u25B6 ALL MILESTONES BY CATEGORY</h2>'
mile_all_narr = f'**{len(milestone_health)} milestones** are tracked for study {TEST_STUDY}. '
mile_all_narr += f'The table below shows all milestones grouped by event category with their current status, actual/scheduled dates, and variance from baseline. '
mile_all_narr += f'Use this data to identify patterns of delay across categories and to prioritize resource allocation for upcoming milestones.'
mile_html += format_narrative(mile_all_narr)
mile_html += build_milestone_table(milestone_health, 60)

# M3: Overdue & Variance Analysis
mile_html += '<h2 id="ms3">\u25B6 OVERDUE &amp; VARIANCE ANALYSIS</h2>'
overdue_df = milestone_health[milestone_health['milestone_progress_status']=='Overdue']
if not overdue_df.empty:
    overdue_df_num = overdue_df.copy()
    overdue_df_num['days_overdue'] = pd.to_numeric(overdue_df_num['days_overdue'], errors='coerce')
    n_crit = len(overdue_df_num[overdue_df_num['days_overdue'] >= 365])
    n_high = len(overdue_df_num[(overdue_df_num['days_overdue'] >= 90) & (overdue_df_num['days_overdue'] < 365)])
    n_other = len(overdue_df) - n_crit - n_high
    top3 = overdue_df_num.sort_values('days_overdue', ascending=False).head(3)
    top3_text = ', '.join(f'{r["event_name"]} ({int(r["days_overdue"])}d)' for _, r in top3.iterrows() if pd.notna(r['days_overdue']))
    var_narr = f'**{len(overdue_df)} overdue milestones** identified across the study timeline:\n'
    var_narr += f'- **{n_crit} Critical** (>365 days overdue): These represent severe timeline slippage that may impact regulatory submission readiness and overall program timelines. Immediate CTT escalation and Study Steering Committee review required.\n'
    var_narr += f'- **{n_high} High** (90\u2013365 days overdue): Significant delays requiring dedicated recovery plans with named owners and bi-weekly progress tracking.\n'
    if n_other > 0:
        var_narr += f'- **{n_other} Medium/Low** (<90 days overdue): Early-stage delays that should be monitored at regular CTT meetings to prevent further slippage.\n'
    var_narr += f'\n**Most critical overdue:** {top3_text}.\n\n'
    var_narr += '**Recommended Actions:**\n'
    var_narr += '- Schedule an emergency CTT meeting focused on the top 3\u20135 longest-overdue milestones\n'
    var_narr += '- Assign named milestone recovery owners with clear accountability and weekly status reporting\n'
    var_narr += '- For milestones blocking downstream activities (database lock, CSR, regulatory submissions), create parallel-track recovery timelines\n'
    var_narr += '- Evaluate whether additional vendor support (CRO, data management, medical writing) is needed to accelerate recovery\n'
    var_narr += '- Review resource allocation across competing priorities and reallocate as needed'
    mile_html += format_narrative(var_narr)
else:
    mile_html += format_narrative('No overdue milestones identified. All milestones are on track or completed. Continue monitoring pending milestones to maintain this trajectory.')
ob = chart_overdue_bars(milestone_health)
if ob: mile_html += f'<div class="chart-container">{ob}</div>'
mile_html += build_milestone_table(overdue_df, 30)

# M4: Country & Site Enrollment
mile_html += '<h2 id="ms4">\u25B6 COUNTRY &amp; SITE ENROLLMENT</h2>'
active_sites = int(country_matrix['sites_active'].sum())
total_enrolled = int(country_matrix['enrolled_act'].sum())
total_planned = int(country_matrix['enrolled_pln'].sum())
high_sfr = country_matrix[country_matrix['sfr_act'] >= 40]
low_enroll = country_matrix[(country_matrix['enrolled_pln'] > 0) & (country_matrix['enrolled_act'] < country_matrix['enrolled_pln'])]
country_narr = f'**{len(country_matrix)} countries** are actively participating in this study with {active_sites} sites active and {total_enrolled} patients enrolled'
country_narr += f' (study-level plan: {int(enr_pln)}).\n\n'
if not low_enroll.empty:
    country_narr += f'**Enrollment Gaps:** {len(low_enroll)} countries are below their enrollment plan. '
    for _, r in low_enroll.head(3).iterrows():
        gap = int(r['enrolled_pln'] - r['enrolled_act'])
        country_narr += f'{r["country_name"]} ({int(r["enrolled_act"])}/{int(r["enrolled_pln"])}, {gap} behind), '
    country_narr = country_narr.rstrip(', ') + '.\n\n'
if not high_sfr.empty:
    country_narr += f'\U0001f534 **Screen Failure Alert:** {len(high_sfr)} countries have SFR \u2265 40% ({', '.join(high_sfr['country_name'].tolist())}). '
    country_narr += 'This level of screen failure warrants immediate review of eligibility criteria application at these sites and potential protocol clarification or investigator retraining.\n\n'
country_narr += '**Data Limitation:** Country-level planned enrollment values are sparse (NULL for most countries in source data). '
country_narr += 'Figures shown use available country-level data; study-level totals from mv_study_recruitment_performance are more reliable for overall plan vs actual comparisons.'
mile_html += format_narrative(country_narr)
ce2 = chart_country_enrollment_grouped(country_matrix)
if ce2: mile_html += f'<div class="chart-container">{ce2}</div>'
mile_html += build_country_enrollment_table(country_matrix)

# M5: Scenario Planning
mile_html += '<h2 id="ms5">\u25B6 SCENARIO PLANNING</h2>'
if not scenario_data.empty:
    approved = scenario_data[scenario_data['scenario_status']=='Approved']
    active_sc = scenario_data[scenario_data['scenario_status']=='Active'] if 'Active' in scenario_data['scenario_status'].values else pd.DataFrame()
    scen_narr = f'**{len(scenario_data)} enrollment scenarios** have been defined for this study'
    scen_narr += f' ({len(approved)} approved' + (f', {len(active_sc)} active' if not active_sc.empty else '') + ').\n\n'
    if not approved.empty:
        avg_screen = approved['screening_rate'].mean()
        avg_rand = approved['randomization_rate'].mean()
        scen_narr += f'**Approved scenario parameters:** Average screening rate: {avg_screen:.2f}, average randomization rate: {avg_rand:.2f}. '
        scen_narr += 'These rates serve as the baseline for enrollment forecasting and site-level performance monitoring.\n\n'
    if len(approved) == 0:
        scen_narr += '**\u26A0 No approved scenarios.** All defined scenarios are in draft or review status. '
        scen_narr += 'An approved scenario is needed to establish the official enrollment forecast baseline. '
        scen_narr += 'Recommend finalizing scenario approval at the next CTT meeting.\n\n'
    scen_narr += '**Data Limitation:** Scenario planning data comes from mv_scenario_planning. '
    scen_narr += 'Committed patient numbers and site initiation rates, when available, provide additional context for enrollment feasibility assessment.'
    mile_html += format_narrative(scen_narr)
else:
    mile_html += format_narrative('No scenario planning data available for this study. Scenario planning is used to model enrollment feasibility under different assumptions. Contact the study planning team to define scenarios.')
mile_html += build_scenario_table(scenario_data)

# M6: Risk Insights & Recommended Actions
mile_html += '<h2 id="ms6">\u25B6 RISK INSIGHTS &amp; RECOMMENDED ACTIONS</h2>'
mile_html += build_risk_summary_html(risk_data)
rc2 = chart_risk_stacked(risk_data)
if rc2: mile_html += f'<div class="chart-container">{rc2}</div>'
if risk_data.get('rows'):
    rdf2 = pd.DataFrame(risk_data['rows'], columns=risk_data['columns'])
    mile_html += build_risk_highlights_html(rdf2, top_critical=6, top_high=5)
    mile_html += build_action_recommendations_html(rdf2)
mile_html += build_risk_table_html(risk_data, 50)

# M7: Known Limitations & Data Gaps
mile_html += '<h2 id="ms7">\u25B6 KNOWN LIMITATIONS &amp; DATA GAPS</h2>'
mile_html += '<div class="data-gap"><strong>Data Source:</strong> nextgen_eu_development_sandbox.clinops_research (5 metric views)</div>'
mile_html += '<table><thead><tr><th>#</th><th>Limitation</th><th>Impact</th><th>Mitigation</th></tr></thead><tbody>'
gaps_mile = [
    ('D1','Country-level milestones not available','All milestones are study-level; cannot drill to country-specific delays','Study-level overdue flags applied to all countries in cross-domain analysis'),
    ('D2','Daily enrollment curves unavailable','No plan-as-of-today tracking for enrollment trajectory','Snapshot comparison (enrolled actual vs plan-to-date)'),
    ('D3','HA/EC approval coverage is pattern-matched','Derived from milestone event names matching HA/EC patterns, not direct approval tracking','Accuracy depends on milestone naming conventions'),
    ('D4','Per-site SIV date unavailable','Cannot calculate days-since-SIV per site for inactivity analysis','Country-level approximation (sites_active > 0 AND screened = 0)'),
    ('D5','study_name 98.6% NULL in source','Some studies show only code, not name','Graceful fallback to study_code when name unavailable'),
    ('D6','Screening rate per site/month','Shown as study-level enrollment rate, not normalized per site per month','Would need monthly site count time series data'),
    ('D7','Post-SIV section empty for high-performing studies','Studies with strong enrollment show 0 inactive countries','Section correctly reports "no inactivity" when all sites are screening'),
]
for i, (gid, desc, impact, mitigation) in enumerate(gaps_mile, 1):
    mile_html += f'<tr><td>{gid}</td><td>{html_mod.escape(desc)}</td><td>{html_mod.escape(impact)}</td><td>{html_mod.escape(mitigation)}</td></tr>'
mile_html += '</tbody></table>'

# ---- Save to workspace ----
OUTPUT_DIR = '/Workspace/Users/mutafmi1@novartis.net/reports'
os.makedirs(OUTPUT_DIR, exist_ok=True)

exec_path = f'{OUTPUT_DIR}/executive_summary_{TEST_STUDY}_{today}.html'
with open(exec_path, 'w') as f:
    f.write(f'<!DOCTYPE html><html><head><meta charset="utf-8"><title>Clinical Trial Status Report - {TEST_STUDY}</title></head><body>{exec_html}</body></html>')

mile_path = f'{OUTPUT_DIR}/milestone_analysis_{TEST_STUDY}_{today}.html'
with open(mile_path, 'w') as f:
    f.write(f'<!DOCTYPE html><html><head><meta charset="utf-8"><title>Milestone Analysis - {TEST_STUDY}</title></head><body>{mile_html}</body></html>')

print(f'Report 1 saved: {exec_path} ({os.path.getsize(exec_path):,} bytes)')
print(f'Report 2 saved: {mile_path} ({os.path.getsize(mile_path):,} bytes)')

print('\n' + '=' * 60)
print('REPORT 1: Executive Summary (6 sections)')
print('=' * 60)
displayHTML(exec_html)

print('\n' + '=' * 60)
print('REPORT 2: Milestone Analysis (6 sections)')
print('=' * 60)
displayHTML(mile_html)

# COMMAND ----------

# DBTITLE 1,Report Output Summary
# ============================================================
# Report output summary + file locations
# ============================================================
import os

print("REPORT OUTPUT SUMMARY")
print("=" * 60)

# Data sources summary
print(f"\nDATA SOURCES (direct SQL):")
print(f"  Study KPIs:        {len(study_kpis)} metrics")
print(f"  Countries:         {len(country_matrix)} countries")
print(f"  Milestones:        {len(milestone_health)} milestones")
print(f"  Sites:             {len(site_summary)} site records")
print(f"  Scenarios:         {len(scenario_data)} scenarios")
print(f"  Risks identified:  {len(risk_df)} risks")
print(f"  Cross-domain flags:{len(cross_domain_flags)} countries flagged")
print(f"  KPI scorecards:    {len(kpi_cards)} cards")
print(f"  HA Approvals:      {ha_ec_data['ha_done']}/{ha_ec_data['ha_total']}")
print(f"  EC/IRB Approvals:  {ha_ec_data['ec_done']}/{ha_ec_data['ec_total']}")
print(f"  Post-SIV inactive: {post_siv['total_inactive']} countries")
print(f"  Study metadata:    {study_name or '(unavailable)'} | Phase {study_phase or '(unavailable)'}")

# Genie queries (if fetched)
total_queries = len(CERTIFIED_QUERIES)
completed = sum(1 for cq in CERTIFIED_QUERIES if results.get(cq['id'], {}).get('status') == 'COMPLETED')
print(f"\nGENIE QUERIES:")
print(f"  Defined:    {total_queries}")
print(f"  Completed:  {completed}/{total_queries}" + (" (fetch not run — using direct SQL)" if completed == 0 else ""))

# Report sections
print(f"\nREPORT STRUCTURE:")
print(f"  Executive Summary: 8 sections (Overview, KPIs, Enrollment, Milestones, Regulatory, Post-SIV, Risks, Data Gaps)")
print(f"  Milestone Analysis: 6 sections (Overview, All Milestones, Overdue, Country/Site, Scenarios, Risks)")

print(f"\nFILE LOCATIONS:")
print(f"  Report 1: {exec_path} ({os.path.getsize(exec_path):,} bytes)")
print(f"  Report 2: {mile_path} ({os.path.getsize(mile_path):,} bytes)")
print(f"\n  Open in browser and Print > Save as PDF for final PDF output.")