# Integrating Genie into a web application

**Audience:** Novartis (Krithika) · **Support case:** 01011943 · **Status:** Genie One MCP is GA (Sept 2026); the Genie Agent MCP server is Beta (Public Preview); the Genie Conversation API is public

This guide shows how to call **Genie** from a custom web application, and which integration
path fits your goal:

| Your goal | Use | Why |
|---|---|---|
| **Embed Genie directly in your own UI** (custom web app or Databricks App) | **Genie Conversation API** (public REST) — see §6 | It's the same API the Genie UI uses; you drive it from your backend and render the answer, generated SQL and result rows in your own UI. No agent id, no MCP layer. |
| **Use Genie as a tool inside an agent / LLM framework** | a **managed Genie MCP server** — §1–§4 | Two options: **Genie One MCP** (workspace-wide, GA) or the **Genie Agent MCP** (scoped to one curated Genie space). Both expose Genie as an ask → poll tool over the standard MCP protocol. |

> **Two Genie MCP servers (both current):**
> - **Genie One MCP** — `system.ai.genie_one_mcp`, **workspace-wide**, GA Sept 2026, grounded
>   in Genie Ontology across your enterprise data. Use it when the agent shouldn't be pinned to
>   one space.
> - **Genie Agent MCP** — `/api/2.0/mcp/genie/<space-id>`, **scoped to one curated Genie space**.
>   Use it to constrain analytics to a specific, governed space.
>
> The older *space-less* Beta endpoint `/api/2.0/mcp/genie` (the `genie` scope) is **deprecated,
> sunset 2026-10-31** — superseded by the Genie One MCP Service. Neither MCP server embeds the
> full Genie UI; for direct UI embedding use the Conversation API (§6).

For the MCP path we built and tested a single small reference app that runs **both** as a
Databricks App and as an external web app from the same code; only the auth layer changes.

---

## 1. What you connect to (MCP path)

Databricks exposes **managed MCP servers** (no server to build or host):

| Server | Endpoint | OAuth scope | What it gives the app |
|---|---|---|---|
| **Genie One** | `https://<workspace-host>/ai-gateway/mcp-services/system.ai.genie_one_mcp` | `ai-gateway` | Workspace-wide Genie One over Unity Gateway (GA), grounded in Genie Ontology; per-user Unity Catalog governance enforced. `EXECUTE` on `system.ai` is held by default. |
| **Genie Agent** | `https://<workspace-host>/api/2.0/mcp/genie/<space-id>` | `genie` | One curated Genie space exposed as a **Genie Agent** tool; per-user governance enforced |
| **Unity Catalog functions** | `https://<workspace-host>/api/2.0/mcp/functions/<catalog>/<schema>` | (app SP / OAuth) | Every UC function in the schema, exposed as a callable tool |

The application connects over the standard MCP protocol; a Genie query runs asynchronously, so
the app submits then polls:

- **Genie One** exposes `genie_ask` (start a response — returns `conversation_id`, `response_id`,
  `status`), `genie_poll_response` (poll for progress + the final answer), `genie_get_query_result`
  (full SQL result: columns + rows), `genie_cancel_response`, and `view_ask` (interactive View on
  MCP Apps clients). **Two practical notes** (verified against the GA server): each tool returns its
  useful payload in the MCP **`structuredContent`** (the text block is agent-facing markdown) —
  read `status` (`in_progress` → `completed`), `final_answer`, `deep_link`, and `query_items` there;
  and **`genie_get_query_result` requires an `item_id`** taken from `query_items[].item_id` (the ran
  SQL is on `query_items[].sql`). When Genie answers inline, `query_items` can be empty and
  `final_answer` carries the result.
- **Genie Agent** exposes `query_space_<id>` (submit a question) and `poll_response_<id>` (poll
  until the answer completes).

**Expectation:** these servers expose Genie as an ask → poll *tool* for agent/LLM-framework use,
not for embedding the full Genie experience into a custom UI. For direct UI embedding, use the
Conversation API (§6).

---

## 2. The one decision: Databricks App vs external web app

It only changes **how the app authenticates** to the managed MCP servers.

| | **Databricks App** | **External web app** (any host / cloud) |
|---|---|---|
| **Auth pattern** | On-behalf-of (OBO) the signed-in user — native | Per-user OAuth (U2M), **or** one service principal (M2M) for all users |
| **How the token arrives** | Platform injects `x-forwarded-access-token` per request | App obtains a token itself (OAuth flow, or SP client-id/secret, or PAT) |
| **Per-user governance** | **Preserved** — Genie/UC enforce each user's own row/column permissions | Preserved with per-user OAuth; **traded away** with a shared service principal (all queries run as one identity) |
| **Setup** | Set `user_api_scopes` on the app (`genie` for Genie Agent, `ai-gateway` for Genie One, `sql`); read the forwarded header | Register an OAuth app (U2M) or create a service principal (M2M) with the same scopes |
| **Where it runs** | Inside the Databricks workspace | Anywhere you host it |
| **Workspace host** | Implicit (its own workspace) | You configure `DATABRICKS_HOST` |

**Recommendation:** if per-user governance matters (it usually does for credit/finance data),
prefer a **Databricks App** (native OBO) or **per-user OAuth** on an external app. Use a single
service principal only if one shared application identity is acceptable for all users.

---

## 3. Minimal integration (same code, both modes)

Standard MCP Python SDK + a bearer token — the token is the only thing that differs:

```python
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

async def list_genie_tools(host, headers, space_id):
    url = f"{host}/api/2.0/mcp/genie/{space_id}"
    async with streamablehttp_client(url, headers=headers) as (r, w, _):
        async with ClientSession(r, w) as s:
            await s.initialize()
            return await s.list_tools()
```

- **External app** — get `headers` from the Databricks SDK:
  ```python
  from databricks.sdk import WorkspaceClient
  wc = WorkspaceClient()                 # profile / PAT / service principal from env
  host, headers = wc.config.host, wc.config.authenticate()
  ```
- **Databricks App** — get the user token from the request header:
  ```python
  token = request.headers["x-forwarded-access-token"]
  headers = {"Authorization": f"Bearer {token}"}
  ```

The same code hits the **Genie One** server by swapping the URL:
```python
url = f"{host}/ai-gateway/mcp-services/system.ai.genie_one_mcp"   # then call_tool("genie_ask", {"question": ...})
```

A Genie query is submit-then-poll (Genie One: `genie_ask` → `genie_poll_response` →
`genie_get_query_result`); a UC function call is a single `call_tool(name, args)`.
(Databricks also ships a higher-level `databricks-mcp` `DatabricksMCPClient` that wraps auth
via a `WorkspaceClient` — convenient inside agents.)

---

## 4. Setup steps

**Databricks App**
1. `databricks apps create --json '{"name":"<app>","user_api_scopes":["genie","ai-gateway","sql"]}'`
   (`genie` = Genie Agent, `ai-gateway` = Genie One, `sql` = query execution).
2. Upload the source and `databricks apps deploy <app> --source-code-path <workspace-path>`.
3. In the app, read `x-forwarded-access-token` per request and call the MCP endpoints as that user.

**External web app**
1. Set `DATABRICKS_HOST` and pick an auth method:
   - per-user **OAuth (U2M)** — register an OAuth app; best for per-user governance;
   - **service principal (M2M)** — `DATABRICKS_CLIENT_ID` + `DATABRICKS_CLIENT_SECRET`;
   - **PAT** — `DATABRICKS_TOKEN` (fine for a quick test).
2. Point `GENIE_SPACE_ID` (Genie Agent) / `UC_CATALOG` / `UC_SCHEMA` at your resources; Genie One
   needs no space id. Call the same endpoints.

Prereq (both): a workspace admin enables the **Managed MCP Servers** preview.

---

## 6. Direct embedding — the Genie Conversation API (recommended for a custom UI)

To embed Genie in your own web app or Databricks App UI, call the **Genie Conversation
API** (public REST) directly from your backend — no agent id and no MCP layer. It's the
same API the Genie UI uses:

1. **Start a conversation** — `POST /api/2.0/genie/spaces/{space_id}/start-conversation`
2. **Send a follow-up message** — `POST /api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages`
3. **Poll message status** — `GET /api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}`
4. **Fetch the SQL result** — `GET .../messages/{message_id}/query-result`

Render the answer text, the generated SQL and the result rows in your own UI. Authentication
is the same choice as everywhere else: from a **Databricks App**, on-behalf-of the signed-in
user (per-user governance) or the app service principal; from an **external web app**,
per-user OAuth (U2M) or a service principal (M2M).

Docs: https://docs.databricks.com/aws/en/genie/conversation-api

---

## 7. Reference documentation (public)

- Genie Conversation API — https://docs.databricks.com/aws/en/genie/conversation-api
- Databricks managed MCP servers — https://docs.databricks.com/aws/en/agents/mcp-tools/managed-mcp
- Genie MCP server — https://docs.databricks.com/aws/en/agents/mcp-tools/genie-mcp
- Connect MCP clients & set up authentication — https://docs.databricks.com/aws/en/agents/mcp-tools/connect-clients
- Use MCP servers from application code (Python) — https://docs.databricks.com/aws/en/agents/mcp-tools/use-mcp-in-agents
- Databricks Apps — on-behalf-of-user authorization — https://docs.databricks.com/aws/en/dev-tools/databricks-apps/auth
