# Integrating Genie One into a web application via managed MCP

**Audience:** Novartis (Krithika) · **Support case:** 01011943 · **Status of feature:** Beta (Public Preview)

This guide shows how to call **Genie One** from a custom web application using the
Databricks **managed MCP servers**, and lays out the two hosting options — a **Databricks
App** vs an **external web app** — and exactly what differs between them (the choice
drives the authentication pattern, and nothing else in the app code).

We built and tested a single small reference app that runs **both** ways from the same
code; only the auth layer changes.

---

## 1. What you connect to

Databricks exposes **managed MCP servers** (no server to build or host). The two relevant here:

| Server | Endpoint | What it gives the app |
|---|---|---|
| **Genie One** | `https://<workspace-host>/api/2.0/mcp/genie/<space-id>` | Natural-language querying of a Genie space; per-user Unity Catalog governance enforced |
| **Unity Catalog functions** | `https://<workspace-host>/api/2.0/mcp/functions/<catalog>/<schema>` | Every UC function in the schema, exposed as a callable tool |

The application connects over the standard MCP protocol. The Genie server exposes two
tools: `query_space_<id>` (submit a natural-language question) and `poll_response_<id>`
(poll until the answer completes) — the query runs asynchronously, so the app submits then polls.

**Beta expectation:** the MCP server exposes a **focused set of Genie actions** (query + poll).
Embedding the **full** Genie One interface into a custom application is not generally
available today.

---

## 2. The one decision: Databricks App vs external web app

It only changes **how the app authenticates** to the managed MCP servers.

| | **Databricks App** | **External web app** (any host / cloud) |
|---|---|---|
| **Auth pattern** | On-behalf-of (OBO) the signed-in user — native | Per-user OAuth (U2M), **or** one service principal (M2M) for all users |
| **How the token arrives** | Platform injects `x-forwarded-access-token` per request | App obtains a token itself (OAuth flow, or SP client-id/secret, or PAT) |
| **Per-user governance** | **Preserved** — Genie/UC enforce each user's own row/column permissions | Preserved with per-user OAuth; **traded away** with a shared service principal (all queries run as one identity) |
| **Setup** | Set `user_api_scopes: ["genie","sql"]` on the app; read the forwarded header | Register an OAuth app (U2M) or create a service principal (M2M) |
| **Where it runs** | Inside the Databricks workspace | Anywhere you host it |
| **Workspace host** | Implicit (its own workspace) | You configure `DATABRICKS_HOST` |

**Recommendation:** if per-user governance matters (it usually does for credit/finance data),
prefer a **Databricks App** (native OBO) or **per-user OAuth** on an external app. Use a single
service principal only if one shared application identity is acceptable for all users.

---

## 3. Minimal integration (same code, both modes)

Standard MCP Python SDK + a bearer token — the token is the only thing that differs:

```python
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

async def list_genie_tools(host, headers, space_id):
    url = f"{host}/api/2.0/mcp/genie/{space_id}"
    async with streamablehttp_client(url, headers=headers) as (r, w, _):
        async with ClientSession(r, w) as s:
            await s.initialize()
            return await s.list_tools()
```

- **External app** — get `headers` from the Databricks SDK:
  ```python
  from databricks.sdk import WorkspaceClient
  wc = WorkspaceClient()                 # profile / PAT / service principal from env
  host, headers = wc.config.host, wc.config.authenticate()
  ```
- **Databricks App** — get the user token from the request header:
  ```python
  token = request.headers["x-forwarded-access-token"]
  headers = {"Authorization": f"Bearer {token}"}
  ```

A Genie query is submit-then-poll; a UC function call is a single `call_tool(name, args)`.
(Databricks also ships a higher-level `databricks-mcp` `DatabricksMCPClient` that wraps auth
via a `WorkspaceClient` — convenient inside agents.)

---

## 4. Setup steps

**Databricks App**
1. `databricks apps create --json '{"name":"<app>","user_api_scopes":["genie","sql"]}'`
2. Upload the source and `databricks apps deploy <app> --source-code-path <workspace-path>`.
3. In the app, read `x-forwarded-access-token` per request and call the MCP endpoints as that user.

**External web app**
1. Set `DATABRICKS_HOST` and pick an auth method:
   - per-user **OAuth (U2M)** — register an OAuth app; best for per-user governance;
   - **service principal (M2M)** — `DATABRICKS_CLIENT_ID` + `DATABRICKS_CLIENT_SECRET`;
   - **PAT** — `DATABRICKS_TOKEN` (fine for a quick test).
2. Point `GENIE_SPACE_ID` / `UC_CATALOG` / `UC_SCHEMA` at your resources and call the same endpoints.

Prereq (both): a workspace admin enables the **Managed MCP Servers** preview.

---

## 5. Reference documentation (public)

- Databricks managed MCP servers — https://docs.databricks.com/aws/en/agents/mcp-tools/managed-mcp
- Genie One MCP server — https://docs.databricks.com/aws/en/agents/mcp-tools/genie-mcp
- Connect MCP clients & set up authentication — https://docs.databricks.com/aws/en/agents/mcp-tools/connect-clients
- Use MCP servers from application code (Python) — https://docs.databricks.com/aws/en/agents/mcp-tools/use-mcp-in-agents
- Databricks Apps — on-behalf-of-user authorization — https://docs.databricks.com/aws/en/dev-tools/databricks-apps/auth
