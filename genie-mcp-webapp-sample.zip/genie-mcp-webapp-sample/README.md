# Genie + Unity Catalog — managed MCP web-app sample

Prepared for Novartis · Support case 01011943.

**One** small web app that connects to three Databricks **managed MCP servers** — **Genie One**
(`system.ai.genie_one_mcp`, workspace-wide, GA), the **Genie Agent** (`/api/2.0/mcp/genie/<space-id>`,
one curated Genie space), and **Unity Catalog functions** (each UC function as a tool) — and runs
**either as a Databricks App or as an external web app**. The application code is identical; only
*how it authenticates* changes, selected by the `AUTH_MODE` environment variable. That is the
"Databricks App vs external web app" decision in practice.

> **Scope.** This sample demonstrates the **managed Genie MCP servers** — the path for using
> Genie as a tool inside an agent / LLM framework. **Genie One MCP** is workspace-wide (GA Sept
> 2026, `ai-gateway` scope); the **Genie Agent MCP** is scoped to one Genie space (`genie` scope).
> To embed Genie **directly** in a custom UI, use the **Genie Conversation API** (public REST)
> instead — see `INTEGRATION_GUIDE.md`.

---

## Which app is which

There is a single codebase (`app/`). The two "apps" are two ways to **run** it:

| | **Databricks App** | **External web app** (any host / cloud) |
|---|---|---|
| How to run | Deploy `app/` with **`app.yaml`** (sets `AUTH_MODE=databricks_app`) | Run `app/` with **`AUTH_MODE=external`** |
| Authentication | On-behalf-of the signed-in user via the `x-forwarded-access-token` header the platform injects | Your app obtains the token: CLI profile, PAT, or service principal |
| Per-user governance | Preserved (Genie/UC enforce each user's own permissions) | Preserved with per-user OAuth; a shared service principal trades it away |
| Instructions | `app/README.md` → "Deploy as a Databricks App" | `app/README.md` → "Run as an external web app" |

So: **`app.yaml` + `AUTH_MODE=databricks_app` = the Databricks App**; **`AUTH_MODE=external` = the
external web app**. Same code both times.

## Contents

```
README.md               ← you are here (which app is which)
INTEGRATION_GUIDE.md    endpoints, the App-vs-external differences, setup steps, doc links
app.yaml                Databricks Apps manifest (the deploy root; sets AUTH_MODE=databricks_app)
app/
  config.py             env-based config (no secrets)
  auth.py               THE ONLY difference between the two modes → produces (host, headers)
  mcp_client.py         connect to Genie Agent + Genie One + UC functions MCP; list tools, ask Genie, call a function
  main.py               FastAPI endpoints + serves the UI
  static/index.html     minimal chat + tool UI
  requirements.txt      dependencies
  .env.example          copy to .env and fill in (never commit real values)
  README.md             run + deploy instructions
setup_uc_functions.py   registers two demo UC functions so the functions MCP has tools to show
test_mcp_tools.py       acceptance test over MCP
```

## Quick start — external web app (fastest to try)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r app/requirements.txt
cp app/.env.example app/.env    # set AUTH_MODE=external, GENIE_SPACE_ID, GENIE_ONE_ENABLED, UC_CATALOG, UC_SCHEMA, DATABRICKS_HOST + auth
uvicorn app.main:app --port 8000
# open http://localhost:8000
```

## Managed MCP endpoints

- Genie One (workspace-wide, GA): `https://<workspace-host>/ai-gateway/mcp-services/system.ai.genie_one_mcp` — `ai-gateway` scope
- Genie Agent (one space): `https://<workspace-host>/api/2.0/mcp/genie/<space-id>` — `genie` scope
- Unity Catalog functions: `https://<workspace-host>/api/2.0/mcp/functions/<catalog>/<schema>`

## One note on Unity Catalog functions from a Databricks App

Genie works **per-user (OBO)** with the `genie` scope (Genie Agent) / `ai-gateway` scope (Genie
One). The UC **functions** MCP over OBO currently needs the `unity-catalog` scope, which is not
yet an available Databricks Apps user-authorization scope, so this sample calls the functions
server as the **app's service
principal** (grant that SP `EXECUTE` on the schema; `UC_USE_APP_SP=true`). An **external** app is
unaffected — a per-user OAuth token can carry the `unity-catalog` scope.

## Prerequisite

A workspace admin enables the **Managed MCP Servers** preview.
