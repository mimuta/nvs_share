"""Acceptance test — connect to the Genie One and Unity Catalog managed MCP servers
and assert the app's core operations work. Uses the external-mode auth (ambient
Databricks SDK creds), so run it with a profile / PAT / service principal set.

  python test_mcp_tools.py --profile DEFAULT \
    --space <your-genie-space-id> \
    --catalog <your-catalog> --schema <your-schema>
"""

from __future__ import annotations

import argparse
import asyncio
import sys

from databricks.sdk import WorkspaceClient

from app import mcp_client as mcp


async def run(host: str, headers: dict, space: str, catalog: str, schema: str) -> int:
    failures = 0

    def check(name: str, ok: bool, detail: str = "") -> None:
        nonlocal failures
        print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
        if not ok:
            failures += 1

    # 1. Genie server lists its tools
    genie_tools = await mcp.list_tools(mcp.genie_url(host, space), headers)
    names = [t["name"] for t in genie_tools]
    check("genie: query + poll tools present", any("query_space" in n for n in names)
          and any("poll_response" in n for n in names), str(names))

    # 2. Genie answers a natural-language question
    ans = await mcp.ask_genie(host, headers, space, "How many customers are there in total?")
    check("genie: query completes", ans.get("status") == "COMPLETED", str(ans.get("status")))
    check("genie: returns an answer or rows", bool(ans.get("answer") or ans.get("rows")),
          (ans.get("answer") or "")[:60])

    # 3. UC functions server lists tools
    uc_url = mcp.uc_functions_url(host, catalog, schema)
    uc_tools = await mcp.list_tools(uc_url, headers)
    uc_names = [t["name"].split("__")[-1] for t in uc_tools]
    check("uc: functions exposed as tools", "flag_credit_risk" in uc_names, str(uc_names))

    # 4. UC function executes with the expected result
    tool = next(t["name"] for t in uc_tools if t["name"].endswith("flag_credit_risk"))
    out = await mcp.call_uc_tool(host, headers, catalog, schema, tool,
                                 {"credit_score": 540, "days_overdue": 20})
    got = (out.get("rows") or [[None]])[0][0]
    check("uc: flag_credit_risk(540, 20) == HIGH", str(got) == "HIGH", str(out))

    print(f"\n{'ALL PASSED' if failures == 0 else str(failures) + ' FAILED'}")
    return failures


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default=None)
    ap.add_argument("--space", required=True)
    ap.add_argument("--catalog", required=True)
    ap.add_argument("--schema", required=True)
    args = ap.parse_args()

    wc = WorkspaceClient(profile=args.profile) if args.profile else WorkspaceClient()
    host = wc.config.host.rstrip("/")
    headers = dict(wc.config.authenticate())
    return asyncio.run(run(host, headers, args.space, args.catalog, args.schema))


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
