# Genie One + Unity Catalog managed-MCP demo app

One small FastAPI web app that talks to two **Databricks managed MCP servers** — the
**Genie One** server (natural-language querying) and the **Unity Catalog functions**
server (each UC function surfaces as a tool). It runs in **two modes** from the same
code; only the auth layer (`auth.py`) differs:

| Mode | `AUTH_MODE` | How it authenticates |
|---|---|---|
| **Databricks App** | `databricks_app` | on-behalf-of the signed-in user via the `x-forwarded-access-token` header the platform injects |
| **External web app** | `external` | Databricks SDK ambient auth: CLI profile **or** PAT **or** service principal |

Nothing sensitive lives in the code — see `.env.example`. Config is four env vars:
`GENIE_SPACE_ID`, `UC_CATALOG`, `UC_SCHEMA`, and (external) `DATABRICKS_HOST` + auth.

## Files

```
app/
  config.py       env-based config (no secrets)
  auth.py         the ONLY thing that differs between the two modes → (host, headers)
  mcp_client.py   async MCP calls: list tools, ask Genie (query→poll), call a UC function
  main.py         FastAPI: /api/config, /api/tools, /api/query, /api/call, and the UI
  static/index.html  minimal chat + tool UI
app.yaml          Databricks Apps manifest (one dir up: the deploy root)
```

## Run as an external web app (anywhere)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r app/requirements.txt
cp app/.env.example app/.env      # set AUTH_MODE=external, GENIE_SPACE_ID, UC_*, and auth
uvicorn app.main:app --reload --port 8000
# open http://localhost:8000
```

Auth for external mode (pick one, in `.env` / environment):
- **CLI profile** — `export DATABRICKS_CONFIG_PROFILE=DEFAULT` (simplest for a laptop demo)
- **PAT** — `DATABRICKS_TOKEN=...`
- **Service principal** — `DATABRICKS_CLIENT_ID=...` + `DATABRICKS_CLIENT_SECRET=...`

## Deploy as a Databricks App

```bash
# 1) create the app WITH the user-authorization scopes it needs
databricks apps create --json '{"name":"genie-mcp-demo","user_api_scopes":["genie","sql"]}'

# 2) upload the source (this directory's parent, which holds app.yaml)
databricks sync --full . /Workspace/Users/<you>/genie-mcp-demo

# 3) deploy
databricks apps deploy genie-mcp-demo \
  --source-code-path /Workspace/Users/<you>/genie-mcp-demo
```

`app.yaml` sets `AUTH_MODE=databricks_app`; the app then calls Genie/UC as the signed-in
user, so their own Unity Catalog row/column permissions are enforced end to end.

## The higher-level `databricks-mcp` client (alternative)

This demo uses the standard `mcp` SDK + a bearer token for portability. Databricks also
ships `databricks-mcp` (`DatabricksMCPClient`) which wraps auth via a `WorkspaceClient` —
handy inside agents. See the docs linked in the workstream README.
