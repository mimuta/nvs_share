"""Thin async wrapper over the Databricks *managed* MCP servers.

Uses only the standard MCP Python SDK (``mcp``) + a bearer token, so it is fully
portable — the same code talks to the Genie server and the Unity Catalog
functions server, and works identically in both run modes (the token is the only
thing that changes).

Two Genie MCP servers, side by side (they are different products):

* Genie Agent (one space) :  {host}/api/2.0/mcp/genie/{space_id}
      Scoped to one curated Genie space. Tools: query_space_<id> / poll_response_<id>.
      OAuth scope: ``genie``. This is the space-scoped "Genie Agent" managed MCP server.
* Genie One (workspace)   :  {host}/ai-gateway/mcp-services/system.ai.genie_one_mcp
      Workspace-wide Genie One over Unity Gateway (GA, Sept 2026), grounded in Genie
      Ontology — not tied to a single space. Tools: genie_ask / genie_poll_response /
      genie_get_query_result / genie_cancel_response / view_ask. OAuth scope: ``ai-gateway``
      (account users hold EXECUTE on ``system.ai`` by default).
      Docs: https://docs.databricks.com/aws/en/agents/mcp-tools/genie-mcp
* Unity Catalog funcs     :  {host}/api/2.0/mcp/functions/{catalog}/{schema}
* Vector Search           :  {host}/api/2.0/mcp/vector-search/{catalog}/{schema}

NOTE: the *space-less* Beta endpoint {host}/api/2.0/mcp/genie (``genie`` scope) is
deprecated and sunset 2026-10-31 — superseded by the Genie One MCP Service above. The
*space-scoped* Genie Agent endpoint (/api/2.0/mcp/genie/<space-id>) is a separate,
current server and stays.
"""

from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager
from typing import Any

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

GENIE_ONE_SERVICE = "system.ai.genie_one_mcp"

# Genie Agent (space) statuses that mean "keep polling".
_GENIE_PENDING = {
    "PENDING", "SUBMITTED", "PENDING_WAREHOUSE", "EXECUTING_QUERY",
    "FILTERING_CONTEXT", "ASKING_AI", "PENDING_RESULT", "RUNNING",
}

# Genie One (system.ai.genie_one_mcp) statuses. A response is ``in_progress`` until
# it reaches ``completed`` / ``incomplete`` / ``failed`` (verified live 2026-09-23).
_GENIE_ONE_PENDING = {"in_progress", "pending", "running", "submitted", "not_started"}


def genie_url(host: str, space_id: str) -> str:
    return f"{host}/api/2.0/mcp/genie/{space_id}"


def genie_one_url(host: str) -> str:
    """Genie One MCP Service, addressed by its fully qualified UC name via Unity Gateway."""
    return f"{host}/ai-gateway/mcp-services/{GENIE_ONE_SERVICE}"


def uc_functions_url(host: str, catalog: str, schema: str) -> str:
    return f"{host}/api/2.0/mcp/functions/{catalog}/{schema}"


@asynccontextmanager
async def _session(url: str, headers: dict[str, str]):
    async with streamablehttp_client(url, headers=headers) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            yield session


def _first_json(result: Any) -> dict:
    """Managed MCP tools return a single JSON text block; parse it."""
    for block in result.content:
        text = getattr(block, "text", None)
        if text:
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"text": text}
    return {}


def _struct(result: Any) -> dict:
    """Prefer the MCP ``structuredContent`` and fall back to the text block.

    Genie One returns its useful payload (status / final_answer / query_items) in
    ``structuredContent``; its text block is agent-facing markdown, not JSON.
    """
    sc = getattr(result, "structuredContent", None)
    if isinstance(sc, dict) and sc:
        return sc
    return _first_json(result)


async def list_tools(url: str, headers: dict[str, str]) -> list[dict]:
    async with _session(url, headers) as session:
        tools = await session.list_tools()
        return [{"name": t.name, "description": (t.description or "").strip(),
                 "input_schema": t.inputSchema or {}} for t in tools.tools]


async def ask_genie(host: str, headers: dict[str, str], space_id: str, question: str,
                    conversation_id: str | None = None, poll_seconds: float = 3.0,
                    max_polls: int = 40) -> dict:
    """Ask a natural-language question and poll until Genie completes.

    Returns ``{answer, sql, columns, rows, conversation_id, status}``.
    """
    url = genie_url(host, space_id)
    async with _session(url, headers) as session:
        args = {"query": question}
        if conversation_id:
            args["conversation_id"] = conversation_id
        started = _first_json(await session.call_tool(f"query_space_{space_id}", args))
        conv = started.get("conversationId") or conversation_id
        msg = started.get("messageId")
        payload = started
        for _ in range(max_polls):
            status = (payload.get("content") or {}).get("status") or payload.get("status")
            if status and status not in _GENIE_PENDING:
                break
            await asyncio.sleep(poll_seconds)
            payload = _first_json(await session.call_tool(
                f"poll_response_{space_id}", {"conversation_id": conv, "message_id": msg}))
    return _shape_genie(payload, conv)


def _shape_genie(payload: dict, conversation_id: str | None) -> dict:
    content = payload.get("content") or {}
    answer = "\n".join(content.get("textAttachments") or []) or None
    sql, columns, rows = None, [], []
    for att in content.get("queryAttachments") or []:
        # `query` is the SQL string; `statement_response` holds the result set.
        sql = att.get("query") or sql
        statement = att.get("statement_response") or {}
        manifest = statement.get("manifest") or {}
        columns = [c.get("name") for c in (manifest.get("schema") or {}).get("columns", [])]
        result = statement.get("result") or {}
        for row in result.get("data_array") or []:
            rows.append([_cell(v) for v in row.get("values", [])])
    return {
        "answer": answer,
        "sql": sql,
        "columns": columns,
        "rows": rows,
        "conversation_id": payload.get("conversationId") or conversation_id,
        "status": content.get("status") or payload.get("status"),
    }


def _cell(value: dict) -> Any:
    for key in ("string_value", "long_value", "double_value", "boolean_value"):
        if key in value:
            return value[key]
    return value.get("null_value") if "null_value" in value else None


# --------------------------------------------------------------------------- #
# Genie One (system.ai.genie_one_mcp) — workspace-wide, GA Sept 2026.
#
# Verified live against the GA server (fevm-mikael-serverless, 2026-09-23). Each tool
# returns its useful payload in the MCP ``structuredContent`` (the text block is
# agent-facing markdown, not JSON):
#   * genie_ask            -> {conversation_id, response_id, status: "in_progress"}
#   * genie_poll_response  -> {status, final_answer, deep_link, query_items,
#                              progress_steps, narration_instruction}
#                             status goes in_progress -> completed/incomplete/failed;
#                             final_answer is markdown (often with an inline table).
#   * genie_get_query_result(conversation_id, response_id, item_id) -> full table;
#                             item_id comes from query_items[].item_id (may be empty
#                             when Genie routes to a Genie space and answers inline).
# --------------------------------------------------------------------------- #

def _dig(obj: Any, *keys: str) -> Any:
    """First non-empty value found for any of ``keys``, searched recursively."""
    if isinstance(obj, dict):
        for k in keys:
            if k in obj and obj[k] not in (None, "", [], {}):
                return obj[k]
        for v in obj.values():
            found = _dig(v, *keys)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for v in obj:
            found = _dig(v, *keys)
            if found is not None:
                return found
    return None


def _collect_text(obj: Any) -> str | None:
    """Best-effort natural-language answer from a Genie One payload."""
    direct = _dig(obj, "answer", "final_answer", "narration", "message", "text")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()
    atts = _dig(obj, "textAttachments", "text_attachments")
    if isinstance(atts, list):
        parts = [a if isinstance(a, str) else (a.get("text") if isinstance(a, dict) else None)
                 for a in atts]
        parts = [p for p in parts if p]
        if parts:
            return "\n".join(parts)
    return None


def _extract_table(obj: Any) -> tuple[list, list, str | None]:
    """``(columns, rows, sql)`` from a genie_get_query_result / statement-style payload.

    genie_get_query_result returns ``columns: [{name, type_text}]`` and ``rows: [[...]]``
    at the top level; other shapes (schema.columns, statement_response, data_array with
    ``values``) are handled too.
    """
    sql = _dig(obj, "query", "sql")
    sql = sql if isinstance(sql, str) else None
    stmt = _dig(obj, "statement_response") or obj
    schema = _dig(stmt, "schema")
    columns: list = []
    if isinstance(schema, dict):
        columns = [c.get("name") for c in schema.get("columns", []) if isinstance(c, dict)]
    if not columns:
        maybe = _dig(obj, "columns")
        if isinstance(maybe, list) and maybe:
            if all(isinstance(c, str) for c in maybe):
                columns = maybe
            else:
                columns = [c.get("name") or c.get("column_name")
                           for c in maybe if isinstance(c, dict)]
    data = _dig(obj, "data_array") or _dig(obj, "rows")
    rows: list = []
    if isinstance(data, list):
        for r in data:
            if isinstance(r, dict) and "values" in r:
                rows.append([_cell(v) for v in r["values"]])
            elif isinstance(r, list):
                rows.append(list(r))
    return columns, rows, sql


def _shape_genie_one(payload: dict, conversation_id: str | None, response_id: str | None) -> dict:
    """Shape a Genie One poll payload (its ``structuredContent``) into the common dict.

    ``final_answer`` is the markdown answer (often with an inline result table). Full
    tabular rows, when Genie exposes a query item, are fetched separately by
    ``ask_genie_one`` via ``genie_get_query_result`` and merged in.
    """
    answer = payload.get("final_answer") or _collect_text(payload)
    return {
        "answer": answer,
        "sql": None,
        "columns": [],
        "rows": [],
        "conversation_id": payload.get("conversation_id") or conversation_id,
        "response_id": payload.get("response_id") or response_id,
        "status": payload.get("status"),
        "deep_link": payload.get("deep_link"),
        "query_items": payload.get("query_items") or [],
        # If no answer parsed, hand the raw payload to the UI so nothing is dropped.
        "raw": None if answer else payload,
    }


async def ask_genie_one(host: str, headers: dict[str, str], question: str,
                        conversation_id: str | None = None, poll_seconds: float = 3.0,
                        max_polls: int = 60) -> dict:
    """Ask Genie One (workspace-wide) and poll until it completes.

    Reads the MCP ``structuredContent`` at each step (verified live 2026-09-23):
    ``genie_ask`` starts the turn, ``genie_poll_response`` is polled until ``status``
    leaves ``in_progress``, and ``genie_get_query_result`` (keyed by each
    ``query_items[].item_id``) fetches the full table when Genie exposes one.
    """
    url = genie_one_url(host)
    async with _session(url, headers) as session:
        args: dict[str, Any] = {"question": question}
        if conversation_id:
            args["conversation_id"] = conversation_id
        started = _struct(await session.call_tool("genie_ask", args))
        conv = started.get("conversation_id") or conversation_id
        resp = started.get("response_id")
        payload = started
        for _ in range(max_polls):
            status = str(payload.get("status") or "").lower()
            if status and status not in _GENIE_ONE_PENDING:
                break
            await asyncio.sleep(poll_seconds)
            # genie_poll_response requires BOTH ids.
            payload = _struct(await session.call_tool(
                "genie_poll_response", {"conversation_id": conv, "response_id": resp}))
        shaped = _shape_genie_one(payload, conv, resp)
        # Fetch the full tabular result for each query item Genie produced.
        for item in shaped.get("query_items") or []:
            if not isinstance(item, dict):
                continue
            # The SQL Genie ran is on the query item itself.
            if item.get("sql") and not shaped["sql"]:
                shaped["sql"] = item["sql"]
            item_id = item.get("item_id")
            if not item_id:
                continue
            try:
                qr = _struct(await session.call_tool("genie_get_query_result",
                    {"conversation_id": conv, "response_id": resp, "item_id": item_id}))
                cols, rows, qsql = _extract_table(qr)
                if cols:
                    shaped["columns"] = cols
                if rows:
                    shaped["rows"] = rows
                if qsql and not shaped["sql"]:
                    shaped["sql"] = qsql
            except Exception:
                pass  # best-effort — final_answer already carries the answer
        shaped["raw"] = None if (shaped["answer"] or shaped["rows"]) else shaped["raw"]
        return shaped


async def call_uc_tool(host: str, headers: dict[str, str], catalog: str, schema: str,
                       tool_name: str, arguments: dict) -> dict:
    """Invoke a Unity Catalog function exposed as an MCP tool."""
    url = uc_functions_url(host, catalog, schema)
    async with _session(url, headers) as session:
        return _first_json(await session.call_tool(tool_name, arguments))
