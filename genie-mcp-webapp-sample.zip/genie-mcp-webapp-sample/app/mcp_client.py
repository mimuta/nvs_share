"""Thin async wrapper over the Databricks *managed* MCP servers.

Uses only the standard MCP Python SDK (``mcp``) + a bearer token, so it is fully
portable — the same code talks to the Genie One server and the Unity Catalog
functions server, and works identically in both run modes (the token is the only
thing that changes).

Managed MCP endpoints:
* Genie One            :  {host}/api/2.0/mcp/genie/{space_id}
* Unity Catalog funcs  :  {host}/api/2.0/mcp/functions/{catalog}/{schema}
* Vector Search        :  {host}/api/2.0/mcp/vector-search/{catalog}/{schema}
"""

from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager
from typing import Any

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

# Genie statuses that mean "keep polling".
_GENIE_PENDING = {
    "PENDING", "SUBMITTED", "PENDING_WAREHOUSE", "EXECUTING_QUERY",
    "FILTERING_CONTEXT", "ASKING_AI", "PENDING_RESULT", "RUNNING",
}


def genie_url(host: str, space_id: str) -> str:
    return f"{host}/api/2.0/mcp/genie/{space_id}"


def uc_functions_url(host: str, catalog: str, schema: str) -> str:
    return f"{host}/api/2.0/mcp/functions/{catalog}/{schema}"


@asynccontextmanager
async def _session(url: str, headers: dict[str, str]):
    async with streamablehttp_client(url, headers=headers) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            yield session


def _first_json(result: Any) -> dict:
    """Managed MCP tools return a single JSON text block; parse it."""
    for block in result.content:
        text = getattr(block, "text", None)
        if text:
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"text": text}
    return {}


async def list_tools(url: str, headers: dict[str, str]) -> list[dict]:
    async with _session(url, headers) as session:
        tools = await session.list_tools()
        return [{"name": t.name, "description": (t.description or "").strip(),
                 "input_schema": t.inputSchema or {}} for t in tools.tools]


async def ask_genie(host: str, headers: dict[str, str], space_id: str, question: str,
                    conversation_id: str | None = None, poll_seconds: float = 3.0,
                    max_polls: int = 40) -> dict:
    """Ask a natural-language question and poll until Genie completes.

    Returns ``{answer, sql, columns, rows, conversation_id, status}``.
    """
    url = genie_url(host, space_id)
    async with _session(url, headers) as session:
        args = {"query": question}
        if conversation_id:
            args["conversation_id"] = conversation_id
        started = _first_json(await session.call_tool(f"query_space_{space_id}", args))
        conv = started.get("conversationId") or conversation_id
        msg = started.get("messageId")
        payload = started
        for _ in range(max_polls):
            status = (payload.get("content") or {}).get("status") or payload.get("status")
            if status and status not in _GENIE_PENDING:
                break
            await asyncio.sleep(poll_seconds)
            payload = _first_json(await session.call_tool(
                f"poll_response_{space_id}", {"conversation_id": conv, "message_id": msg}))
    return _shape_genie(payload, conv)


def _shape_genie(payload: dict, conversation_id: str | None) -> dict:
    content = payload.get("content") or {}
    answer = "\n".join(content.get("textAttachments") or []) or None
    sql, columns, rows = None, [], []
    for att in content.get("queryAttachments") or []:
        # `query` is the SQL string; `statement_response` holds the result set.
        sql = att.get("query") or sql
        statement = att.get("statement_response") or {}
        manifest = statement.get("manifest") or {}
        columns = [c.get("name") for c in (manifest.get("schema") or {}).get("columns", [])]
        result = statement.get("result") or {}
        for row in result.get("data_array") or []:
            rows.append([_cell(v) for v in row.get("values", [])])
    return {
        "answer": answer,
        "sql": sql,
        "columns": columns,
        "rows": rows,
        "conversation_id": payload.get("conversationId") or conversation_id,
        "status": content.get("status") or payload.get("status"),
    }


def _cell(value: dict) -> Any:
    for key in ("string_value", "long_value", "double_value", "boolean_value"):
        if key in value:
            return value[key]
    return value.get("null_value") if "null_value" in value else None


async def call_uc_tool(host: str, headers: dict[str, str], catalog: str, schema: str,
                       tool_name: str, arguments: dict) -> dict:
    """Invoke a Unity Catalog function exposed as an MCP tool."""
    url = uc_functions_url(host, catalog, schema)
    async with _session(url, headers) as session:
        return _first_json(await session.call_tool(tool_name, arguments))
