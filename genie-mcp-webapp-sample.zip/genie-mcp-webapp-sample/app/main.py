"""Genie + Unity Catalog managed-MCP demo — a single FastAPI web app that runs
either as a Databricks App (on-behalf-of user) or as an external web app, chosen by
the ``AUTH_MODE`` env var. The app code is identical; only ``auth.resolve_auth``
differs. No secrets are stored in the app.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .auth import resolve_auth, app_identity_auth
from .config import load_config
from . import mcp_client as mcp

try:  # local dev convenience only; never required in production
    from dotenv import load_dotenv
    load_dotenv()
except Exception:  # pragma: no cover
    pass

CFG = load_config()
STATIC = Path(__file__).parent / "static"
app = FastAPI(title="Genie + UC managed-MCP demo")


def _auth(request: Request) -> tuple[str, dict[str, str]]:
    # Starlette lower-cases header names; pass the whole mapping to resolve_auth.
    return resolve_auth(CFG, request.headers)


def _uc_auth(request: Request) -> tuple[str, dict[str, str]]:
    # The functions server: OBO per-user by default, or the app service principal
    # when UC_USE_APP_SP is set (per-user OBO needs the unity-catalog scope).
    if CFG.is_obo and CFG.uc_use_app_sp:
        return app_identity_auth(CFG)
    return resolve_auth(CFG, request.headers)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.get("/api/config")
def config() -> JSONResponse:
    # Non-sensitive descriptors only — shown in the UI header.
    return JSONResponse({
        "auth_mode": CFG.auth_mode,
        "genie_space_id": CFG.genie_space_id,
        "genie_one_enabled": CFG.genie_one_enabled,
        "uc_catalog": CFG.uc_catalog,
        "uc_schema": CFG.uc_schema,
    })


@app.get("/api/tools")
async def tools(request: Request) -> JSONResponse:
    try:
        result = {"genie": [], "genie_one": [], "uc_functions": []}
        if CFG.genie_space_id or CFG.genie_one_enabled:
            host, headers = _auth(request)
            if CFG.genie_space_id:
                result["genie"] = await mcp.list_tools(mcp.genie_url(host, CFG.genie_space_id), headers)
            if CFG.genie_one_enabled:
                result["genie_one"] = await mcp.list_tools(mcp.genie_one_url(host), headers)
        if CFG.uc_catalog and CFG.uc_schema:
            uc_host, uc_headers = _uc_auth(request)
            result["uc_functions"] = await mcp.list_tools(
                mcp.uc_functions_url(uc_host, CFG.uc_catalog, CFG.uc_schema), uc_headers)
        return JSONResponse(result)
    except Exception as exc:  # surface a clean error to the UI
        return JSONResponse({"error": _err(exc)}, status_code=_status(exc))


@app.post("/api/query")
async def query(request: Request) -> JSONResponse:
    """Ask the space-scoped Genie Agent MCP server."""
    body = await request.json()
    question = (body.get("question") or "").strip()
    if not question:
        return JSONResponse({"error": "question is required"}, status_code=400)
    if not CFG.genie_space_id:
        return JSONResponse({"error": "GENIE_SPACE_ID is not configured"}, status_code=400)
    try:
        host, headers = _auth(request)
        answer = await mcp.ask_genie(host, headers, CFG.genie_space_id, question,
                                     conversation_id=body.get("conversation_id"))
        return JSONResponse(answer)
    except Exception as exc:
        return JSONResponse({"error": _err(exc)}, status_code=_status(exc))


@app.post("/api/query-one")
async def query_one(request: Request) -> JSONResponse:
    """Ask the workspace-wide Genie One MCP server (system.ai.genie_one_mcp)."""
    body = await request.json()
    question = (body.get("question") or "").strip()
    if not question:
        return JSONResponse({"error": "question is required"}, status_code=400)
    if not CFG.genie_one_enabled:
        return JSONResponse({"error": "Genie One is disabled (set GENIE_ONE_ENABLED=true)"}, status_code=400)
    try:
        host, headers = _auth(request)
        answer = await mcp.ask_genie_one(host, headers, question,
                                         conversation_id=body.get("conversation_id"))
        return JSONResponse(answer)
    except Exception as exc:
        return JSONResponse({"error": _err(exc)}, status_code=_status(exc))


@app.post("/api/call")
async def call(request: Request) -> JSONResponse:
    body = await request.json()
    tool_name = (body.get("tool") or "").strip()
    if not tool_name:
        return JSONResponse({"error": "tool is required"}, status_code=400)
    try:
        host, headers = _uc_auth(request)
        out = await mcp.call_uc_tool(host, headers, CFG.uc_catalog, CFG.uc_schema,
                                     tool_name, body.get("args") or {})
        return JSONResponse(out)
    except Exception as exc:
        return JSONResponse({"error": _err(exc)}, status_code=_status(exc))


def _status(exc: Exception) -> int:
    return 401 if isinstance(exc, PermissionError) else 500


def _err(exc: BaseException) -> str:
    """Flatten anyio TaskGroup ExceptionGroups to the informative leaf messages."""
    leaves: list[str] = []

    def walk(e: BaseException) -> None:
        group = getattr(e, "exceptions", None)
        if group:  # BaseExceptionGroup
            for sub in group:
                walk(sub)
        else:
            leaves.append(f"{type(e).__name__}: {e}")

    walk(exc)
    return " | ".join(dict.fromkeys(leaves)) or f"{type(exc).__name__}: {exc}"


# Mount static assets last so the API routes above take precedence.
app.mount("/static", StaticFiles(directory=STATIC), name="static")
