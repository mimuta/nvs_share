"""Auth resolution — the ONLY thing that differs between the two run modes.

Both modes end up producing the same pair ``(host, headers)`` that the MCP layer
uses to call the managed MCP servers. No secrets are stored: the SDK resolves
ambient credentials for the external mode, and the user's forwarded token is used
(never persisted) for the Databricks-App mode.
"""

from __future__ import annotations

from typing import Mapping

from databricks.sdk import WorkspaceClient

from .config import Config

FORWARDED_TOKEN_HEADER = "x-forwarded-access-token"


def _normalize_host(host: str) -> str:
    """Databricks Apps inject DATABRICKS_HOST without a scheme; add one."""
    host = (host or "").rstrip("/")
    if host and not host.startswith(("http://", "https://")):
        host = "https://" + host
    return host


def resolve_auth(cfg: Config, request_headers: Mapping[str, str] | None = None) -> tuple[str, dict[str, str]]:
    """Return ``(host, headers)`` for calling the managed MCP servers.

    * ``databricks_app`` — read the per-request ``x-forwarded-access-token`` and call
      as that user, so Genie / Unity Catalog enforce *their* permissions end to end.
    * ``external`` — let the Databricks SDK resolve ambient auth (profile / PAT /
      service principal) and mint the Authorization header.
    """
    if cfg.is_obo:
        headers = request_headers or {}
        # Header names are case-insensitive; Starlette/{FastAPI} lower-case them.
        token = headers.get(FORWARDED_TOKEN_HEADER) or headers.get(FORWARDED_TOKEN_HEADER.title())
        if not token:
            raise PermissionError(
                f"AUTH_MODE=databricks_app but no '{FORWARDED_TOKEN_HEADER}' header was "
                "present. This mode only works when the app runs as a Databricks App "
                "with user authorization enabled."
            )
        host = _normalize_host(cfg.host or WorkspaceClient().config.host)
        return host, {"Authorization": f"Bearer {token}"}

    # external: WorkspaceClient() reads profile / DATABRICKS_TOKEN / client-id+secret.
    return app_identity_auth(cfg)


def app_identity_auth(cfg: Config) -> tuple[str, dict[str, str]]:
    """Authenticate as the ambient identity resolved by the Databricks SDK.

    * external mode      → the configured profile / PAT / service principal
    * databricks_app SP  → the app's own service principal

    Used for the Unity Catalog *functions* server when ``UC_USE_APP_SP`` is set,
    because per-user OBO to that server needs the ``unity-catalog`` scope, which is
    not (yet) an available Databricks Apps user-authorization scope.
    """
    wc = WorkspaceClient(host=cfg.host) if cfg.host else WorkspaceClient()
    return _normalize_host(wc.config.host), dict(wc.config.authenticate())
