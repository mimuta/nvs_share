"""Minimal, env-based configuration.

Nothing sensitive lives in code: workspace host, Genie space and UC schema come
from environment variables, and credentials are never read or stored here (auth is
handled by the Databricks SDK / the forwarded user token — see ``auth.py``).

Two run modes, selected by ``AUTH_MODE``:

* ``external``       — the app runs anywhere (laptop, another cloud). The Databricks
                       SDK picks up ambient auth: a CLI profile, a PAT
                       (``DATABRICKS_TOKEN``), or a service principal
                       (``DATABRICKS_CLIENT_ID`` / ``DATABRICKS_CLIENT_SECRET``).
* ``databricks_app`` — the app runs as a Databricks App and calls the managed MCP
                       servers on-behalf-of the signed-in user, using the
                       ``x-forwarded-access-token`` header the platform injects.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    auth_mode: str          # "external" | "databricks_app"
    host: str               # workspace URL (auto-injected as DATABRICKS_HOST on a Databricks App)
    genie_space_id: str
    uc_catalog: str
    uc_schema: str
    uc_use_app_sp: bool     # databricks_app only: call the functions server as the app SP

    @property
    def is_obo(self) -> bool:
        return self.auth_mode == "databricks_app"


def load_config() -> Config:
    return Config(
        auth_mode=os.environ.get("AUTH_MODE", "external").strip().lower(),
        host=(os.environ.get("DATABRICKS_HOST", "") or "").rstrip("/"),
        genie_space_id=os.environ.get("GENIE_SPACE_ID", "").strip(),
        uc_catalog=os.environ.get("UC_CATALOG", "").strip(),
        uc_schema=os.environ.get("UC_SCHEMA", "").strip(),
        uc_use_app_sp=os.environ.get("UC_USE_APP_SP", "").strip().lower() in ("1", "true", "yes"),
    )
