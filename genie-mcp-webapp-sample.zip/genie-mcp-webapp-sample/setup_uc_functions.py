"""Register a couple of Unity Catalog SQL functions so the *functions* managed MCP
server has something to expose as tools.

Each UC function automatically becomes an MCP tool on
``{host}/api/2.0/mcp/functions/{catalog}/{schema}``:
  * tool **name**        = function name
  * tool **description** = the function's SQL ``COMMENT`` (what the LLM reads)
  * tool **inputs**      = the function parameters

The demo functions are deterministic business rules (credit-management themed to
match the Genie space) — no table dependency, nothing sensitive.

Usage:
  python setup_uc_functions.py --profile DEFAULT \
      --catalog <your-catalog> --schema mcp_demo --warehouse-id <id>
"""

from __future__ import annotations

import argparse
import sys

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementState


def run_sql(w: WorkspaceClient, warehouse_id: str, sql: str) -> None:
    resp = w.statement_execution.execute_statement(
        warehouse_id=warehouse_id, statement=sql, wait_timeout="30s")
    state = resp.status.state
    if state != StatementState.SUCCEEDED:
        detail = resp.status.error.message if resp.status.error else state
        raise RuntimeError(f"SQL failed ({state}): {detail}\n---\n{sql}")


def statements(catalog: str, schema: str) -> list[str]:
    fq = f"`{catalog}`.`{schema}`"
    return [
        f"CREATE SCHEMA IF NOT EXISTS {fq} COMMENT 'Genie One + UC managed-MCP demo functions'",
        f"""CREATE OR REPLACE FUNCTION {fq}.flag_credit_risk(
                credit_score INT COMMENT 'Customer credit score, 300-850',
                days_overdue INT COMMENT 'Days the current balance is overdue')
            RETURNS STRING
            COMMENT 'Classify a customer''s credit risk as LOW, MEDIUM or HIGH from their credit score and days overdue. Use this to triage an account before approving an order.'
            RETURN CASE
                WHEN credit_score < 580 OR days_overdue > 60 THEN 'HIGH'
                WHEN credit_score < 670 OR days_overdue > 15 THEN 'MEDIUM'
                ELSE 'LOW' END""",
        f"""CREATE OR REPLACE FUNCTION {fq}.recommended_credit_limit(
                annual_revenue DOUBLE COMMENT 'Customer annual revenue in USD',
                risk_band STRING COMMENT 'Risk band: LOW, MEDIUM or HIGH')
            RETURNS DOUBLE
            COMMENT 'Recommend a credit limit in USD from a customer''s annual revenue and risk band (LOW=15%, MEDIUM=8%, HIGH=3% of revenue).'
            RETURN annual_revenue * CASE upper(risk_band)
                WHEN 'LOW' THEN 0.15 WHEN 'MEDIUM' THEN 0.08 ELSE 0.03 END""",
    ]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default=None)
    ap.add_argument("--catalog", required=True)
    ap.add_argument("--schema", required=True)
    ap.add_argument("--warehouse-id", required=True)
    args = ap.parse_args()

    w = WorkspaceClient(profile=args.profile) if args.profile else WorkspaceClient()
    for sql in statements(args.catalog, args.schema):
        run_sql(w, args.warehouse_id, sql)
        print("OK:", sql.split("\n")[0].strip())
    print(f"\nDone. Functions MCP: {w.config.host}/api/2.0/mcp/functions/{args.catalog}/{args.schema}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
