# Novartis MCP solution — delivery package

Custom Unity-Catalog MCP server for Databricks (schema-as-data-product: schema, record counts,
freshness, data-quality profile), plus how to combine it with managed MCP.

Contents:
- README.md        — the solution guide (concept, managed MCP, deploy, run, test from CLI + GUI)
- bundle/          — ready-to-deploy Databricks Asset Bundle of databrickslabs/mcp
                     (databricks-vectorsearch dependency fix applied; schema defaults baked in).
                     See bundle/DEPLOY.md. Run `uv build --wheel` before deploy.
- scripts/
    create_uc_functions.py — registers the 7 UC SQL functions (from information_schema)
    test_mcp_tools.py      — acceptance test: calls all 7 tools over MCP, asserts vs ground truth
    README.md              — env-specific record + troubleshooting

Prereqs: Databricks CLI (authenticated), Python 3.10+, uv (or pip). MCP endpoint is
`https://<app-url>.databricksapps.com/api/mcp` (no trailing slash).

databrickslabs/mcp is a Databricks Labs project — experimental, no SLA.
