# Ready-to-deploy bundle — `databrickslabs/mcp` UC server

Pre-built Databricks Asset Bundle of the `databrickslabs/mcp` Unity Catalog MCP server, configured
for schema **`dfy_domain_complex_modalities_dev.publish_antibody_property_prediction`**.

**Already done in this copy:**
- `databricks-vectorsearch>=0.40` added to `pyproject.toml` (the upstream wheel omits it → App
  crashes on import without it).
- Wheel built into `.build/` (`databricks_labs_mcp-…-py3-none-any.whl`).
- `databricks.yml` variable **defaults** set to this schema, `genie_space_ids='[]'` (UC-functions
  only — no Genie space attached). Validated clean.

## Deploy

```bash
cd customers/novartis/workstreams/mcp-server/bundle

# rebuild the wheel if you changed the source (safe to run again):
uv build --wheel

# defaults are baked in, so no BUNDLE_VAR_* needed:
databricks bundle deploy -p <profile>
databricks bundle run mcp-on-apps -p <profile>
```

To target a different schema without editing the file: `databricks bundle deploy --var
schema_full_name=<catalog>.<schema> -p <profile>` (and the same on `run`).

## After deploy — grant the App's service principal

Find the App SP client id: `databricks apps get mcp-on-apps -p <profile>` (field
`service_principal_client_id`). Then:

```sql
GRANT USE CATALOG ON CATALOG dfy_domain_complex_modalities_dev TO `<app_sp_client_id>`;
GRANT USE SCHEMA, SELECT, EXECUTE
  ON SCHEMA dfy_domain_complex_modalities_dev.publish_antibody_property_prediction
  TO `<app_sp_client_id>`;
```
Also grant the SP **CAN USE** on the SQL warehouse it runs against.

> The server exposes the **UC functions** in this schema as MCP tools (none yet? see the guide's
> "Minimum set" SQL to add `get_row_counts` + `list_tables`). MCP endpoint after deploy:
> `https://<app-url>.databricksapps.com/api/mcp` **(no trailing slash)**.

Full context: [`../deliveries/2026-07-22-mcp-solution-guide.md`](../deliveries/2026-07-22-mcp-solution-guide.md).
