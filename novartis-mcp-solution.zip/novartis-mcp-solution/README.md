# MCP on Databricks — solution guide

**Prepared for:** Paolo Ciccarese (`paolo.ciccarese@novartis.com`) — Novartis, scientific computing / R&D
**From:** Mikael Mutafyan, Solutions Architect, Databricks
**Date:** 2026-07-22

> How to expose a Databricks schema (a *data product*) to an AI agent over MCP: a short note on the
> **managed** option, then the **custom UC MCP server** we're standing up — how to deploy, run, and
> test it. Substitute your own workspace host, catalog/schema, and profile throughout.

**Delivery package:** the full source (server config, the `create_uc_functions.py` generator, the
`test_mcp_tools.py` acceptance test, the ready-to-deploy bundle, and this guide) is attached as a
zip and mirrored on GitHub:
**<https://github.com/mikael-mutafyan/novartis-mcp-solution>** *(placeholder — update once uploaded)*.

---

## 1. Managed MCP (the simple option — use where it fits)

Databricks hosts **managed MCP servers** — no infrastructure, and Unity Catalog permissions are
always enforced. Turn them on once per workspace: **username (top bar) → Previews → Managed MCP
Servers**. Then point any MCP client at the URL:

| Managed server | URL | OAuth scope |
|---|---|---|
| **Genie** (natural-language Q&A over a space) | `https://<workspace-host>/api/2.0/mcp/genie/{genie_space_id}` | `genie` |
| Unity Catalog functions | `https://<workspace-host>/api/2.0/mcp/functions/{catalog}/{schema}` | `unity-catalog` |
| Vector / AI Search | `https://<workspace-host>/api/2.0/mcp/ai-search/{catalog}/{schema}/{index}` | `ai-search` |

Managed **Genie** is the fastest way to let an agent ask natural-language questions of the data with
governed access. Use the **custom server below** when you need *deterministic, typed tools* — a
stable tool surface the agent calls directly (documentation, record counts, freshness, data-quality
profile) rather than model-generated SQL. Docs:
[managed MCP](https://docs.databricks.com/aws/en/agents/mcp/managed-mcp) ·
[Genie MCP](https://docs.databricks.com/aws/en/agents/mcp/genie-mcp).

> **They combine — you don't have to choose.** The custom server's tools are just Unity Catalog
> functions, and the **managed UC-functions server** (`…/api/2.0/mcp/functions/{catalog}/{schema}`)
> exposes those *same* functions with **zero hosting** — so you can skip the custom App entirely and
> serve the 7 tools from managed MCP. Then an agent can point at **both** a managed server (Genie for
> natural-language exploration, or UC-functions for the typed tools) **and** the custom App (for any
> bespoke logic a managed server can't cover) at the same time. Same UC governance across all of them.

---

## 2. The custom solution

A **custom MCP server hosted as a Databricks App**, built on the open-source
[`databrickslabs/mcp`](https://github.com/databrickslabs/mcp) Unity Catalog server. The tool logic
lives in **Unity Catalog SQL functions**; the server is a thin, governed wrapper that turns those
functions into MCP tools an AI agent can call.

### How MCP uses the functions (the concept)

```
   AI agent / client                MCP server (Databricks App)            Unity Catalog
   (Claude, Cursor, …)     MCP        databrickslabs/mcp
        │  "how many records          │                                     │
        │   in each table?"           │                                     │
        ├───── list tools ───────────►│  at startup: discover every         │
        │                             │  function in catalog.schema (`.*`)  │
        │◄──── tools + schemas ───────┤  one function → one tool            │
        │                             │                                     │
        ├──── call get_row_counts ───►│  execute_function(                  │
        │                             │    'cat.sch.get_row_counts', args)──►│ runs the SQL function
        │◄──── rows (result) ─────────┤◄──── result ────────────────────────┤ (UC enforces permissions)
```

Three things happen, all driven by the UC functions — you never edit server code:

1. **Discovery.** At startup the server lists **every function in the configured
   `catalog.schema`** (a `catalog.schema.*` wildcard). Add a function → it becomes a tool on the
   next restart; no code change.
2. **Mapping (function → tool).** For each function the server exposes an MCP tool where:
   - **tool name** = the function name (e.g. `get_row_counts`),
   - **tool description** = the function's SQL **`COMMENT`** — this is what the LLM reads to decide
     *when* to call it, so write clear comments,
   - **input schema** = the function's parameters (e.g. `p_table STRING`), with types.
3. **Execution.** When the agent calls the tool, the server runs the underlying SQL function with
   the agent's arguments (`execute_function(name, args)`) on a Databricks warehouse and returns the
   rows. Because it's a real UC function call, **Unity Catalog enforces permissions** (the App's
   service principal, or the end user via on-behalf-of) — the agent only ever sees what it's allowed
   to.

So "adding a capability" = **writing one UC SQL function with a good `COMMENT`**; the MCP tool
surface follows automatically. That's what `create_uc_functions.py` does for the 7 below.

**The 7 tools** (each a UC SQL function; all deterministic — same input, same SQL, same shape):

| Tool | Returns | Data-contract dimension |
|---|---|---|
| `list_tables()` | tables + doc comments | documentation / schema |
| `describe_table(table)` | columns, types, comments | schema detail |
| `get_row_counts()` | exact count per table | record counts |
| `get_table_row_count(table)` | count for one table | record counts |
| `get_freshness()` | latest data date per table | freshness / SLA |
| `get_column_profile(table)` | null count + approx distinct per column | data quality |
| `get_table_stats(table)` | row count + column count | stats |

---

## 3. Deploy

```bash
# clone the OSS server + add the one missing runtime dependency
git clone https://github.com/databrickslabs/mcp && cd mcp
#   add "databricks-vectorsearch>=0.40" to [project].dependencies in pyproject.toml
#   (without it the App crashes on import: "No module named 'databricks.vector_search'")

uv build --wheel      # build the Apps-compatible wheel

# deploy + start the App (defaults resolved from databricks.yml; schema points at your data product)
export BUNDLE_VAR_schema_full_name=<catalog>.<schema>
export BUNDLE_VAR_genie_space_ids='[]'          # UC-functions only; no Genie space needed
databricks bundle deploy -p <profile>
databricks bundle run   mcp-on-apps -p <profile>
```

**Register the tools** — the server exposes whatever UC functions exist in the schema. Create them
with the generator (reads `information_schema`, so re-run after any schema change):

```bash
python create_uc_functions.py \
  --catalog <catalog> --schema <schema> \
  --warehouse <warehouse_id> --profile <profile>
```

**Grant the App's service principal** (client id from `databricks apps get mcp-on-apps`):

```sql
GRANT USE CATALOG ON CATALOG <catalog> TO `<app_sp_client_id>`;
GRANT USE SCHEMA, SELECT, EXECUTE ON SCHEMA <catalog>.<schema> TO `<app_sp_client_id>`;
-- plus CAN USE on the SQL warehouse the App runs against
```

A ready-to-deploy bundle for `dfy_domain_complex_modalities_dev.publish_antibody_property_prediction`
(dependency fix + defaults baked in) is in [`../bundle/`](../bundle/DEPLOY.md).

---

## 4. Run & connect

The App's MCP endpoint (Streamable-HTTP):

```
https://<app-url>.databricksapps.com/api/mcp        ← note: NO trailing slash
```

Connect any MCP client (Claude Desktop, Cursor, MCP Inspector, your agent) with an
`Authorization: Bearer <token>` header — `databricks auth token -p <profile>` gives a token for
testing; use on-behalf-of OAuth for production so Unity Catalog enforces the end user's permissions.

**Interactive check — AI Playground:** attach the MCP tools and ask e.g. *"how many records in each
table?"* or *"profile the patients table"*. Use a **Claude** model (`databricks-claude-sonnet-4-5`);
some GPT models reject the tool-call path.

---

## 5. Test

Two scripts (both in the solution folder). No `uv`? `pip install "mcp>=1.9.2" "httpx>=0.27"` then
`python <script> …`.

**a) Functions return correct values (SQL layer)** — `create_uc_functions.py` re-creates all 7
functions and smoke-tests them:

```bash
python create_uc_functions.py --catalog <catalog> --schema <schema> \
  --warehouse <warehouse_id> --profile <profile>
# → "done — 7 functions registered." + printed counts / freshness / profile
```

**b) Tools work over MCP (acceptance test)** — `test_mcp_tools.py` connects to the deployed App,
calls all 7 tools, and asserts each result against known values. Exits non-zero on any failure
(CI-friendly):

```bash
uv run test_mcp_tools.py --labs-url https://<app-url>.databricksapps.com --profile <profile>
```

Expected:

```
  [PASS] tool discovery: 7 UC-function tools exposed
  [PASS] list_tables / get_row_counts / get_table_row_count
  [PASS] describe_table / get_freshness
  [PASS] get_column_profile / get_table_stats
  RESULT: 9 passed, 0 failed
```

**c) From the GUI — AI Playground (no code).** The quickest visual test:

1. Left nav → **Playground**.
2. **Model:** pick one that tool-calls cleanly — **`databricks-claude-sonnet-4-5`** (⚠️ not
   `gpt-5-5`, which rejects the tool-call path with a `BAD_REQUEST`).
3. **Tools → Add tool:** add the Unity Catalog functions by name
   (`<catalog>.<schema>.get_row_counts`, `…get_freshness`, `…get_column_profile`, etc.). *If your
   Playground version lists MCP servers/Databricks Apps directly, you can instead point it at the
   App's `/api/mcp` endpoint — same functions either way.*
4. **Ask** in plain language and watch the tool calls + returned rows:
   - *"How many records are in each table?"* → `get_row_counts`
   - *"How fresh is each table?"* → `get_freshness`
   - *"Profile the patients table."* → `get_column_profile`
5. The Playground shows each tool invocation and its result — confirm the numbers match.

You can also browse the registered functions (and their comments = tool descriptions) in **Catalog
Explorer** → your catalog → schema → **Functions**, and check the App is **Running** under **Compute
→ Apps**.

---

## Notes

- **Token expired?** `databricks auth login -p <profile>` (opens a browser — click Allow), then
  retry. Symptom: `invalid_request … Refresh token is invalid`.
- Row-count / freshness / profile / stats functions **enumerate the table (and column) lists**
  (a UC SQL function can't iterate a dynamic list), so **re-run `create_uc_functions.py` when the
  schema changes.** `list_tables` / `describe_table` read `information_schema` and adapt on their
  own.
- After adding/removing *functions* (not just editing bodies), restart the App so it re-discovers
  the tool set: `databricks bundle run mcp-on-apps -p <profile>`.
- `databrickslabs/mcp` is a Databricks Labs project — experimental, no SLA.

*References are public Databricks documentation and the public `databrickslabs/mcp` repository.*
