# Custom MCP server — solution (env-specific record)

The custom UC MCP server (`databrickslabs/mcp` on a Databricks App), built and verified in Mikael's
environment (`fevm-mikael-serverless`). Customer-facing writeup:
[`../deliveries/2026-07-22-mcp-solution-guide.md`](../deliveries/2026-07-22-mcp-solution-guide.md).

## What's deployed

| Piece | Value |
|---|---|
| Workspace | `https://fevm-mikael-serverless.cloud.databricks.com` |
| Data product (schema) | `mikael_serverless_catalog.mcp_demo` |
| Tables (ground-truth counts) | `clinical_trials` = **120** · `patients` = **5000** · `adverse_events` = **842** · `compounds` = **37** |
| UC functions → MCP tools (7) | `list_tables()`, `describe_table(t)`, `get_row_counts()`, `get_table_row_count(t)`, `get_freshness()`, `get_column_profile(t)`, `get_table_stats(t)` — registered by [`create_uc_functions.py`](create_uc_functions.py) |
| MCP App | `mcp-on-apps` → `https://mcp-on-apps-7474646766200344.aws.databricksapps.com/api/mcp` (no trailing slash) |
| Warehouse | `e2665318a06bc2b3` (Serverless Starter) |
| App service principal | `21bc7751-…` (granted USE/SELECT/EXECUTE on the schema + CAN USE on the warehouse) |

## How MCP uses the functions

The server exposes UC SQL functions as MCP tools — no server code to write:
- **Discovery:** at startup it lists **every function in `catalog.schema`** (`catalog.schema.*`);
  add a function → it's a tool after the next App restart.
- **Mapping:** tool **name** = function name, **description** = the function's SQL `COMMENT` (what
  the LLM reads to decide when to call it), **inputs** = the function parameters.
- **Execution:** a tool call runs `execute_function(name, args)` on the warehouse; **Unity Catalog
  enforces permissions** (App service principal, or on-behalf-of the user).

So adding a capability = writing one UC SQL function with a clear `COMMENT`. Concept diagram in the
[solution guide](../deliveries/2026-07-22-mcp-solution-guide.md#2-the-custom-solution).

## Files here

- **`create_uc_functions.py`** — generates + registers the 7 UC functions from `information_schema`.
- **`test_mcp_tools.py`** — acceptance test: calls all 7 tools over MCP, asserts vs ground truth.

## Register the tools

```bash
python create_uc_functions.py \
  --catalog mikael_serverless_catalog --schema mcp_demo \
  --warehouse e2665318a06bc2b3 --profile fevm-mikael-serverless
# → "done — 7 functions registered." + printed counts / freshness / profile
```

| Function | Returns | Data-contract dimension |
|---|---|---|
| `list_tables()` | tables + comments | documentation / schema |
| `describe_table(p_table)` | columns, types, comments | schema detail |
| `get_row_counts()` | count per table | record counts |
| `get_table_row_count(p_table)` | count for one table | record counts |
| `get_freshness()` | latest data date per table | freshness / SLA |
| `get_column_profile(p_table)` | null count + approx distinct per column | data quality |
| `get_table_stats(p_table)` | row count + column count | stats |

## Test

`test_mcp_tools.py` connects to the deployed App over MCP, calls all 7 tools, and asserts each result
against ground truth. Exits non-zero on any failure (CI-friendly). No `uv`?
`pip install "mcp>=1.9.2" "httpx>=0.27"` then `python test_mcp_tools.py …`.

```bash
uv run test_mcp_tools.py \
  --labs-url https://mcp-on-apps-7474646766200344.aws.databricksapps.com \
  --profile  fevm-mikael-serverless
```

Confirmed result (2026-07-22):

```
  [PASS] tool discovery: 7 UC-function tools exposed — 7 present
  [PASS] list_tables returns the 4 tables
  [PASS] get_row_counts matches ground truth
  [PASS] get_table_row_count('patients') == 5000
  [PASS] describe_table('patients') columns
  [PASS] get_freshness matches ground truth
  [PASS] get_column_profile('patients') columns + nulls
  [PASS] get_column_profile sex distinct == 2 (exact)
  [PASS] get_table_stats('patients') == (5000, 5)
  RESULT: 9 passed, 0 failed
```

**Interactive check — AI Playground:** attach the `mcp_demo` MCP tools and ask e.g. *"how fresh is
each table?"* — use a **Claude** model (`databricks-claude-sonnet-4-5`); see Troubleshooting for why
not `gpt-5-5`.

> Notes: `get_table_row_count` returns a **scalar** (bare `5000`, no CSV header) — the test reads it
> as raw text. `get_column_profile` uses `approx_count_distinct`, so distinct counts on high-
> cardinality columns are approximate; the test only asserts exact values on low-cardinality columns
> (`sex` = 2) and null counts.

## How it was built (reproducible)

1. `CREATE SCHEMA mcp_demo` + 4 tables with fixed row counts (SQL Statement Execution API).
2. 7 UC functions registered by `create_uc_functions.py` (auto-surfaced as MCP tools).
3. Clone `databrickslabs/mcp`, add `databricks-vectorsearch>=0.40` to `pyproject.toml` (else the App
   crashes on import), `uv build --wheel`, then deploy:
   ```bash
   export BUNDLE_VAR_schema_full_name=mikael_serverless_catalog.mcp_demo
   export BUNDLE_VAR_genie_space_ids='[]'
   databricks bundle deploy -p fevm-mikael-serverless
   databricks bundle run   mcp-on-apps -p fevm-mikael-serverless
   ```
4. Grant the App service principal USE/SELECT/EXECUTE on the schema + CAN USE on the warehouse.

> The row-count / freshness / profile / stats functions **enumerate the table (and column) lists** (a
> UC SQL function can't iterate a dynamic list), so **re-run `create_uc_functions.py` when the schema
> changes.** After adding/removing *functions*, restart the App to re-discover the tool set:
> `databricks bundle run mcp-on-apps -p <profile>`.

## Troubleshooting

**`Refresh token is invalid` / `token refresh … http 400`** — the OAuth session expired. Re-login
(opens a browser, click **Allow**), then retry:

```bash
databricks auth login -p fevm-mikael-serverless
databricks auth token -p fevm-mikael-serverless   # should print an access_token
```

**AI Playground `BAD_REQUEST` when attaching the tools with `gpt-5-5`** — GPT-5.5 rejects the
function-tools + `reasoning_effort` combination on `/v1/chat/completions`. It's a model-compat issue,
not an MCP problem. Switch the model to **`databricks-claude-sonnet-4-5`** (verified), `…-opus-4-8`,
or a `gpt-5-6-*` model. The tools stay attached.

## Teardown

```bash
databricks apps delete mcp-on-apps -p fevm-mikael-serverless
databricks api post /api/2.0/sql/statements -p fevm-mikael-serverless --json \
  '{"warehouse_id":"e2665318a06bc2b3","statement":"DROP SCHEMA IF EXISTS mikael_serverless_catalog.mcp_demo CASCADE"}'
```
