# /// script
# requires-python = ">=3.10"
# dependencies = ["mcp>=1.9.2", "httpx>=0.27"]
# ///
"""
Acceptance test for the demo MCP server's UC-function tools.

Connects to the deployed databrickslabs/mcp App over MCP (Streamable-HTTP), calls each of the
7 tools, and asserts the result against known ground truth for
mikael_serverless_catalog.mcp_demo. Prints PASS/FAIL per tool and exits non-zero on any failure.

This is the "does the MCP surface actually work for a client" test. It complements
create_uc_functions.py, which registers the functions and smoke-tests them via SQL.

Run:
  uv run test_mcp_tools.py \
    --labs-url https://mcp-on-apps-7474646766200344.aws.databricksapps.com \
    --profile  fevm-mikael-serverless
  # (no uv? pip install "mcp>=1.9.2" "httpx>=0.27" && python test_mcp_tools.py ...)
"""
import argparse
import asyncio
import csv
import io
import json
import subprocess
import sys
from contextlib import asynccontextmanager

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

PREFIX = "mikael_serverless_catalog__mcp_demo__"

# ---- ground truth for mikael_serverless_catalog.mcp_demo ----
EXPECTED_COUNTS = {"clinical_trials": 120, "patients": 5000, "adverse_events": 842, "compounds": 37}
EXPECTED_TABLES = set(EXPECTED_COUNTS)
EXPECTED_FRESHNESS = {  # None = table has no date column
    "clinical_trials": "2021-12-27", "adverse_events": "2023-12-01",
    "compounds": None, "patients": None,
}
EXPECTED_PATIENTS_COLS = {"patient_id", "trial_id", "sex", "age", "arm"}
EXPECTED_PATIENTS_STATS = (5000, 5)  # row_count, column_count


def auth_token(profile: str) -> str:
    out = subprocess.run(["databricks", "auth", "token", "-p", profile],
                         capture_output=True, text=True)
    try:
        return json.loads(out.stdout)["access_token"]
    except Exception:
        print("Could not get token — run: databricks auth login -p", profile)
        print(out.stdout[:200], out.stderr[:200]); sys.exit(2)


@asynccontextmanager
async def mcp_session(url: str, token: str):
    async with streamablehttp_client(url, headers={"Authorization": f"Bearer {token}"}) as (r, w, _):
        async with ClientSession(r, w) as s:
            await s.initialize()
            yield s


def text_of(result) -> str:
    return "\n".join(c.text for c in result.content if getattr(c, "text", None))


def parse_csv(text: str) -> list[dict]:
    """The labs UC-function tools return CSV text (header + rows)."""
    text = text.strip()
    if not text:
        return []
    return list(csv.DictReader(io.StringIO(text)))


class Results:
    def __init__(self):
        self.passed = 0
        self.failed = 0

    def check(self, name: str, ok: bool, detail: str = ""):
        mark = "PASS" if ok else "FAIL"
        print(f"  [{mark}] {name}" + (f" — {detail}" if detail else ""))
        if ok:
            self.passed += 1
        else:
            self.failed += 1


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--labs-url", required=True, help="Databricks App base URL of databrickslabs/mcp")
    ap.add_argument("--profile", default="fevm-mikael-serverless")
    args = ap.parse_args()

    token = auth_token(args.profile)
    url = args.labs_url.rstrip("/") + "/api/mcp"   # NOTE: no trailing slash
    R = Results()

    print(f"\nTesting MCP tools at {url}\n")
    async with mcp_session(url, token) as s:
        tool_names = [t.name for t in (await s.list_tools()).tools]

        # 0) all 7 expected UC-function tools are exposed
        expected_tools = {PREFIX + n for n in [
            "list_tables", "describe_table", "get_row_counts", "get_table_row_count",
            "get_freshness", "get_column_profile", "get_table_stats"]}
        missing = expected_tools - set(tool_names)
        R.check("tool discovery: 7 UC-function tools exposed", not missing,
                f"missing: {sorted(missing)}" if missing else f"{len(expected_tools)} present")

        async def call(fn, **args):
            return parse_csv(text_of(await s.call_tool(PREFIX + fn, args)))

        # 1) list_tables -> the 4 expected tables
        rows = await call("list_tables")
        got = {r["table_name"] for r in rows}
        R.check("list_tables returns the 4 tables", got == EXPECTED_TABLES, f"got {sorted(got)}")

        # 2) get_row_counts -> exact counts
        rows = await call("get_row_counts")
        got = {r["table_name"]: int(r["row_count"]) for r in rows}
        R.check("get_row_counts matches ground truth", got == EXPECTED_COUNTS, f"got {got}")

        # 3) get_table_row_count('patients') -> 5000
        #    This function returns a scalar BIGINT, so the tool emits a bare value (e.g. "5000"),
        #    not CSV with a header — read the raw text, not parse_csv.
        raw = text_of(await s.call_tool(PREFIX + "get_table_row_count", {"p_table": "patients"})).strip()
        val = int(raw) if raw.replace(",", "").isdigit() else None
        R.check("get_table_row_count('patients') == 5000", val == 5000, f"got {raw!r}")

        # 4) describe_table('patients') -> 5 columns, expected names
        rows = await call("describe_table", p_table="patients")
        cols = {r["column_name"] for r in rows}
        R.check("describe_table('patients') columns", cols == EXPECTED_PATIENTS_COLS, f"got {sorted(cols)}")

        # 5) get_freshness -> latest date per table (null where no date col)
        rows = await call("get_freshness")
        got = {r["table_name"]: (r["latest_date"] or None) for r in rows}
        R.check("get_freshness matches ground truth", got == EXPECTED_FRESHNESS, f"got {got}")

        # 6) get_column_profile('patients') -> per-column nulls (all 0 here) + sane distincts
        rows = await call("get_column_profile", p_table="patients")
        cols = {r["column_name"] for r in rows}
        all_zero_nulls = all(int(r["null_count"]) == 0 for r in rows)
        sex_distinct = next((int(r["distinct_count"]) for r in rows if r["column_name"] == "sex"), None)
        R.check("get_column_profile('patients') columns + nulls", cols == EXPECTED_PATIENTS_COLS and all_zero_nulls,
                f"cols {sorted(cols)}, all-zero-nulls={all_zero_nulls}")
        R.check("get_column_profile sex distinct == 2 (exact)", sex_distinct == 2, f"got {sex_distinct}")

        # 7) get_table_stats('patients') -> (5000, 5)
        rows = await call("get_table_stats", p_table="patients")
        stats = (int(rows[0]["row_count"]), int(rows[0]["column_count"])) if rows else None
        R.check("get_table_stats('patients') == (5000, 5)", stats == EXPECTED_PATIENTS_STATS, f"got {stats}")

    print(f"\n{'='*60}\n  RESULT: {R.passed} passed, {R.failed} failed\n{'='*60}\n")
    sys.exit(1 if R.failed else 0)


if __name__ == "__main__":
    asyncio.run(main())
