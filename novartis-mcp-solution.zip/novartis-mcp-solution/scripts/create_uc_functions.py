#!/usr/bin/env python3
"""
Generate + register the demo's UC SQL functions from information_schema, so they stay in sync
with the actual tables in the schema. These functions are what the databrickslabs/mcp UC server
exposes as MCP tools.

Functions created (all deterministic, one call each):
  list_tables()               — schema discovery: tables + doc comments
  describe_table(p_table)      — columns / types / comments for one table
  get_row_counts()             — exact record count per table   (record counts)
  get_table_row_count(p_table) — exact count for one table
  get_freshness()              — latest data date per table     (ODCS freshness / SLA)
  get_column_profile(p_table)  — null count + approx distinct per column  (data quality)
  get_table_stats(p_table)     — row count + column count for one table

Row-count / freshness / profile functions hard-code the table & column lists (a UC SQL function
can't iterate a dynamic list), so RE-RUN this whenever the schema changes.

Usage:
  python create_uc_functions.py --catalog <cat> --schema <sch> --warehouse <id> --profile <profile>
Defaults target the demo: mikael_serverless_catalog.mcp_demo.
"""
import argparse
import json
import subprocess
import sys


def sql(stmt, catalog, schema, warehouse, profile, wait="50s"):
    payload = {
        "warehouse_id": warehouse, "catalog": catalog, "schema": schema,
        "wait_timeout": wait, "statement": stmt,
    }
    out = subprocess.run(
        ["databricks", "api", "post", "/api/2.0/sql/statements", "-p", profile,
         "--json", json.dumps(payload)],
        capture_output=True, text=True,
    )
    try:
        d = json.loads(out.stdout)
    except Exception:
        print("  ! could not parse:", out.stdout[:200], out.stderr[:200]); sys.exit(1)
    st = d.get("status", {}).get("state")
    if st == "FAILED":
        return {"FAILED": d.get("status", {}).get("error", {}).get("message", "")[:300]}
    return {"ok": st, "rows": d.get("result", {}).get("data_array")}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--catalog", default="mikael_serverless_catalog")
    ap.add_argument("--schema", default="mcp_demo")
    ap.add_argument("--warehouse", default="e2665318a06bc2b3")
    ap.add_argument("--profile", default="fevm-mikael-serverless")
    a = ap.parse_args()
    C, S = a.catalog, a.schema

    def run(stmt):
        return sql(stmt, C, S, a.warehouse, a.profile)

    # discover tables + columns + date columns from information_schema
    tbls = [r[0] for r in run(
        f"SELECT table_name FROM {C}.information_schema.tables "
        f"WHERE table_schema='{S}' ORDER BY table_name")["rows"]]
    cols = run(
        f"SELECT table_name, column_name FROM {C}.information_schema.columns "
        f"WHERE table_schema='{S}' ORDER BY table_name, ordinal_position")["rows"]
    date_cols = {r[0]: r[1] for r in run(
        f"SELECT table_name, column_name FROM {C}.information_schema.columns "
        f"WHERE table_schema='{S}' AND (full_data_type ILIKE '%date%' OR full_data_type ILIKE '%timestamp%') "
        f"ORDER BY table_name, ordinal_position")["rows"]}  # first date col per table wins
    cols_by = {}
    for tn, cn in cols:
        cols_by.setdefault(tn, []).append(cn)

    print(f"tables: {tbls}")
    print(f"date columns: {date_cols}")

    # --- schema discovery (information_schema-based, auto-adapting) ---
    run(f"""CREATE OR REPLACE FUNCTION {C}.{S}.list_tables()
RETURNS TABLE(table_name STRING, comment STRING)
COMMENT 'List the tables in the data product schema with their documentation comment.'
RETURN SELECT table_name, comment FROM {C}.information_schema.tables WHERE table_schema='{S}'""")

    run(f"""CREATE OR REPLACE FUNCTION {C}.{S}.describe_table(p_table STRING)
RETURNS TABLE(column_name STRING, data_type STRING, comment STRING)
COMMENT 'Return the columns, data types, and comments for a given table.'
RETURN SELECT column_name, full_data_type, comment FROM {C}.information_schema.columns
       WHERE table_schema='{S}' AND table_name=p_table ORDER BY ordinal_position""")

    # --- record counts (hard-coded table list) ---
    counts = " UNION ALL ".join(f"SELECT '{t}', count(*) FROM {C}.{S}.{t}" for t in tbls)
    run(f"""CREATE OR REPLACE FUNCTION {C}.{S}.get_row_counts()
RETURNS TABLE(table_name STRING, row_count BIGINT)
COMMENT 'Return the exact record count for every table in the data product.'
RETURN {counts}""")

    when = " ".join(f"WHEN '{t}' THEN (SELECT count(*) FROM {C}.{S}.{t})" for t in tbls)
    run(f"""CREATE OR REPLACE FUNCTION {C}.{S}.get_table_row_count(p_table STRING)
RETURNS BIGINT
COMMENT 'Return the exact record count for a single named table.'
RETURN CASE p_table {when} ELSE NULL END""")

    # --- freshness (latest date per table) ---
    fresh = " UNION ALL ".join(
        (f"SELECT '{t}', CAST(MAX({date_cols[t]}) AS STRING) FROM {C}.{S}.{t}"
         if t in date_cols else f"SELECT '{t}', CAST(NULL AS STRING)")
        for t in tbls)
    run(f"""CREATE OR REPLACE FUNCTION {C}.{S}.get_freshness()
RETURNS TABLE(table_name STRING, latest_date STRING)
COMMENT 'Return the latest data date (freshness) for each table; null when the table has no date column.'
RETURN {fresh}""")

    # --- table stats (rows + column count) ---
    # NB: a UC-function parameter can't be referenced inside a correlated information_schema
    #     subquery (UNRESOLVED_COLUMN p_table), so hard-code both counts via CASE like row counts.
    rows_when = " ".join(f"WHEN '{t}' THEN (SELECT count(*) FROM {C}.{S}.{t})" for t in tbls)
    cols_when = " ".join(f"WHEN '{t}' THEN {len(cols_by[t])}" for t in tbls)
    run(f"""CREATE OR REPLACE FUNCTION {C}.{S}.get_table_stats(p_table STRING)
RETURNS TABLE(table_name STRING, row_count BIGINT, column_count BIGINT)
COMMENT 'Return row count and column count for a single named table.'
RETURN SELECT p_table,
  CASE p_table {rows_when} ELSE NULL END,
  CASE p_table {cols_when} ELSE NULL END""")

    # --- column profile (nulls + approx distinct per column) ---
    blocks = []
    for t in tbls:
        for c in cols_by[t]:
            blocks.append(
                f"SELECT '{t}' AS tbl, '{c}' AS column_name, "
                f"(SELECT count(*) FROM {C}.{S}.{t}) - (SELECT count(`{c}`) FROM {C}.{S}.{t}) AS null_count, "
                f"(SELECT approx_count_distinct(`{c}`) FROM {C}.{S}.{t}) AS distinct_count")
    run(f"""CREATE OR REPLACE FUNCTION {C}.{S}.get_column_profile(p_table STRING)
RETURNS TABLE(column_name STRING, null_count BIGINT, distinct_count BIGINT)
COMMENT 'Simple data-quality profile (null count + approx distinct count) per column for one table.'
RETURN SELECT column_name, null_count, distinct_count FROM (
{' UNION ALL '.join(blocks)}
) WHERE tbl = p_table""")

    # smoke test
    print("get_row_counts ->", run("SELECT * FROM get_row_counts() ORDER BY table_name")["rows"])
    print("get_freshness  ->", run("SELECT * FROM get_freshness() ORDER BY table_name")["rows"])
    print("get_column_profile('patients') ->", run("SELECT * FROM get_column_profile('patients')")["rows"])
    print("done — 7 functions registered.")


if __name__ == "__main__":
    main()
