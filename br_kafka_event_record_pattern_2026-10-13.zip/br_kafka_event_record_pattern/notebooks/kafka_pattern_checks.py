# Databricks notebook source
# MAGIC %md
# MAGIC # Checks for the Kafka event-record pattern
# MAGIC
# MAGIC Runs after each pipeline update. It reads `topics.yaml`, so it checks whatever topics and
# MAGIC recipes the configuration lists:
# MAGIC
# MAGIC - each recipe's `key_columns` are unique (the role the MERGE keys played in FP12);
# MAGIC - each record table holds one row per key, with no delete markers;
# MAGIC - every deleted key's history is closed;
# MAGIC - message counts: total, invalid, deletes, and backfilled rows;
# MAGIC - how each materialized view refreshed on the last update (incremental or full).

# COMMAND ----------

# MAGIC %pip install pyyaml==6.0.2 -q

# COMMAND ----------

dbutils.widgets.text("catalog", "", "Catalog")
dbutils.widgets.text("schema", "", "Schema")
dbutils.widgets.text("config_path", "", "topics.yaml path")
dbutils.widgets.text("pipeline_id", "", "Pipeline id")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA = dbutils.widgets.get("schema")
CONFIG_PATH = dbutils.widgets.get("config_path")
PIPELINE_ID = dbutils.widgets.get("pipeline_id")

# COMMAND ----------

import json
import yaml

with open(CONFIG_PATH) as f:
    cfg = yaml.safe_load(f)


def fq(name):
    return f"{CATALOG}.{SCHEMA}.{name}"


def one(sql):
    return spark.sql(sql).collect()[0][0]


results = []


def check(name, ok, detail):
    results.append((name, "PASS" if ok else "FAIL", detail))


for t in cfg["topics"]:
    e = t["entity"]
    ev = fq(f"{e}_event")
    total = one(f"SELECT count(*) FROM {ev}")
    invalid = one(f"SELECT count(*) FROM {ev} WHERE NOT is_valid")
    deletes = one(f"SELECT count(*) FROM {ev} WHERE is_delete_event")
    bf_id = (t.get("backfill") or {}).get("batch_id", cfg["defaults"].get("backfill", {}).get("batch_id", -1))
    backfill = one(f"SELECT count(*) FROM {ev} WHERE ingestion_batch_id = {bf_id}")
    check(f"{e}_event counts", total > 0,
          f"{total} messages: {invalid} invalid (kept, flagged), {deletes} deletes, {backfill} backfilled")

    rec = fq(f"{e}_record")
    rows, keys = spark.sql(f"SELECT count(*), count(DISTINCT kafka_key) FROM {rec}").collect()[0]
    markers = one(f"SELECT count(*) FROM {rec} WHERE get_json_object(payload_json, '$.deleted') = 'true'")
    check(f"{e}_record one row per key", rows == keys and markers == 0,
          f"{rows} rows, {keys} keys, {markers} delete markers")

    # Replay proof: recompute the latest valid version per key from the event table alone, in
    # Kafka order, and compare with the record table. Late arrivals and duplicates must not matter.
    seq = t.get("sequence_by", cfg["defaults"]["sequence_by"])
    order = ", ".join(
        (f"coalesce(CAST(get_json_object(payload_json, '{c}') AS TIMESTAMP), kafka_timestamp) DESC"
         if c.startswith("$.") else f"{c} DESC") for c in seq) + ", ingestion_batch_id DESC"
    mismatches = one(f"""
        WITH latest AS (
          SELECT kafka_key, payload_json, is_delete_event FROM {ev} WHERE is_valid
          QUALIFY row_number() OVER (PARTITION BY kafka_key ORDER BY {order}) = 1),
        expected AS (SELECT kafka_key, payload_json FROM latest WHERE NOT is_delete_event)
        SELECT count(*) FROM (
          (SELECT kafka_key, payload_json FROM expected EXCEPT SELECT kafka_key, payload_json FROM {rec})
          UNION ALL
          (SELECT kafka_key, payload_json FROM {rec} EXCEPT SELECT kafka_key, payload_json FROM expected))""")
    check(f"{e}_record matches a replay of {e}_event", mismatches == 0, f"{mismatches} differing rows")

    hist = fq(f"{e}_record_history")
    open_deleted = one(f"""
        SELECT count(*) FROM {hist} h
        JOIN (SELECT DISTINCT kafka_key FROM {ev} WHERE is_delete_event) d USING (kafka_key)
        WHERE h.__END_AT IS NULL""")
    versions = one(f"SELECT count(*) FROM {hist}")
    no_start = one(f"SELECT count(*) FROM {hist} WHERE __START_AT IS NULL")
    check(f"{e}_record_history deletes closed", open_deleted == 0 and no_start == 0,
          f"{versions} versions; {open_deleted} deleted keys still open; {no_start} rows without a start")

    for r in t.get("recipes", []):
        cols = ", ".join(r["key_columns"])
        n, distinct = spark.sql(
            f"SELECT count(*), count(DISTINCT struct({cols})) FROM {fq(r['name'])}").collect()[0]
        check(f"{r['name']} unique on ({cols})", n == distinct, f"{n} rows, {distinct} distinct keys")

# COMMAND ----------

# How each materialized view refreshed on its most recent update.
if PIPELINE_ID:
    plans = spark.sql(f"""
        SELECT origin.flow_name AS flow,
               details:planning_information:technique_information AS techniques
        FROM event_log('{PIPELINE_ID}')
        WHERE event_type = 'planning_information'
        QUALIFY row_number() OVER (PARTITION BY origin.flow_name ORDER BY timestamp DESC) = 1
    """).collect()

    for p in plans:
        chosen = [x.get("maintenance_type") for x in json.loads(p.techniques) if x.get("is_chosen")]
        results.append((f"{p.flow.split('.')[-1]} refresh", "INFO", ", ".join(chosen) or "n/a"))

# COMMAND ----------

display(spark.createDataFrame(results, "check STRING, result STRING, detail STRING"))
failed = [r for r in results if r[1] == "FAIL"]
assert not failed, f"{len(failed)} check(s) failed: {failed}"
dbutils.notebook.exit(json.dumps([{"check": c, "result": r, "detail": d} for c, r, d in results]))
