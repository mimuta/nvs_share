-- FP12 recipe: ANIMAL_COMMENT_V1
-- Supplied by BR Data Factory. Everything from SELECT down is unchanged from the
-- supplied file. The pipeline points the table name in FROM at the record table
-- through a temporary view, so this file never needs editing. The header notes the comments
-- below refer to stay with the files Data Factory supplied.
-- One row per comment, exploded animal -> studies -> comments. key_columns is (_source_key, oiv_id).
SELECT
  kafka_animal.kafka_key AS _source_key,
  CAST(get_json_object(kafka_study_animal.value, '$.studySid') AS STRING) AS study_sid,
  CAST(get_json_object(kafka_study_animal.value, '$.oivId') AS BIGINT) AS study_animal_oiv_id,
  CAST(get_json_object(kafka_animal.payload_json, '$.smfId') AS STRING) AS animal_smf_id,
  CAST(get_json_object(kafka_comment.value, '$.oivId') AS BIGINT) AS oiv_id,
  -- TIMESTAMP, not DATE -- comments carry a full instant. See the fidelity note.
  CAST(get_json_object(kafka_comment.value, '$.date') AS TIMESTAMP) AS date,
  CAST(get_json_object(kafka_comment.value, '$.level') AS STRING) AS level,
  CAST(get_json_object(kafka_comment.value, '$.context') AS STRING) AS context,
  -- Arrays kept as raw JSON text -- see the validation note in the header.
  CAST(get_json_object(kafka_comment.value, '$.measurementOivIds') AS STRING) AS measurement_oiv_ids,
  CAST(get_json_object(kafka_comment.value, '$.interventionOivIds') AS STRING) AS intervention_oiv_ids,
  CAST(get_json_object(kafka_comment.value, '$.comment') AS STRING) AS comment,
  CAST(get_json_object(kafka_comment.value, '$.isImportant') AS BOOLEAN) AS is_important,
  CAST(get_json_object(kafka_comment.value, '$.createdBy') AS STRING) AS created_by,
  CAST(get_json_object(kafka_comment.value, '$.createdAt') AS TIMESTAMP) AS created_at,
  CAST(get_json_object(kafka_comment.value, '$.modifiedBy') AS STRING) AS modified_by,
  CAST(get_json_object(kafka_comment.value, '$.modifiedAt') AS TIMESTAMP) AS modified_at
FROM kafka_animal
LATERAL VIEW explode(
  from_json(get_json_object(kafka_animal.payload_json, '$.studies'), 'array<string>')
) kafka_study_animal AS value
LATERAL VIEW explode(
  from_json(get_json_object(kafka_study_animal.value, '$.comments'), 'array<string>')
) kafka_comment AS value
-- Snowflake's `WHERE deleted = 0`; see the soft-delete note in the header.
WHERE get_json_object(kafka_animal.payload_json, '$.deleted') IS DISTINCT FROM 'true'
