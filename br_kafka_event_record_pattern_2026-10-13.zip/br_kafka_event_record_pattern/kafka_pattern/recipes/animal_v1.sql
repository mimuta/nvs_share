-- FP12 recipe: ANIMAL_V1
-- Supplied by BR Data Factory. Everything from SELECT down is unchanged from the
-- supplied file. The pipeline points the table name in FROM at the record table
-- through a temporary view, so this file never needs editing. The header notes the comments
-- below refer to stay with the files Data Factory supplied.
-- One row per animal. A 1:1 projection of the record payload, so key_columns is _source_key.
SELECT
  kafka_animal.kafka_key AS _source_key,
  CAST(get_json_object(kafka_animal.payload_json, '$.smfId') AS STRING) AS smf_id,
  CAST(get_json_object(kafka_animal.payload_json, '$.speciesAndStrain') AS STRING) AS species_and_strain,
  CAST(get_json_object(kafka_animal.payload_json, '$.genotype') AS STRING) AS genotype,
  CAST(get_json_object(kafka_animal.payload_json, '$.sex') AS STRING) AS sex,
  CAST(get_json_object(kafka_animal.payload_json, '$.dateOfBirth') AS DATE) AS date_of_birth,
  CAST(get_json_object(kafka_animal.payload_json, '$.animalProvider') AS STRING) AS animal_provider,
  CAST(get_json_object(kafka_animal.payload_json, '$.namsId') AS BIGINT) AS nams_id,
  CAST(get_json_object(kafka_animal.payload_json, '$.mosaicId') AS STRING) AS mosaic_id,
  CAST(get_json_object(kafka_animal.payload_json, '$.fateCode.abbreviation') AS STRING) AS fate_code_abbreviation,
  CAST(get_json_object(kafka_animal.payload_json, '$.fateCode.name') AS STRING) AS fate_code_name,
  CAST(get_json_object(kafka_animal.payload_json, '$.fateCode.date') AS DATE) AS fate_code_date,
  -- STRING, not TIME/TIMESTAMP -- see the fidelity note in the header.
  CAST(get_json_object(kafka_animal.payload_json, '$.fateCode.time') AS STRING) AS fate_code_time,
  CAST(get_json_object(kafka_animal.payload_json, '$.fateCode.comment') AS STRING) AS fate_code_comment,
  -- Array of objects, kept as raw JSON text -- see the fidelity note in the header.
  CAST(get_json_object(kafka_animal.payload_json, '$.studyTransfers') AS STRING) AS study_transfers,
  CAST(get_json_object(kafka_animal.payload_json, '$.createdBy') AS STRING) AS created_by,
  CAST(get_json_object(kafka_animal.payload_json, '$.createdAt') AS TIMESTAMP) AS created_at,
  CAST(get_json_object(kafka_animal.payload_json, '$.modifiedBy') AS STRING) AS modified_by,
  CAST(get_json_object(kafka_animal.payload_json, '$.modifiedAt') AS TIMESTAMP) AS modified_at
FROM kafka_animal
-- Snowflake's `WHERE deleted = 0`; see the soft-delete note in the header.
-- IS DISTINCT FROM, not <>, or every live row is dropped.
WHERE get_json_object(kafka_animal.payload_json, '$.deleted') IS DISTINCT FROM 'true'
