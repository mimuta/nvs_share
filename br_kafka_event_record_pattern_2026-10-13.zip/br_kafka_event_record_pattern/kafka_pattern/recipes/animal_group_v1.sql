-- FP12 recipe: ANIMAL_GROUP_V1
-- Supplied by BR Data Factory. Everything from SELECT down is unchanged from the
-- supplied file. The pipeline points the table name in FROM at the record table
-- through a temporary view, so this file never needs editing. The header notes the comments
-- below refer to stay with the files Data Factory supplied.
-- One row per study group, exploded from the STUDY record (kafka_study). key_columns is (_source_key, oiv_id).
SELECT
  kafka_study.kafka_key AS _source_key,
  CAST(get_json_object(kafka_study.payload_json, '$.sid') AS STRING) AS study_sid,
  CAST(get_json_object(kafka_group.value, '$.oivId') AS BIGINT) AS oiv_id,
  CAST(get_json_object(kafka_group.value, '$.name') AS STRING) AS name,
  from_json(get_json_object(kafka_group.value, '$.groupTypes'), 'array<string>') AS group_types,
  CAST(get_json_object(kafka_group.value, '$.color') AS STRING) AS color,
  CAST(get_json_object(kafka_group.value, '$.speciesAndStrain') AS STRING) AS species_and_strain,
  CAST(get_json_object(kafka_group.value, '$.genotype') AS STRING) AS genotype,
  CAST(get_json_object(kafka_group.value, '$.sex') AS STRING) AS sex,
  CAST(get_json_object(kafka_group.value, '$.ageAtStudyStart') AS STRING) AS age_at_study_start,
  CAST(get_json_object(kafka_group.value, '$.plannedAnimalCount') AS BIGINT) AS planned_animal_count,
  CAST(get_json_object(kafka_group.value, '$.comments') AS STRING) AS comments,
  CAST(get_json_object(kafka_group.value, '$.createdBy') AS STRING) AS created_by,
  CAST(get_json_object(kafka_group.value, '$.createdAt') AS TIMESTAMP) AS created_at,
  CAST(get_json_object(kafka_group.value, '$.modifiedBy') AS STRING) AS modified_by,
  CAST(get_json_object(kafka_group.value, '$.modifiedAt') AS TIMESTAMP) AS modified_at
FROM kafka_study
LATERAL VIEW explode(
  from_json(get_json_object(kafka_study.payload_json, '$.groups'), 'array<string>')
) kafka_group AS value
-- Snowflake's `WHERE deleted = 0`; see the soft-delete note in the header.
-- IS DISTINCT FROM, not <>, so rows with no `deleted` key at all (NULL) are
-- kept rather than silently dropped by three-valued logic.
WHERE get_json_object(kafka_study.payload_json, '$.deleted') IS DISTINCT FROM 'true'
