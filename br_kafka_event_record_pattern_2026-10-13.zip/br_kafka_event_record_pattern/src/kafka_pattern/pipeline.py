# Kafka event-record pattern, generated from configuration.
#
# One Lakeflow pipeline builds every table for every topic listed in kafka_pattern/topics.yaml:
#
#   source (Kafka, or files with the Kafka columns)
#     -> <entity>_event           append-only, every message kept, protected from full refresh
#     -> <entity>_record          latest version per key (AUTO CDC, SCD Type 1)
#     -> <entity>_record_history  every version per key (AUTO CDC, SCD Type 2)
#     -> one materialized view per FP12 recipe, from the record table, SQL unchanged
#
# The event table feeds the record tables in sequence, so a rebuild or a day-one backfill only
# ever needs the event table. Nothing here names a topic or a table: everything comes from config.

import json
import os
import time

import pandas as pd
import yaml
from pyspark import pipelines as dp
from pyspark.sql import functions as F

CONFIG_PATH = spark.conf.get("kafka_pattern.config_path")
CATALOG = spark.conf.get("kafka_pattern.catalog")
SCHEMA = spark.conf.get("kafka_pattern.schema")
LANDING_ROOT = spark.conf.get("kafka_pattern.landing_root")
CONFIG_DIR = os.path.dirname(CONFIG_PATH)

# One id per pipeline update, the counterpart of FP11's micro-batch id. The graph is rebuilt on
# every update, so this value is fixed for the whole update.
UPDATE_BATCH_ID = int(time.time())

# The exact columns a Kafka source returns. The file lane carries the same columns, so the rest of
# the pipeline cannot tell the two apart.
KAFKA_SOURCE_SCHEMA = (
    "key BINARY, value BINARY, topic STRING, partition INT, offset BIGINT, "
    "timestamp TIMESTAMP, timestampType INT"
)


def load_config(path):
    with open(path) as f:
        cfg = yaml.safe_load(f)
    defaults = cfg.get("defaults", {})
    topics = []
    for entry in cfg["topics"]:
        merged = json.loads(json.dumps(defaults))
        for k, v in entry.items():
            if isinstance(v, dict) and isinstance(merged.get(k), dict):
                merged[k] = {**merged[k], **v}
            else:
                merged[k] = v
        topics.append(merged)
    validate_config(topics)
    return topics


def validate_config(topics):
    """Fail loudly on a config typo instead of silently changing behavior."""
    seen_entities, seen_outputs = set(), set()
    for t in topics:
        e = t.get("entity")
        problems = []
        if not e or e in seen_entities:
            problems.append(f"entity {e!r} is missing or repeated")
        seen_entities.add(e)
        if t["source"].get("mode") not in ("volume", "kafka"):
            problems.append(f"source.mode must be volume or kafka, not {t['source'].get('mode')!r}")
        if t["source"].get("mode") == "kafka" and str(t["source"]["kafka"].get("bootstrap_servers", "")).startswith("REPLACE"):
            problems.append("source.kafka.bootstrap_servers is still a placeholder")
        if t["validation"].get("json_schema_version", "auto") not in ("auto", *SCHEMA_VERSIONS):
            problems.append(f"validation.json_schema_version must be auto or one of {sorted(SCHEMA_VERSIONS)}")
        if t["validation"].get("on_invalid") not in ("quarantine", "fail"):
            problems.append(f"validation.on_invalid must be quarantine or fail, not {t['validation'].get('on_invalid')!r}")
        if not set(t.get("scd_types", [])) or not set(t["scd_types"]) <= {1, 2}:
            problems.append(f"scd_types must be a non-empty subset of [1, 2], not {t.get('scd_types')!r}")
        if t.get("payload_mode", "raw") != "raw":
            problems.append("payload_mode supports raw only")
        if t.get("recipes") and 1 not in t["scd_types"]:
            problems.append("recipes read the latest-version record table, so scd_types must include 1")
        for r in t.get("recipes") or []:
            if r["name"] in seen_outputs:
                problems.append(f"recipe name {r['name']!r} is repeated")
            seen_outputs.add(r["name"])
        if problems:
            raise ValueError(f"topics.yaml, topic {e!r}: " + "; ".join(problems))


def read_text(rel_path):
    with open(os.path.join(CONFIG_DIR, rel_path)) as f:
        return f.read()


# JSON Schema versions a contract can use. "auto" reads the contract's own "$schema" line and
# falls back to 2020-12 when the contract has none.
SCHEMA_VERSIONS = {
    "draft-04": "Draft4Validator",
    "draft-06": "Draft6Validator",
    "draft-07": "Draft7Validator",
    "2019-09": "Draft201909Validator",
    "2020-12": "Draft202012Validator",
}


def validator_class(schema, version):
    """Pick the JSON Schema validator for a contract: from config, or from its "$schema" line."""
    import jsonschema

    if version and version != "auto":
        return getattr(jsonschema, SCHEMA_VERSIONS[version])
    return jsonschema.validators.validator_for(schema, default=jsonschema.Draft202012Validator)


def make_validator(schema_text, skip_delete_markers, version="auto"):
    """A pandas UDF that checks each payload against the topic's JSON Schema contract."""
    schema = json.loads(schema_text)
    # Fail at the start of the update, not row by row, if the contract itself is not valid.
    validator_class(schema, version).check_schema(schema)

    @F.pandas_udf("struct<is_valid:boolean,validation_error:string>")
    def validate(payload: pd.Series, is_delete: pd.Series) -> pd.DataFrame:
        validator = validator_class(schema, version)(schema)
        valid, errors = [], []
        for text, deleted in zip(payload, is_delete):
            if deleted and skip_delete_markers:
                valid.append(True)
                errors.append(None)
                continue
            try:
                doc = json.loads(text)
            except Exception as exc:  # not JSON at all
                valid.append(False)
                errors.append(f"$: not valid JSON ({exc})"[:1000])
                continue
            found = sorted(validator.iter_errors(doc), key=lambda e: list(e.path))
            if found:
                msg = "; ".join(
                    f"$/{'/'.join(map(str, e.path))}: {e.message}" for e in found[:3]
                )
                valid.append(False)
                errors.append(msg[:1000])
            else:
                valid.append(True)
                errors.append(None)
        return pd.DataFrame({"is_valid": valid, "validation_error": errors})

    return validate


def to_event_columns(df, t, batch_id):
    """Shape Kafka source columns into the FP11 event table, then add the contract check."""
    payload = F.col("value").cast("string")
    df = df.select(
        F.col("key").cast("string").alias("kafka_key"),
        F.col("topic").alias("kafka_topic"),
        F.col("partition").alias("kafka_partition"),
        F.col("offset").alias("kafka_offset"),
        F.col("timestamp").alias("kafka_timestamp"),
        F.col("timestampType").alias("kafka_timestamp_type"),
        F.coalesce(
            F.get_json_object(payload, t["delete_flag_path"]) == F.lit("true"), F.lit(False)
        ).alias("is_delete_event"),
        F.lit(batch_id).cast("bigint").alias("ingestion_batch_id"),
        F.current_timestamp().alias("ingested_at"),
        F.current_date().alias("ingestion_date"),
        payload.alias("payload_json"),
    )
    return add_validation(df, t)


def add_validation(df, t):
    v = t["validation"]
    if v.get("enabled"):
        check = make_validator(
            read_text(t["contract"]["schema"]),
            v.get("skip_delete_markers", True),
            v.get("json_schema_version", "auto"),
        )
        result = check(F.col("payload_json"), F.col("is_delete_event"))
        df = df.withColumn("_check", result)
        df = df.withColumn("is_valid", F.col("_check.is_valid")).withColumn(
            "validation_error", F.col("_check.validation_error")
        ).drop("_check")
    else:
        df = df.withColumn("is_valid", F.lit(True)).withColumn(
            "validation_error", F.lit(None).cast("string")
        )
    return df.withColumn("contract_version", F.lit(t["contract"].get("version")))


def read_source(t):
    src = t["source"]
    if src["mode"] == "kafka":
        k = src["kafka"]
        reader = (
            spark.readStream.format("kafka")
            .option("kafka.bootstrap.servers", k["bootstrap_servers"])
            .option("subscribe", t["topic"])
            .option("startingOffsets", k.get("starting_offsets", "earliest"))
            # True stops the update if offsets were lost to retention (an idle gap longer than the
            # topic keeps messages), so a silent gap in the event table is impossible.
            .option("failOnDataLoss", str(k.get("fail_on_data_loss", True)).lower())
        )
        for opt, val in (k.get("options") or {}).items():
            # Never put credentials in topics.yaml: write "secret:<scope>/<key>" to read a secret.
            if isinstance(val, str) and val.startswith("secret:"):
                scope, key = val[len("secret:"):].split("/", 1)
                val = dbutils.secrets.get(scope=scope, key=key)
            reader = reader.option(opt, val)
        return reader.load().select(*[c.split()[0] for c in KAFKA_SOURCE_SCHEMA.split(", ")])
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "parquet")
        .schema(KAFKA_SOURCE_SCHEMA)
        .load(f"{LANDING_ROOT}/{t['topic']}/")
    )


def build_topic(t):
    e = t["entity"]
    event, record, history = f"{e}_event", f"{e}_record", f"{e}_record_history"

    # 1. Event table: every message, valid or not, deletes included. Never fully refreshed, because
    #    it is the replayable record of everything Kafka delivered.
    dp.create_streaming_table(
        name=event,
        comment=f"Append-only event table for topic {t['topic']}: every message with Kafka metadata and full payload.",
        cluster_by=["ingestion_date"],
        table_properties={"pipelines.reset.allowed": "false", "quality": "bronze"},
        expect_all={"valid_contract": "is_valid"},  # tracked, never dropped
    )

    @dp.append_flow(target=event, name=f"{e}_live")
    def live():
        return to_event_columns(read_source(t), t, UPDATE_BATCH_ID)

    bf = t.get("backfill") or {}
    if bf.get("enabled"):

        @dp.append_flow(target=event, name=f"{e}_backfill", once=True)
        def backfill():
            # The history copy already has the event-table columns and keeps the original Kafka
            # coordinates. Reload time and the backfill batch id are stamped on the way in.
            h = spark.read.table(f"{CATALOG}.{SCHEMA}.{bf['table']}")
            h = h.select(
                "kafka_key", "kafka_topic", "kafka_partition", "kafka_offset", "kafka_timestamp",
                "kafka_timestamp_type", "is_delete_event",
                F.lit(bf.get("batch_id", -1)).cast("bigint").alias("ingestion_batch_id"),
                F.current_timestamp().alias("ingested_at"),
                F.current_date().alias("ingestion_date"),
                "payload_json",
            )
            return add_validation(h, t)

    # 2. Invalid messages, for review. They stay in the event table too.
    @dp.materialized_view(name=f"{e}_invalid", comment=f"Messages on {t['topic']} that failed contract {t['contract'].get('version')}.")
    def invalid():
        return spark.read.table(event).where("NOT is_valid")

    # 3. The changes that feed the record tables: valid messages only, renamed to FP11's record columns.
    changes = f"{e}_record_changes"

    # Ordering: Kafka columns map to the record's last_* names. A "$.path" entry orders by a payload
    # field instead, cast to a timestamp. Delete markers carry no such field, so they fall back to
    # the Kafka timestamp and still sort after the version they delete.
    seq_cols, seq_extra = [], []
    for i, c in enumerate(t["sequence_by"]):
        if c.startswith("$."):
            seq_extra.append(F.coalesce(
                F.get_json_object("payload_json", c).cast("timestamp"), F.col("kafka_timestamp")
            ).alias(f"_seq_{i}"))
            seq_cols.append(f"_seq_{i}")
        else:
            seq_cols.append(f"last_{c}" if c.startswith("kafka_") else c)

    def changes_df():
        return spark.readStream.table(event).select(
            "kafka_key",
            F.col("kafka_topic").alias("last_kafka_topic"),
            F.col("kafka_partition").alias("last_kafka_partition"),
            F.col("kafka_offset").alias("last_kafka_offset"),
            F.col("kafka_timestamp").alias("last_kafka_timestamp"),
            F.col("ingestion_batch_id").alias("last_ingestion_batch_id"),
            F.col("ingested_at").alias("last_updated_at"),
            "payload_json",
            "is_delete_event",
            "is_valid",
            *seq_extra,
        )

    if t["validation"].get("on_invalid") == "fail":
        # Today's FP11 behavior: the first invalid message stops the update.
        @dp.temporary_view(name=changes)
        @dp.expect_or_fail("valid_contract", "is_valid")
        def _changes():
            return changes_df()

    else:
        # Quarantine: invalid messages stay in the event table and never reach the record.
        @dp.temporary_view(name=changes)
        def _changes():
            return changes_df().where("is_valid")

    # A message delivered twice (by the backfill and by Kafka) keeps its timestamp and offset, so both
    # copies share one sequence value and collapse into one version. Do not add the batch id as a
    # tiebreaker: the second copy of a delete would then read as a later delete of a deleted key, and
    # the history table would gain a stray row with no start.
    sequence = F.struct(*seq_cols)
    not_stored = ["is_delete_event", "is_valid"] + [c for c in seq_cols if c.startswith("_seq_")]
    keys = t["keys"]
    record_props = {
        "delta.enableChangeDataFeed": "true",
        "delta.enableRowTracking": "true",
        "delta.enableDeletionVectors": "true",
        "quality": "silver",
    }

    # 4. Latest version per key. A delete removes the key.
    if 1 in t["scd_types"]:
        dp.create_streaming_table(
            name=record,
            comment=f"Latest version of each {e}, keyed on the Kafka key (SCD Type 1).",
            table_properties=record_props,
        )
        dp.create_auto_cdc_flow(
            target=record, source=changes, keys=keys, sequence_by=sequence,
            apply_as_deletes=F.expr("is_delete_event"),
            except_column_list=not_stored,
            stored_as_scd_type=1,
        )

    # 5. Every version per key. A delete closes the key's history. Only a payload change opens a
    #    new version, so a re-sent identical message does not.
    if 2 in t["scd_types"]:
        dp.create_streaming_table(
            name=history,
            comment=f"Every version of each {e} (SCD Type 2, __START_AT and __END_AT).",
            table_properties=record_props,
        )
        dp.create_auto_cdc_flow(
            target=history, source=changes, keys=keys, sequence_by=sequence,
            apply_as_deletes=F.expr("is_delete_event"),
            except_column_list=not_stored,
            stored_as_scd_type=2,
            track_history_column_list=["payload_json"],
        )

    # 6. Flattened tables: FP12 recipes, unchanged. Each recipe reads recipe_alias, which is a
    #    temporary view over the record table.
    if t.get("recipes"):

        @dp.temporary_view(name=t["recipe_alias"])
        def alias():
            return spark.read.table(record)

        for r in t["recipes"]:
            build_recipe(r, t)


def build_recipe(r, t):
    sql_text = read_text(r["file"])

    @dp.materialized_view(
        name=r["name"],
        comment=f"FP12 recipe {r['name']} over {t['entity']}_record. Key columns: {', '.join(r.get('key_columns', []))}.",
        table_properties={"delta.enableRowTracking": "true", "quality": "gold"},
    )
    def recipe():
        return spark.sql(sql_text)


for topic in load_config(CONFIG_PATH):
    build_topic(topic)
