# Databricks notebook source
# MAGIC %md
# MAGIC # Synthetic Kafka feed for the event-record pattern
# MAGIC
# MAGIC There is no Kafka broker in the demo workspace, so this notebook plays the producer. It writes
# MAGIC Parquet files that carry the exact columns a Kafka source returns (`key`, `value`, `topic`,
# MAGIC `partition`, `offset`, `timestamp`, `timestampType`) into a Unity Catalog volume, one folder
# MAGIC per topic. Every value is synthetic. The payload shapes follow the field paths in the FP12
# MAGIC recipes.
# MAGIC
# MAGIC It behaves like a producer:
# MAGIC
# MAGIC - **Key-hash partitioning.** One key always lands on one partition, and offsets increase within
# MAGIC   each partition.
# MAGIC - **Deletes** are ordinary messages whose payload is only the key plus `"deleted": true`.
# MAGIC - **About 5% invalid payloads** (a wrong type, a missing required field, a malformed date,
# MAGIC   one message that is not JSON).
# MAGIC - **Re-sent duplicates** (same payload, new offset) and **late arrivals** (a message that
# MAGIC   shows up one batch after its neighbors).
# MAGIC - **A 3-day Kafka window.** Older messages exist only in a history copy, the stand-in for the
# MAGIC   Snowflake tables. The copy overlaps the Kafka window by 12 hours, as a real backfill would.
# MAGIC
# MAGIC ## Actions
# MAGIC
# MAGIC | action | what it does |
# MAGIC | --- | --- |
# MAGIC | `reset` | Clears the landing folders, writes the history copy tables, and writes live batch 1 |
# MAGIC | `next` | Writes the next live batch (2, 3, then 4) for every topic |
# MAGIC
# MAGIC The whole timeline is generated from a fixed seed, so every run produces the same messages.

# COMMAND ----------

dbutils.widgets.text("catalog", "", "Catalog")
dbutils.widgets.text("schema", "", "Schema")
dbutils.widgets.text("landing_root", "", "Landing root (volume path)")
dbutils.widgets.dropdown("action", "next", ["reset", "next"], "Action")
dbutils.widgets.text("animal_topic", "demo-animal-v2", "Animal topic")
dbutils.widgets.text("study_topic", "demo-study-v1", "Study topic")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA = dbutils.widgets.get("schema")
ROOT = dbutils.widgets.get("landing_root").rstrip("/")
ACTION = dbutils.widgets.get("action")
TOPICS = {"animal": dbutils.widgets.get("animal_topic"), "study": dbutils.widgets.get("study_topic")}
assert CATALOG and SCHEMA and ROOT, "catalog, schema, and landing_root are required"

# COMMAND ----------

import copy
import json
import random
import zlib
from datetime import datetime, timedelta, timezone

SEED = 20261009
PARTITIONS = 3
LIVE_BATCHES = 4
ANCHOR = datetime(2026, 10, 9, 6, 0, tzinfo=timezone.utc)   # "now" for the synthetic timeline
START = ANCHOR - timedelta(days=10)
KAFKA_WINDOW_START = ANCHOR - timedelta(days=3)               # Kafka keeps 3 days
HISTORY_END = KAFKA_WINDOW_START + timedelta(hours=12)        # the copy overlaps by 12 hours

rng = random.Random(SEED)


def iso(ts):
    return ts.strftime("%Y-%m-%dT%H:%M:%S.") + f"{ts.microsecond // 1000:03d}Z"


USERS = ["user.a", "user.b", "user.c", "user.d"]
SPECIES = ["Mouse, C57BL/6", "Mouse, BALB/c", "Rat, Sprague Dawley", "Rat, Wistar"]
GENOTYPES = ["WT", "KO", "Het", None]
PROVIDERS = ["Provider North", "Provider South", None, None]
LEVELS = ["Info", "Warning", "Observation"]
CONTEXTS = ["Dosing", "Health check", "Weighing", "Necropsy"]
FATES = [("EUT", "Euthanized"), ("TRN", "Transferred"), ("FND", "Found dead")]

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Build the entity timeline
# MAGIC
# MAGIC Each message is `(time, entity, key, payload_text)`. State changes are applied to a working copy
# MAGIC of each entity, and every change is published as the full entity view, as the source
# MAGIC applications do.

# COMMAND ----------

messages = []   # (ts, entity, key, payload_text)


def publish(ts, entity, key, doc):
    messages.append((ts, entity, key, json.dumps(doc, separators=(",", ":"))))


def rand_time(lo, hi):
    return lo + timedelta(seconds=rng.uniform(0, (hi - lo).total_seconds()))


# Studies: the source of the group table.
studies = {}
next_group_id = 5000
for i in range(1, 13):
    sid = f"ST-{i:04d}"
    created = rand_time(START, START + timedelta(days=2))
    groups = []
    for g in range(rng.randint(2, 4)):
        next_group_id += 1
        groups.append({
            "oivId": next_group_id, "name": f"Group {g + 1}", "groupTypes": [rng.choice(["Treatment", "Control"])],
            "color": rng.choice(["#1F8A5B", "#C8870B", "#1B3139", "#FF3621"]),
            "speciesAndStrain": rng.choice(SPECIES), "genotype": rng.choice(GENOTYPES), "sex": rng.choice(["M", "F"]),
            "ageAtStudyStart": f"{rng.randint(6, 12)} weeks", "plannedAnimalCount": rng.randint(4, 12),
            "comments": None, "createdBy": rng.choice(USERS), "createdAt": iso(created),
            "modifiedBy": rng.choice(USERS), "modifiedAt": iso(created),
        })
    studies[sid] = {"sid": sid, "groups": groups}
    publish(created, "study", sid, studies[sid])

# Study updates across the timeline, a few in every live batch.
for sid in rng.sample(sorted(studies), 9):
    ts = rand_time(START + timedelta(days=2), ANCHOR)
    s = studies[sid]
    g = rng.choice(s["groups"])
    if rng.random() < 0.3 and len(s["groups"]) > 2:
        s["groups"].remove(g)                              # a group removed from the array
    else:
        g["plannedAnimalCount"] = g["plannedAnimalCount"] + rng.randint(1, 3)
        g["comments"] = "Planned count revised"
        g["modifiedAt"], g["modifiedBy"] = iso(ts), rng.choice(USERS)
    publish(ts, "study", sid, s)

# One study deleted in the history, one in the live window.
publish(START + timedelta(days=5), "study", "ST-0011", {"sid": "ST-0011", "deleted": True})
publish(ANCHOR - timedelta(hours=20), "study", "ST-0012", {"sid": "ST-0012", "deleted": True})
study_ids = [s for s in sorted(studies) if s not in ("ST-0011", "ST-0012")]

# Animals: the source of the animal and comment tables.
animals = {}
created_at = {}
next_comment_id, next_link_id = 12000, 900
for i in range(1, 241):
    key = f"AN-{i:05d}"
    created = rand_time(START, ANCHOR - timedelta(days=1))
    created_at[key] = created
    links = []
    for sid in rng.sample(study_ids, rng.choice([1, 1, 2])):
        next_link_id += 1
        links.append({"studySid": sid, "oivId": next_link_id, "comments": []})
    animals[key] = {
        "smfId": key, "speciesAndStrain": rng.choice(SPECIES), "genotype": rng.choice(GENOTYPES),
        "sex": rng.choice(["M", "F"]),
        "dateOfBirth": (created - timedelta(days=rng.randint(40, 120))).strftime("%Y-%m-%d"),
        "animalProvider": rng.choice(PROVIDERS), "namsId": rng.randint(100000, 999999),
        "mosaicId": f"MZ-{rng.randint(10000, 99999)}", "fateCode": None,
        "studyTransfers": [],                              # usually empty, as in the real feed
        "studies": links, "createdBy": rng.choice(USERS), "createdAt": iso(created),
        "modifiedBy": rng.choice(USERS), "modifiedAt": iso(created),
    }
    publish(created, "animal", key, animals[key])


def touch(a, ts):
    a["modifiedAt"], a["modifiedBy"] = iso(ts), rng.choice(USERS)


def add_comment(a, ts):
    global next_comment_id
    next_comment_id += 1
    link = rng.choice(a["studies"])
    link["comments"].append({
        "oivId": next_comment_id, "date": iso(ts), "level": rng.choice(LEVELS), "context": rng.choice(CONTEXTS),
        "measurementOivIds": rng.sample(range(70000, 70100), rng.choice([0, 0, 2])), "interventionOivIds": [],
        "comment": f"Observation {next_comment_id}", "isImportant": rng.random() < 0.1,
        "createdBy": rng.choice(USERS), "createdAt": iso(ts), "modifiedBy": rng.choice(USERS), "modifiedAt": iso(ts),
    })


deleted_animals = set(rng.sample(sorted(animals), 10))
for key in sorted(animals):
    a = animals[key]
    for _ in range(rng.randint(1, 4)):
        ts = rand_time(created_at[key] + timedelta(minutes=5), ANCHOR - timedelta(minutes=5))
        all_comments = [(l, c) for l in a["studies"] for c in l["comments"]]
        r = rng.random()
        if r < 0.5 or not all_comments:
            add_comment(a, ts)
        elif r < 0.7:
            l, c = rng.choice(all_comments)
            c["comment"] += " (edited)"
            c["modifiedAt"] = iso(ts)
        elif r < 0.8:
            l, c = rng.choice(all_comments)
            l["comments"].remove(c)                        # a comment removed from the array
        elif r < 0.9 and a["fateCode"] is None:
            abbr, name = rng.choice(FATES)
            a["fateCode"] = {"abbreviation": abbr, "name": name, "date": ts.strftime("%Y-%m-%d"),
                             "time": ts.strftime("%H:%M:%S"),  # a bare wall-clock time, not a timestamp
                             "comment": None}
        else:
            a["studyTransfers"].append({"sourceStudySid": a["studies"][0]["studySid"],
                                        "targetStudySid": rng.choice(study_ids), "transferredAt": iso(ts)})
        touch(a, ts)
        publish(ts, "animal", key, copy.deepcopy(a))
    if key in deleted_animals:
        ts = rand_time(created_at[key] + timedelta(hours=1), ANCHOR - timedelta(minutes=1))
        publish(ts, "animal", key, {"smfId": key, "deleted": True})

messages.sort(key=lambda m: m[0])
# A delete must be the last message for its key, so drop anything an animal published after it.
seen_delete = set()
kept = []
for m in messages:
    ts, entity, key, text = m
    if (entity, key) in seen_delete:
        continue
    if '"deleted":true' in text:
        seen_delete.add((entity, key))
    kept.append(m)
messages = kept

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Invalid messages, re-sent duplicates, then Kafka coordinates

# COMMAND ----------

def broken(entity, key, text):
    doc = json.loads(text)
    kind = rng.choice(["type", "missing", "date", "type", "missing", "date", "notjson"])
    if kind == "notjson":
        return text[: len(text) // 2]                        # truncated, not JSON
    if entity == "animal":
        if kind == "type":
            doc["sex"] = 7
        elif kind == "missing":
            doc.pop("smfId", None)
        else:
            doc["dateOfBirth"] = "31/12/2025"
    else:
        if kind == "type":
            doc["groups"][0]["oivId"] = "not-a-number"
        elif kind == "missing":
            doc.pop("sid", None)
        else:
            doc["groups"] = "none"
    return json.dumps(doc, separators=(",", ":"))


extra = []
for ts, entity, key, text in messages:
    if '"deleted":true' in text:
        continue
    r = rng.random()
    if r < 0.05:
        # A faulty publish right after a good one. It never changes the entity's real state.
        extra.append((ts + timedelta(seconds=rng.randint(5, 90)), entity, key, broken(entity, key, text)))
    elif r < 0.08:
        # The same entity view published twice.
        extra.append((ts + timedelta(seconds=rng.randint(30, 300)), entity, key, text))
messages = sorted(messages + extra, key=lambda m: m[0])

offsets = {}
rows = []
for ts, entity, key, text in messages:
    topic = TOPICS[entity]
    part = zlib.crc32(key.encode()) % PARTITIONS
    off = offsets.get((topic, part), 0)
    offsets[(topic, part)] = off + 1
    is_delete = '"deleted":true' in text
    rows.append({"entity": entity, "key": key, "value": text, "topic": topic, "partition": part,
                 "offset": off, "timestamp": ts, "timestampType": 0, "is_delete": is_delete})

# Live batches: 4 equal slices of the 3-day Kafka window. About 3% of messages arrive one batch late.
span = (ANCHOR - KAFKA_WINDOW_START) / LIVE_BATCHES
for r in rows:
    if r["timestamp"] >= KAFKA_WINDOW_START:
        b = min(int((r["timestamp"] - KAFKA_WINDOW_START) / span) + 1, LIVE_BATCHES)
        if b < LIVE_BATCHES and rng.random() < 0.03:
            b += 1
        r["batch"] = b
    else:
        r["batch"] = None

print(f"{len(rows)} messages; per topic:",
      {t: sum(1 for r in rows if r['topic'] == t) for t in TOPICS.values()})

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Write

# COMMAND ----------

from pyspark.sql import types as T

KAFKA_SCHEMA = T.StructType([
    T.StructField("key", T.BinaryType()), T.StructField("value", T.BinaryType()),
    T.StructField("topic", T.StringType()), T.StructField("partition", T.IntegerType()),
    T.StructField("offset", T.LongType()), T.StructField("timestamp", T.TimestampType()),
    T.StructField("timestampType", T.IntegerType()),
])
HISTORY_SCHEMA = T.StructType([
    T.StructField("kafka_key", T.StringType()), T.StructField("kafka_topic", T.StringType()),
    T.StructField("kafka_partition", T.IntegerType()), T.StructField("kafka_offset", T.LongType()),
    T.StructField("kafka_timestamp", T.TimestampType()), T.StructField("kafka_timestamp_type", T.IntegerType()),
    T.StructField("is_delete_event", T.BooleanType()), T.StructField("payload_json", T.StringType()),
])


def batch_path(topic, b):
    return f"{ROOT}/{topic}/batch_{b:04d}"


def write_batch(b):
    for entity, topic in TOPICS.items():
        data = [(r["key"].encode(), r["value"].encode(), r["topic"], r["partition"], r["offset"],
                 r["timestamp"].replace(tzinfo=None), r["timestampType"])
                for r in rows if r["topic"] == topic and r["batch"] == b]
        spark.createDataFrame(data, KAFKA_SCHEMA).coalesce(1).write.mode("overwrite").parquet(batch_path(topic, b))
        print(f"batch {b}: {len(data):4d} messages -> {batch_path(topic, b)}")


def written_batches(topic):
    try:
        return sorted(int(f.name.strip("/").split("_")[1]) for f in dbutils.fs.ls(f"{ROOT}/{topic}/")
                      if f.name.startswith("batch_"))
    except Exception:
        return []


spark.sql("SET TIME ZONE 'UTC'")

if ACTION == "reset":
    # The event table refuses a full refresh, so re-landing batch 1 would be ingested a second time
    # and double every count. Start a fresh demo from a fresh pipeline instead.
    for entity in TOPICS:
        if spark.catalog.tableExists(f"{CATALOG}.{SCHEMA}.{entity}_event") and \
                spark.table(f"{CATALOG}.{SCHEMA}.{entity}_event").limit(1).count() > 0:
            raise RuntimeError(
                f"{entity}_event already holds messages. To start over, run "
                "`databricks bundle destroy -t br_workspace`, then `databricks bundle deploy -t br_workspace`, then reset.")
    for topic in TOPICS.values():
        dbutils.fs.rm(f"{ROOT}/{topic}/", True)
    for entity, topic in TOPICS.items():
        data = [(r["key"], r["topic"], r["partition"], r["offset"], r["timestamp"].replace(tzinfo=None),
                 r["timestampType"], r["is_delete"], r["value"])
                for r in rows if r["topic"] == topic and r["timestamp"] < HISTORY_END]
        table = f"{CATALOG}.{SCHEMA}.{entity}_history_copy"
        (spark.createDataFrame(data, HISTORY_SCHEMA).write.mode("overwrite")
         .option("overwriteSchema", "true").saveAsTable(table))
        spark.sql(f"COMMENT ON TABLE {table} IS 'Stand-in for the Snowflake history of {topic}, copied into Delta once. Synthetic.'")
        print(f"history copy: {len(data):4d} messages -> {table}")
    write_batch(1)
else:
    done = written_batches(TOPICS["animal"])
    nxt = (max(done) + 1) if done else 1
    if nxt > LIVE_BATCHES:
        print(f"All {LIVE_BATCHES} live batches are already written. Run action=reset to start over.")
    else:
        write_batch(nxt)
