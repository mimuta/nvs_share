# Kafka event-record pattern on Lakeflow pipelines

One configuration entry per topic generates the whole flow: an event table, the record tables, validation, and your flattening recipes. A new topic is a new entry in `kafka_pattern/topics.yaml`, with no new code. Your factory pattern 12 (FP12) flattening Structured Query Language (SQL) runs as you wrote it, from `SELECT` down.

Every value in this demo is synthetic. The shapes come from the structures and SQL you shared.

## Run it in your workspace

You need the Databricks command-line interface (CLI), a workspace with serverless compute, and a catalog in Unity Catalog where you can create a schema. Nothing in `topics.yaml` changes for the demo.

1. Sign in once: `databricks auth login --host <your-workspace-url>`. Use the full address from your browser, starting with `https://`. The CLI opens your browser, then saves a profile for that workspace.
2. In `databricks.yml`, set the `br_workspace` target's `host` to the same address and `catalog` to your catalog. The CLI [matches the host to your saved profile](https://docs.databricks.com/aws/en/dev-tools/bundles/settings).
3. Deploy, then run one batch at a time:

```bash
databricks bundle deploy -t br_workspace
databricks bundle run kafka_feed_simulator -t br_workspace --params action=reset   # history copy and live batch 1
databricks bundle run kafka_pattern_run -t br_workspace                            # update, then checks
databricks bundle run kafka_feed_simulator -t br_workspace                         # next live batch (2, 3, 4)
databricks bundle run kafka_pattern_run -t br_workspace
```

In development mode, the bundle deploys the schema as `dev_<user>_br_kafka_pattern`.

To run the demo again from the start, run `databricks bundle destroy -t br_workspace`, then deploy and reset. The event table refuses a full refresh, so the simulator's reset stops with a message if the event table already holds data.

`kafka_pattern_run` carries the same 15-minute schedule as today's FP11 job, paused in the demo. Each run is a triggered update that stops when it finishes, so compute is idle between runs.

**The Kafka source has not yet run against a live broker.** The demo reads files that carry Kafka's exact columns from a Unity Catalog volume, through the same pipeline code. The steps to a live topic are in "Moving to a real topic" below.

## What gets built for each topic

```
Kafka topic (or files carrying the Kafka columns)
  -> <entity>_event            streaming table: every message, append-only, protected from full refresh
       -> <entity>_invalid     materialized view: messages that failed the contract, for review
  -> <entity>_record           streaming table, slowly changing dimension (SCD) Type 1: latest version per key; a delete removes the key
  -> <entity>_record_history   streaming table, SCD Type 2: every version per key; a delete closes its history
  -> your recipes              one materialized view per FP12 SQL file, read from the record table
```

In SCD Type 2, AUTO CDC keeps two validity columns on every version. `__START_AT` is the sequence value at which a version becomes valid. `__END_AT` is the sequence value at which its validity ends, and `NULL` marks the current version. Here the sequence is the Kafka timestamp and offset, so each column holds that pair. A delete fills in the open `__END_AT`, which closes the key's history.

The event table feeds the record tables in sequence. It holds the complete history, so a rebuild or the day-one backfill needs only that table.

## Where your inputs went

| What you shared | Where it lives | How it is used |
|---|---|---|
| Event table structure, factory pattern 11 (FP11) | `src/kafka_pattern/pipeline.py`, `to_event_columns` | The event table has your exact columns, from `kafka_key` to `payload_json`, clustered by `ingestion_date`. Three optional columns record the contract check: `is_valid`, `validation_error`, `contract_version`. |
| Record table structure | Change data capture (CDC) flows in `pipeline.py`, using AUTO CDC | The record table has your exact `last_*` columns. AUTO CDC keeps it current, so no merge code is needed. |
| Business key (Kafka key, also in the payload) | `keys: [kafka_key]` in `topics.yaml` | The key for both record tables. |
| Deletes (`"deleted": true` in the payload) | `delete_flag_path: "$.deleted"` | Sets `is_delete_event`. A delete removes the key from `_record` and closes it in `_record_history`. |
| `animal_v1.sql`, `animal_comment_v1.sql`, `animal_group_v1.sql` | `kafka_pattern/recipes/` | Unchanged from `SELECT` down. Each file reads its table name (`kafka_animal`, `kafka_study`). The pipeline creates that name as a temporary view over the record table. |
| `key_columns` per recipe | `recipes[].key_columns` | Checked for uniqueness after every update. A materialized view needs no merge keys, so FP12's affected-keys merge has no counterpart here. |
| Raw payload mode | `payload_mode: raw` | The whole Kafka value stays as JavaScript Object Notation (JSON) text in `payload_json`, as in FP11. |

## Defaults we chose, each one line to change

| Default | Setting in `topics.yaml` | Why |
|---|---|---|
| Versions of a key are ordered by Kafka timestamp, then offset | `sequence_by: [kafka_timestamp, kafka_offset]` | With key-based partitioning, a key stays on one partition, so this gives a total order per key. To order by a payload field instead, use a path such as `"$.modifiedAt"`. |
| The group recipe reads the study topic | a second entry, `entity: study` | `animal_group_v1.sql` reads `kafka_study` (`$.sid`, `$.groups`). The demo study feed carries only the fields that recipe reads. |
| Backfilled rows carry `ingestion_batch_id = -1` | `backfill.batch_id: -1` | Marks rows loaded from the history copy, apart from live batches. |
| Delete markers skip the contract check | `validation.skip_delete_markers: true` | A delete marker holds only the key and the flag. A full contract would reject it and keep the delete from reaching the record tables. |
| Invalid messages are quarantined | `validation.on_invalid: quarantine` | They stay in the event table, flagged, and never reach the record tables. Set `fail` to stop the update on the first invalid message, as FP11 does today. |

## What the demo proves

The checks notebook (`notebooks/kafka_pattern_checks.py`) runs after every update. On the demo feed, it confirms:

- **Every message is kept:** valid and invalid messages, deletes, re-sent duplicates, and the 12-hour overlap between the history copy and Kafka.
- **The record table matches a replay.** Recomputing the latest valid version per key from the event table alone gives the same rows. This holds with re-sent duplicates, and with a file the demo feed delivers one batch late, as a replay or backfill can.
- **Deletes work at every level.** A deleted key leaves `_record`, its history closes, and its rows leave every recipe output.
- **Recipe outputs are unique on their `key_columns`.**
- **Recipes refresh incrementally.** The pipeline event log shows `ROW_BASED` maintenance for all three recipes, including the double `LATERAL VIEW explode`. Only changed rows are reprocessed.
- **A rebuild needs no Kafka.** A full refresh of the record tables and recipes rebuilds them from the event table, with the same result.
- **The event table is protected.** A full refresh that includes the event table stops with the error "is not resettable".

## Moving to a real topic

1. Set `source.mode: kafka`, and fill in `bootstrap_servers`.
2. Make sure the pipeline's compute can reach the brokers over the network, and authenticate with one of the methods Databricks supports for Kafka, such as a Unity Catalog service credential or Amazon Managed Streaming for Apache Kafka (MSK) authentication ([Kafka authentication](https://docs.databricks.com/aws/en/connect/streaming/kafka/authentication)). Pass any secret as `"secret:<scope>/<key>"` in `options`. Never put a credential in `topics.yaml`.
3. Replace the demo contract with your JSON Schema, and point `contract.schema` at it.
4. Copy the Snowflake history into a Delta table with the event-table columns, and name it in `backfill.table`.
5. Add your recipes under `recipes`.

The demo runs on the file lane because the workspace has no broker. The Kafka read in `read_source` uses the standard `kafka` source with the same columns. It has not run against a live broker in this workspace.
