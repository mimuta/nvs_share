# Kafka event-record pattern on Lakeflow pipelines, for Novartis Biomedical Research (BR)

A working example of the Data Factory Kafka pattern on Databricks, built for BR. One configuration file builds the whole flow: an event table that keeps every message, the record tables, a contract check, and the flattening recipes. Everything runs on synthetic data, in shapes that come from the structures and recipes the Data Factory team shared.

## Run it in your workspace

Prerequisites: the Databricks command-line interface (CLI), a workspace with serverless compute, and a catalog in Unity Catalog where you can create a schema. The pipeline installs two Python packages, `jsonschema` and `pyyaml` (listed in `resources/kafka_pattern.yml`). They come from the Python Package Index (PyPI), or from the [default package repository](https://docs.databricks.com/aws/en/admin/workspace-settings/default-python-packages) your workspace admins set.

1. Sign in once: `databricks auth login --host <your-workspace-url>`. Use the full address from your browser, starting with `https://`. The CLI opens your browser, then saves a profile for that workspace.
2. In `databricks.yml`, set the `br_workspace` target's `host` to the same address and `catalog` to your catalog. The CLI [matches the host to your saved profile](https://docs.databricks.com/aws/en/dev-tools/bundles/settings). Nothing in `topics.yaml` changes for the demo.
3. Deploy, then run the synthetic feed and the pattern, one batch at a time:

```bash
databricks bundle deploy -t br_workspace
databricks bundle run kafka_feed_simulator -t br_workspace --params action=reset   # history copy and live batch 1
databricks bundle run kafka_pattern_run -t br_workspace                            # update, then checks
databricks bundle run kafka_feed_simulator -t br_workspace                         # next live batch
databricks bundle run kafka_pattern_run -t br_workspace
```

Repeat the last two commands for batches 3 and 4. Development mode deploys the schema as `dev_<user>_br_kafka_pattern`. The pattern job carries a 15-minute schedule, paused; unpause it to run on that cadence.

**The Kafka source has not yet run against a live broker.** The demo reads files that carry Kafka's exact columns, from a Unity Catalog volume, through the same pipeline code. Moving to a real topic is a setting change in `topics.yaml` (`source.mode: kafka` and the broker addresses). The steps are in "Moving to a real topic" in `docs/KAFKA_PATTERN.md`. Never put a credential in `topics.yaml`; pass secrets as `"secret:<scope>/<key>"`.

The guide is `docs/KAFKA_PATTERN.html`, also available as `docs/KAFKA_PATTERN.md`.

## What gets built for each topic

One entry per topic in `kafka_pattern/topics.yaml` builds these tables. The event table keeps every message, and the record tables and recipes are built from it in each pipeline update. So a rebuild needs only the event table, never Kafka.

```
Kafka topic (or files carrying the Kafka columns)
  -> <entity>_event            streaming table: every message, append-only, protected from full refresh
       -> <entity>_invalid     materialized view: messages that failed the contract, for review
  -> <entity>_record           streaming table, latest version per key
  -> <entity>_record_history   streaming table, every version per key
  -> your recipes              one materialized view per flattening SQL file
```

The demo builds 13 tables from two topics:

| Topic | Tables |
|---|---|
| `animal` | `animal_event`, `animal_invalid`, `animal_record`, `animal_record_history`, and the recipes `animal_v1` and `animal_comment_v1` |
| `study` | `study_event`, `study_invalid`, `study_record`, `study_record_history`, and the recipe `animal_group_v1` |
| Both | `animal_history_copy` and `study_history_copy`, the synthetic stand-ins for the Snowflake history, loaded once into each event table |

What each layer does:
- **Validation.** Each message is checked against a JavaScript Object Notation (JSON) Schema contract. Invalid messages stay in the event table, flagged, and never reach the record tables.
- **Record tables.** AUTO CDC (change data capture) keeps them current, with no merge code. `_record` is slowly changing dimension (SCD) Type 1, the latest version. `_record_history` is SCD Type 2, every version.
- **Deletes.** A message with `"deleted": true` removes the key from `_record` and closes its history.
- **Recipes.** The factory pattern 12 (FP12) Structured Query Language (SQL) runs as written, from `SELECT` down. Each recipe is a materialized view that refreshes incrementally when it can.

The checks notebook, `notebooks/kafka_pattern_checks.py`, confirms the result after every update.

## Repository layout

```
databricks.yml                  # bundle: name, the catalog variable, and the targets
resources/kafka_pattern.yml     # the schema, landing volume, pipeline, and two jobs
kafka_pattern/                  # topics.yaml, JSON Schema contracts, FP12 recipes
src/kafka_pattern/pipeline.py   # the pipeline, built from topics.yaml
generators/generate_kafka_feed.py   # the synthetic Kafka feed
notebooks/kafka_pattern_checks.py   # the checks that run after each update
docs/KAFKA_PATTERN.html         # the guide (also as .md)
```

## Built for serverless

The pipeline and both jobs run on serverless compute. The notebooks avoid two serverless limits: `spark.conf.set` of arbitrary keys is blocked, and `%sql ${var}` reads Spark configuration rather than notebook widgets. So the notebooks build their SQL in Python with `spark.sql(f"...")`.
